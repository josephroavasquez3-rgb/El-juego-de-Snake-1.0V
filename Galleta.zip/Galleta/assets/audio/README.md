# Audio

El gestor central está en `js/audio/audio-manager.js`. Usa Web Audio como respaldo y busca pistas locales opcionales; si un archivo no existe, Snake sigue funcionando.

- [Música](music/README.md): `menu.mp3`, `game.mp3` y `gameover.mp3`.
- [Efectos](sfx/README.md): nombres, formatos y sonidos de reemplazo.
