# Efectos de sonido

El gestor busca opcionalmente estos archivos y sintetiza un respaldo si faltan:

- `button.wav`, `start.wav`, `eat.wav`, `gameover.wav`
- `pause.wav`, `resume.wav`, `select.wav`, `map.wav`, `mode.wav`
- `error.wav`

Los controles **Sonido** y **Efectos** de Opciones activan/desactivan los efectos; **Efectos** ajusta el volumen. WAV y MP3 son los formatos recomendados.
