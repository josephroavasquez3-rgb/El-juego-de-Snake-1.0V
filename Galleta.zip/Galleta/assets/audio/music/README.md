# Música del juego

Coloca aquí pistas locales con estos nombres:

- `menu.mp3`: tema del menú y salas.
- `game.mp3`: música de una partida.
- `gameover.mp3`: música al terminar.

El gestor central las cambia por escena; reemplaza el archivo conservando el nombre para cambiar una pista. MP3 y WAV funcionan en navegadores modernos; Ogg Vorbis y M4A dependen del navegador. Si falta un archivo, el juego usa la música sintetizada de respaldo sin detenerse.

El control **Música** de Opciones activa/desactiva la pista y el deslizador **Música** guarda el volumen. El navegador solo intenta reproducirla después de una interacción del usuario.
