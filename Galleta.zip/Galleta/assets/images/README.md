# Images

Recursos visuales locales del juego. Mantén las rutas relativas al proyecto para que `index.html` siga funcionando sin servicios externos.
