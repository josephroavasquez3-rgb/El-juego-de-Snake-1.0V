# Avatares locales

Los perfiles actuales usan avatares emoji sin recursos externos. Esta carpeta queda disponible para incorporar imágenes locales; el selector puede ampliarse para referenciarlas desde el perfil sin cambiar las estadísticas o el almacenamiento de salas.