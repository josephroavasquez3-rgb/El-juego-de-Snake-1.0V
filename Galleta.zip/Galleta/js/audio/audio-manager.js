const MUSIC_TRACKS = {
    menu: 'assets/audio/music/menu.mp3',
    game: 'assets/audio/music/game.mp3',
    gameover: 'assets/audio/music/gameover.mp3'
};

const SOUND_FILES = {
    button: 'assets/audio/sfx/button.wav',
    start: 'assets/audio/sfx/start.wav',
    eat: 'assets/audio/sfx/eat.wav',
    gameOver: 'assets/audio/sfx/gameover.wav',
    pause: 'assets/audio/sfx/pause.wav',
    resume: 'assets/audio/sfx/resume.wav',
    select: 'assets/audio/sfx/select.wav',
    map: 'assets/audio/sfx/map.wav',
    mode: 'assets/audio/sfx/mode.wav',
    error: 'assets/audio/sfx/error.wav'
};

export class AudioManager {
    constructor({ soundEnabled = true, musicEnabled = false, soundVolume = 0.65, musicVolume = 0.35 } = {}) {
        this.soundEnabled = soundEnabled;
        this.musicEnabled = musicEnabled;
        this.soundVolume = soundVolume;
        this.musicVolume = musicVolume;
        this.context = null;
        this.musicTimer = null;
        this.musicNote = 0;
        this.musicElement = null;
        this.currentScene = 'menu';
        this.unlocked = false;
        this.fileAvailability = new Map();
        this.activeTrack = null;
    }

    getContext() {
        if (!this.context) {
            const Context = window.AudioContext ?? window.webkitAudioContext;
            if (Context) this.context = new Context();
        }
        if (this.context?.state === 'suspended') this.context.resume();
        return this.context;
    }

    unlock() {
        this.unlocked = true;
        if (this.context?.state === 'suspended') this.context.resume();
        this.updateMusic();
    }

    tone(frequency, duration, type = 'sine', volume = 0.06, delay = 0, channel = 'sound') {
        if (channel === 'music' ? !this.musicEnabled : !this.soundEnabled) return;
        const context = this.getContext();
        if (!context) return;
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        const start = context.currentTime + delay;
        oscillator.type = type;
        oscillator.frequency.setValueAtTime(frequency, start);
        gain.gain.setValueAtTime(volume * (channel === 'music' ? this.musicVolume : this.soundVolume), start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + duration);
        oscillator.connect(gain).connect(context.destination);
        oscillator.start(start);
        oscillator.stop(start + duration);
    }

    playSound(event) {
        if (!this.soundEnabled || this.soundVolume <= 0) return;
        const file = SOUND_FILES[event];
        const available = this.fileAvailability.get(file);
        if (file && available === true) {
            const player = new Audio(file);
            player.volume = this.soundVolume;
            player.play().catch(() => this.playSynth(event));
            return;
        }
        if (file && available === undefined) this.probeFile(file);
        this.playSynth(event);
    }

    probeFile(file) {
        if (this.fileAvailability.has(file)) return Promise.resolve(this.fileAvailability.get(file));
        if (location.protocol === 'file:' || typeof fetch !== 'function') {
            this.fileAvailability.set(file, false);
            return Promise.resolve(false);
        }
        const check = fetch(file, { method: 'HEAD', cache: 'force-cache' })
            .then(response => response.ok && response.headers.get('X-Snake-Optional') !== 'missing')
            .catch(() => false)
            .then(available => {
                this.fileAvailability.set(file, available);
                return available;
            });
        this.fileAvailability.set(file, check);
        return check;
    }

    play(event) {
        this.playSound(event);
    }

    playSynth(event) {
        const patterns = {
            button: [[520, 0.045, 'square', 0.018]],
            start: [[392, 0.11, 'triangle', 0.04], [587, 0.16, 'triangle', 0.035, 0.1]],
            eat: [[740, 0.08, 'sine', 0.06], [980, 0.11, 'sine', 0.035, 0.06]],
            gameOver: [[330, 0.18, 'triangle', 0.05], [220, 0.32, 'triangle', 0.04, 0.16]],
            pause: [[440, 0.06, 'sine', 0.025]],
            resume: [[660, 0.08, 'sine', 0.025]],
            select: [[620, 0.04, 'sine', 0.018]],
            map: [[480, 0.05, 'triangle', 0.02]],
            mode: [[540, 0.05, 'triangle', 0.02]],
            error: [[220, 0.12, 'triangle', 0.025]]
        };
        (patterns[event] ?? []).forEach(([frequency, duration, type, volume, delay = 0]) => this.tone(frequency, duration, type, volume, delay));
    }

    setSoundEnabled(enabled) {
        this.soundEnabled = enabled;
    }

    setSoundVolume(value) {
        this.soundVolume = Math.min(1, Math.max(0, Number(value)));
    }

    setMusicVolume(value) {
        this.musicVolume = Math.min(1, Math.max(0, Number(value)));
        if (this.musicElement) this.musicElement.volume = this.musicVolume;
        if (this.musicVolume === 0) this.stopMusic();
        else if (this.musicEnabled) this.updateMusic();
    }

    setMusicEnabled(enabled) {
        this.musicEnabled = enabled;
        this.updateMusic();
    }

    setScene(scene) {
        this.currentScene = MUSIC_TRACKS[scene] ? scene : 'menu';
        this.updateMusic();
    }

    updateMusic() {
        if (!this.unlocked || !this.musicEnabled || this.musicVolume <= 0) {
            this.stopMusic();
            return;
        }
        const source = MUSIC_TRACKS[this.currentScene];
        if (this.activeTrack === source && (this.musicElement || this.musicTimer)) return;
        this.stopMusic();
        this.activeTrack = source;
        const availability = this.fileAvailability.get(source);
        if (availability === false || location.protocol === 'file:') {
            this.startSynthMusic();
            return;
        }
        if (availability === undefined) {
            this.startSynthMusic();
            this.probeFile(source).then(available => {
                if (available && this.musicEnabled && this.musicVolume > 0 && this.unlocked && MUSIC_TRACKS[this.currentScene] === source) {
                    this.stopMusic();
                    this.activeTrack = source;
                    this.playMusicFile(source);
                }
            });
            return;
        }
        this.playMusicFile(source);
    }

    playMusicFile(source) {
        this.musicElement = new Audio(source);
        this.musicElement.loop = true;
        this.musicElement.volume = this.musicVolume;
        this.musicElement.play().catch(() => {
            this.fileAvailability.set(source, false);
            this.musicElement = null;
            this.startSynthMusic();
        });
    }

    startSynthMusic() {
        if (!this.musicEnabled || this.musicVolume <= 0 || !this.unlocked || this.musicTimer) return;
        this.getContext();
        const notes = [196, 247, 294, 247];
        this.musicTimer = window.setInterval(() => {
            this.tone(notes[this.musicNote++ % notes.length], 0.42, 'sine', 0.012, 0, 'music');
        }, 780);
    }

    stopMusic() {
        window.clearInterval(this.musicTimer);
        this.musicTimer = null;
        if (this.musicElement) {
            this.musicElement.pause();
            this.musicElement = null;
        }
        this.activeTrack = null;
    }
}