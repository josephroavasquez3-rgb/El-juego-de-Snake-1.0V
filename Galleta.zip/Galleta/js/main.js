import { AudioManager } from './audio/audio-manager.js';
import {
    createPlayerProfile,
    deletePlayerProfile,
    getActivePlayerProfile,
    getPlayerProfile,
    getPlayerProfiles,
    renamePlayerProfile,
    selectPlayerProfile
} from './data/player-profile.js';
import { createGame } from './game.js';
import { isModeAvailable } from './game/config.js';
import { getSkin } from './game/skins.js';
import { drawRoomSnapshot, MultiplayerClient, playRoomDeath } from './multiplayer/client.js';
import {
    createPreview,
    markSelection,
    redrawCards,
    renderFoodCards,
    renderSkinCards,
    showUniverse,
    updateSelectionLabels
} from './customize.js';
import {
    applyDifficulty,
    applyMap,
    applyMode,
    applyPalette,
    readMapId,
    readModeId,
    refreshSetupSelection,
    renderAvatarPicker,
    renderDifficulties,
    renderPalettes,
    renderProfileCardList,
    renderSettings,
    renderSetup,
    savePreference,
    updateStatistics
} from './settings.js';

const screens = [...document.querySelectorAll('.screen')];
const initialProfile = getPlayerProfile();
const audio = new AudioManager(initialProfile);
const skinRoot = document.getElementById('screen-customize');
const foodList = document.getElementById('food-list');
let game;
let editingProfileId = null;
let selectedAvatar = initialProfile.avatar;
let currentScreen = 'customize';
let screenBeforeOptions = 'customize';
const preview = createPreview(document.getElementById('preview-canvas'));

function activeProfile() {
    return getActivePlayerProfile() ?? getPlayerProfile();
}

function refreshCustomize(profile = activeProfile()) {
    markSelection(document, 'skin', profile.selectedSkin);
    markSelection(foodList, 'food', profile.selectedFoodSkin);
    const universe = getSkin(profile.selectedSkin).universe;
    if (universe !== 'original') showUniverse(universe);
    updateSelectionLabels(profile);
    preview.select(profile);
}

function showScreen(name) {
    const leavingGame = currentScreen === 'game' && name !== 'game';
    const keepPausedGame = name === 'options' && game.isPaused();
    currentScreen = name;
    screens.forEach(screen => {
        const active = screen.id === `screen-${name}`;
        screen.classList.toggle('is-active', active);
        screen.setAttribute('aria-hidden', String(!active));
    });
    if (leavingGame && !keepPausedGame) game.stop();
    if (name === 'customize') {
        redrawCards(foodList);
        refreshCustomize();
        preview.start();
    } else {
        preview.stop();
    }
    if (name === 'options') renderSettings(activeProfile());
    if (name === 'setup') refreshSetupSelection();
    if (name === 'game') {
        audio.setScene('game');
        game.refresh();
        document.getElementById('game-board').focus({ preventScroll: true });
    } else if (name === 'customize' || name === 'multiplayer') {
        audio.setScene('menu');
    }
    window.scrollTo(0, 0);
}

function syncProfile() {
    const profile = activeProfile();
    applyPalette(profile.selectedTheme);
    applyDifficulty(profile.difficulty);
    applyMap(profile.mapId);
    applyMode(profile.modeId);
    audio.setSoundEnabled(profile.soundEnabled);
    audio.setMusicEnabled(profile.musicEnabled);
    audio.setSoundVolume(profile.soundVolume);
    audio.setMusicVolume(profile.musicVolume);
    document.getElementById('setup-avatar').textContent = profile.avatar;
    document.getElementById('setup-player-name').textContent = profile.name;
    renderSettings(profile);
    renderProfiles();
    redrawCards(foodList);
    refreshCustomize(profile);
}

function renderProfiles() {
    const profiles = getPlayerProfiles();
    const current = getActivePlayerProfile();
    renderProfileCardList(profiles, current?.id, document.getElementById('profile-list'));
    const formTitle = document.getElementById('profile-form-title');
    const saveButton = document.getElementById('btn-profile-save');
    const cancelButton = document.getElementById('btn-profile-cancel');
    const input = document.getElementById('profile-name-input');
    const hasProfiles = profiles.length > 0;
    if (!editingProfileId) {
        formTitle.textContent = hasProfiles ? 'AÑADIR PERFIL' : 'CREAR PERFIL';
        saveButton.textContent = hasProfiles ? 'CREAR PERFIL' : 'CREAR PERFIL';
        input.value = '';
        selectedAvatar = current?.avatar ?? '🐍';
    }
    cancelButton.hidden = !editingProfileId;
    renderAvatarPicker(document.getElementById('avatar-picker'), selectedAvatar);
}

function openProfileEditor(id) {
    const profile = getPlayerProfiles().find(item => item.id === id);
    if (!profile) return;
    editingProfileId = id;
    selectedAvatar = profile.avatar;
    document.getElementById('profile-form-title').textContent = 'CAMBIAR PERFIL';
    document.getElementById('btn-profile-save').textContent = 'GUARDAR CAMBIOS';
    document.getElementById('btn-profile-cancel').hidden = false;
    document.getElementById('profile-name-input').value = profile.name;
    renderAvatarPicker(document.getElementById('avatar-picker'), selectedAvatar);
    document.getElementById('profile-name-input').focus();
}

let roomPlayerId = null;
let roomHostId = null;

function escapeMarkup(value) {
    return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

function refreshRoomPlayers(players = [], playerId = roomPlayerId, hostId = roomHostId) {
    const container = document.getElementById('room-players');
    container.innerHTML = players.map((player, index) => `
        <article class="room-player${player.id === playerId ? ' is-self' : ''}"><span class="room-player-avatar">${escapeMarkup(player.avatar)}</span><strong>${escapeMarkup(player.name)}</strong><small>${player.id === hostId ? 'ANFITRIÓN' : `JUGADOR ${index + 1}`}</small><span class="room-player-status"><i></i>${player.connected === false ? 'DESCONECTADO' : 'CONECTADO'}</span></article>`).join('');
}

function setRoomStatus(title, message, isError = false) {
    document.getElementById('room-status').textContent = title;
    document.getElementById('room-message').textContent = message;
    document.getElementById('room-live-dot').classList.toggle('is-paused', isError);
    document.getElementById('room-panel').classList.toggle('is-error', isError);
}

function showRoomLobby(players = [], playerId = roomPlayerId, hostId = roomHostId) {
    roomPlayerId = playerId;
    roomHostId = hostId;
    document.getElementById('room-format').hidden = false;
    document.getElementById('room-players').hidden = false;
    document.getElementById('room-lobby-actions').hidden = false;
    document.getElementById('multiplayer-board-wrap').hidden = true;
    document.getElementById('multiplayer-results').hidden = true;
    refreshRoomPlayers(players, playerId, hostId);
    const ready = players.length === 2;
    const startButton = document.getElementById('btn-start-room');
    startButton.hidden = playerId !== hostId;
    startButton.disabled = !ready;
    startButton.textContent = ready ? 'INICIAR PARTIDA' : 'ESPERANDO JUGADOR';
    document.getElementById('room-ready-copy').textContent = ready
        ? 'Los dos jugadores están conectados. El anfitrión puede iniciar cuando quiera.'
        : 'Comparte el código; la sala admite dos jugadores.';
    setRoomStatus(ready ? 'SALA LISTA' : 'ESPERANDO JUGADOR', ready ? 'Conexión WebSocket activa. Duelo clásico en arena 24 × 16.' : 'Comparte el código para invitar a otro jugador.');
}

function renderMultiplayerScores(players = [], playerId = roomPlayerId, target = 'multiplayer-scoreboard') {
    const sorted = [...players].sort((left, right) => Number(right.alive) - Number(left.alive) || right.score - left.score);
    document.getElementById(target).innerHTML = sorted.map((player, index) => `
        <div class="multiplayer-score-row${player.id === playerId ? ' is-self' : ''}${player.alive === false ? ' is-out' : ''}"><strong class="multiplayer-rank">${String(index + 1).padStart(2, '0')}</strong><span class="multiplayer-score-avatar">${escapeMarkup(player.avatar)}</span><span class="multiplayer-score-name">${escapeMarkup(player.name)}${player.id === playerId ? '<small>TÚ</small>' : ''}</span><strong class="multiplayer-points">${Number(player.score) || 0}</strong></div>`).join('');
}

function formatRoomDuration(milliseconds = 0) {
    const seconds = Math.floor(Math.max(0, milliseconds) / 1000);
    return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}

let cancelRoomDeath = null;
let roomResultsShown = false;

function stopRoomDeath() {
    cancelRoomDeath?.();
    cancelRoomDeath = null;
}

// Defeat animation first; the results panel only appears once it has finished.
function showRoomOutcome(state) {
    if (roomResultsShown) {
        showRoomResults(state);
        return;
    }
    if (cancelRoomDeath) return;
    document.getElementById('multiplayer-results').hidden = true;
    document.getElementById('multiplayer-board-wrap').hidden = false;
    renderMultiplayerScores(state.players, roomPlayerId);
    cancelRoomDeath = playRoomDeath(document.getElementById('multiplayer-board'), state, () => {
        cancelRoomDeath = null;
        if (roomPlayerId !== null) showRoomResults(state);
    });
}

function showRoomResults(state) {
    roomResultsShown = true;
    const players = [...state.players].sort((left, right) => right.score - left.score);
    const winner = players.find(player => player.id === state.winnerId);
    document.getElementById('multiplayer-board-wrap').hidden = true;
    document.getElementById('room-players').hidden = true;
    document.getElementById('room-lobby-actions').hidden = true;
    document.getElementById('multiplayer-results').hidden = false;
    document.getElementById('multiplayer-result-title').textContent = winner ? `${winner.name.toLocaleUpperCase()} GANA` : 'EMPATE';
    document.getElementById('multiplayer-result-meta').textContent = `DUEL CLÁSICO · ARENA 24 × 16 · ${formatRoomDuration(state.durationMs)}`;
    renderMultiplayerScores(players, roomPlayerId, 'multiplayer-result-list');
    document.getElementById('btn-results-replay').hidden = roomPlayerId !== roomHostId;
    setRoomStatus('RONDA FINALIZADA', 'Resultado recibido del servidor. Puedes repetir o volver a la sala.');
}

const multiplayer = new MultiplayerClient({
    onStatus: (status, message) => {
        setRoomStatus(status, message, status === 'ERROR' || status === 'DESCONECTADO');
        if (status === 'DESCONECTADO') {
            stopRoomDeath();
            roomResultsShown = false;
            roomPlayerId = null;
            roomHostId = null;
            document.getElementById('room-code-display').hidden = true;
            document.getElementById('btn-copy-room').hidden = true;
            document.getElementById('btn-leave-room').hidden = true;
            document.getElementById('room-format').hidden = true;
            document.getElementById('room-lobby-actions').hidden = true;
            document.getElementById('room-players').hidden = false;
            document.getElementById('multiplayer-board-wrap').hidden = true;
            document.getElementById('multiplayer-results').hidden = true;
            refreshRoomPlayers([]);
        }
    },
    onMessage: message => {
        const isOutcome = message.type === 'room-update' && message.state?.status === 'gameover';
        if (!isOutcome) {
            stopRoomDeath();
            roomResultsShown = false;
        }
        if (message.type === 'room-created') {
            roomPlayerId = message.playerId;
            roomHostId = message.hostId;
            document.getElementById('room-code-display').hidden = false;
            document.getElementById('btn-copy-room').hidden = false;
            document.getElementById('room-code-display').textContent = message.roomCode;
            document.getElementById('btn-leave-room').hidden = false;
            showRoomLobby(message.players, roomPlayerId, roomHostId);
        } else if (message.type === 'room-lobby' || message.type === 'room-waiting') {
            roomPlayerId = message.playerId ?? roomPlayerId;
            roomHostId = message.hostId ?? roomHostId;
            document.getElementById('room-code-display').hidden = false;
            document.getElementById('btn-copy-room').hidden = false;
            document.getElementById('room-code-display').textContent = message.roomCode;
            document.getElementById('btn-leave-room').hidden = false;
            showRoomLobby(message.players, roomPlayerId, roomHostId);
        } else if (message.type === 'room-joined' || message.type === 'room-update') {
            roomPlayerId = message.playerId ?? roomPlayerId;
            roomHostId = message.hostId ?? roomHostId;
            document.getElementById('room-code-display').hidden = false;
            document.getElementById('btn-copy-room').hidden = false;
            document.getElementById('room-code-display').textContent = message.roomCode;
            document.getElementById('btn-leave-room').hidden = false;
            document.getElementById('room-format').hidden = false;
            document.getElementById('room-players').hidden = true;
            document.getElementById('room-lobby-actions').hidden = true;
            document.getElementById('multiplayer-board-wrap').hidden = !message.state;
            if (message.state) {
                if (message.state.status === 'gameover') {
                    showRoomOutcome(message.state);
                } else {
                    stopRoomDeath();
                    roomResultsShown = false;
                    document.getElementById('multiplayer-results').hidden = true;
                    document.getElementById('multiplayer-board-wrap').hidden = false;
                    document.getElementById('multiplayer-timer').textContent = formatRoomDuration(message.state.durationMs);
                    drawRoomSnapshot(document.getElementById('multiplayer-board'), message.state);
                    renderMultiplayerScores(message.state.players, roomPlayerId);
                    setRoomStatus('PARTIDA EN CURSO', 'Movimiento, colisiones y puntuación sincronizados en vivo.');
                }
            }
        } else if (message.type === 'room-error') {
            setRoomStatus('NO SE PUDO UNIR', message.message, true);
        } else if (message.type === 'room-closed') {
            setRoomStatus('SALA CERRADA', message.message, true);
            document.getElementById('multiplayer-board-wrap').hidden = true;
            document.getElementById('multiplayer-results').hidden = true;
        } else if (message.type === 'player-left') {
            multiplayer.leave();
            roomPlayerId = null;
            roomHostId = null;
            document.getElementById('room-code-display').hidden = true;
            document.getElementById('btn-copy-room').hidden = true;
            document.getElementById('btn-leave-room').hidden = true;
            document.getElementById('room-format').hidden = true;
            refreshRoomPlayers(message.players, roomPlayerId, roomHostId);
            setRoomStatus('JUGADOR DESCONECTADO', 'La sala se cerró porque la partida requiere dos jugadores.', true);
            document.getElementById('multiplayer-board-wrap').hidden = true;
            document.getElementById('multiplayer-results').hidden = true;
            document.getElementById('room-lobby-actions').hidden = true;
        }
    }
});

renderPalettes(document.getElementById('palette-list'));
renderDifficulties(document.getElementById('difficulty-list'));
renderSetup(document.getElementById('map-list'), document.getElementById('mode-list'));
renderSkinCards();
renderFoodCards(foodList);
game = createGame({
    audio,
    onHome: () => showScreen('customize'),
    onOpenOptions: () => { screenBeforeOptions = 'game'; showScreen('options'); },
    onStatisticsChanged: profile => updateStatistics(profile)
});

syncProfile();

document.getElementById('palette-list').addEventListener('click', event => {
    const option = event.target.closest('[data-palette]');
    if (option) {
        applyPalette(option.dataset.palette);
        savePreference('selectedTheme', option.dataset.palette);
        redrawCards(foodList);
        preview.draw();
    }
});
skinRoot.addEventListener('click', event => {
    const tab = event.target.closest('[data-universe]');
    if (tab) {
        showUniverse(tab.dataset.universe);
        return;
    }
    const card = event.target.closest('[data-skin]');
    if (!card) return;
    savePreference('selectedSkin', card.dataset.skin);
    refreshCustomize();
});
foodList.addEventListener('click', event => {
    const card = event.target.closest('[data-food]');
    if (!card) return;
    savePreference('selectedFoodSkin', card.dataset.food);
    refreshCustomize();
});
document.getElementById('difficulty-list').addEventListener('click', event => {
    const option = event.target.closest('[data-difficulty]');
    if (option) {
        applyDifficulty(option.dataset.difficulty);
        savePreference('difficulty', option.dataset.difficulty);
    }
});
document.getElementById('map-list').addEventListener('click', event => {
    const option = event.target.closest('[data-map]');
    if (option) {
        applyMap(option.dataset.map);
        savePreference('mapId', option.dataset.map);
    }
});
document.getElementById('mode-list').addEventListener('click', event => {
    const option = event.target.closest('[data-mode]');
    if (option && applyMode(option.dataset.mode)) savePreference('modeId', option.dataset.mode);
});

document.getElementById('toggle-sound').addEventListener('click', event => {
    const enabled = event.currentTarget.getAttribute('aria-checked') !== 'true';
    savePreference('soundEnabled', enabled);
    audio.setSoundEnabled(enabled);
    renderSettings(activeProfile());
});
document.getElementById('toggle-music').addEventListener('click', event => {
    const enabled = event.currentTarget.getAttribute('aria-checked') !== 'true';
    savePreference('musicEnabled', enabled);
    audio.setMusicEnabled(enabled);
    renderSettings(activeProfile());
});
document.getElementById('music-volume').addEventListener('input', event => {
    const volume = Number(event.currentTarget.value);
    savePreference('musicVolume', volume);
    audio.setMusicVolume(volume);
    document.getElementById('music-volume-value').value = `${Math.round(volume * 100)}%`;
});
document.getElementById('sound-volume').addEventListener('input', event => {
    const volume = Number(event.currentTarget.value);
    savePreference('soundVolume', volume);
    audio.setSoundVolume(volume);
    document.getElementById('sound-volume-value').value = `${Math.round(volume * 100)}%`;
});

document.getElementById('profile-form').addEventListener('submit', event => {
    event.preventDefault();
    const name = document.getElementById('profile-name-input').value.trim();
    if (!name) return;
    if (editingProfileId) {
        renamePlayerProfile(editingProfileId, name);
        selectPlayerProfile(editingProfileId);
        savePreference('avatar', selectedAvatar);
        editingProfileId = null;
    } else {
        createPlayerProfile({ name, avatar: selectedAvatar });
    }
    syncProfile();
    showScreen('customize');
});
document.getElementById('avatar-picker').addEventListener('click', event => {
    const avatar = event.target.closest('[data-avatar]');
    if (!avatar) return;
    selectedAvatar = avatar.dataset.avatar;
    renderAvatarPicker(document.getElementById('avatar-picker'), selectedAvatar);
});
document.getElementById('profile-list').addEventListener('click', event => {
    const select = event.target.closest('[data-select-profile]');
    const rename = event.target.closest('[data-rename-profile]');
    const remove = event.target.closest('[data-delete-profile]');
    if (select) {
        selectPlayerProfile(select.dataset.selectProfile);
        editingProfileId = null;
        syncProfile();
        showScreen('customize');
    } else if (rename) {
        openProfileEditor(rename.dataset.renameProfile);
    } else if (remove) {
        if (remove.dataset.confirm !== 'true') {
            remove.dataset.confirm = 'true';
            remove.textContent = 'CONFIRMAR';
            window.setTimeout(() => { remove.dataset.confirm = 'false'; remove.textContent = 'ELIMINAR'; }, 2500);
            return;
        }
        deletePlayerProfile(remove.dataset.deleteProfile);
        editingProfileId = null;
        renderProfiles();
        if (!getActivePlayerProfile()) showScreen('profile');
        else syncProfile();
    }
});
document.getElementById('btn-profile-cancel').addEventListener('click', () => {
    editingProfileId = null;
    renderProfiles();
});

document.getElementById('btn-create-room').addEventListener('click', () => {
    document.getElementById('room-code-display').hidden = true;
    document.getElementById('btn-copy-room').hidden = true;
    document.getElementById('multiplayer-board-wrap').hidden = true;
    const profile = activeProfile();
    multiplayer.createRoom({ name: profile.name, avatar: profile.avatar, skin: profile.selectedSkin });
});
document.getElementById('btn-multiplayer-back').addEventListener('click', () => {
    multiplayer.leave();
    roomPlayerId = null;
    roomHostId = null;
    document.getElementById('room-code-display').hidden = true;
    document.getElementById('btn-copy-room').hidden = true;
    document.getElementById('btn-leave-room').hidden = true;
    document.getElementById('room-format').hidden = true;
    document.getElementById('room-players').hidden = false;
    document.getElementById('room-lobby-actions').hidden = true;
    document.getElementById('multiplayer-board-wrap').hidden = true;
    document.getElementById('multiplayer-results').hidden = true;
    refreshRoomPlayers([]);
    setRoomStatus('DESCONECTADO', 'Has salido de la sala.');
    showScreen('customize');
});
document.getElementById('join-room-form').addEventListener('submit', event => {
    event.preventDefault();
    const profile = activeProfile();
    multiplayer.joinRoom(document.getElementById('room-code-input').value, { name: profile.name, avatar: profile.avatar, skin: profile.selectedSkin });
});
document.getElementById('btn-start-room').addEventListener('click', () => multiplayer.startRoom());
document.getElementById('btn-leave-room').addEventListener('click', () => {
    multiplayer.leave();
    document.getElementById('room-code-display').hidden = true;
    document.getElementById('btn-copy-room').hidden = true;
    document.getElementById('btn-leave-room').hidden = true;
    document.getElementById('multiplayer-board-wrap').hidden = true;
    document.getElementById('multiplayer-results').hidden = true;
    document.getElementById('room-format').hidden = true;
    document.getElementById('room-lobby-actions').hidden = true;
    document.getElementById('room-players').hidden = false;
    roomPlayerId = null;
    roomHostId = null;
    refreshRoomPlayers([]);
    setRoomStatus('DESCONECTADO', 'Has salido de la sala.');
});
document.getElementById('btn-results-replay').addEventListener('click', () => multiplayer.replayRoom());
document.getElementById('btn-results-lobby').addEventListener('click', () => multiplayer.returnToLobby());
document.getElementById('btn-results-menu').addEventListener('click', () => {
    multiplayer.leave();
    document.getElementById('btn-leave-room').hidden = true;
    document.getElementById('room-format').hidden = true;
    document.getElementById('multiplayer-results').hidden = true;
    document.getElementById('room-lobby-actions').hidden = true;
    showScreen('customize');
    setRoomStatus('DESCONECTADO', 'Has salido de la sala.');
});

const goToOptions = () => {
    screenBeforeOptions = currentScreen === 'options' ? screenBeforeOptions : currentScreen;
    showScreen('options');
};
document.getElementById('btn-options').addEventListener('click', goToOptions);
document.getElementById('btn-back').addEventListener('click', () => showScreen(screenBeforeOptions));
document.getElementById('btn-profile').addEventListener('click', () => { renderProfiles(); showScreen('profile'); });
document.getElementById('btn-profile-back').addEventListener('click', () => showScreen('customize'));
document.getElementById('btn-multiplayer').addEventListener('click', () => showScreen('multiplayer'));
document.getElementById('btn-game-settings').addEventListener('click', () => showScreen('setup'));
document.getElementById('btn-setup-back').addEventListener('click', () => showScreen('customize'));

function startGame() {
    if (!isModeAvailable(readModeId(), readMapId())) {
        showScreen('setup');
        return;
    }
    showScreen('game');
    game.start();
}
document.getElementById('btn-play').addEventListener('click', startGame);
document.getElementById('btn-confirm-play').addEventListener('click', startGame);
document.querySelectorAll('[data-multiplayer-direction]').forEach(button => button.addEventListener('pointerdown', event => {
    event.preventDefault();
    const directions = { up: { x: 0, y: -1 }, down: { x: 0, y: 1 }, left: { x: -1, y: 0 }, right: { x: 1, y: 0 } };
    multiplayer.setDirection(directions[button.dataset.multiplayerDirection]);
}));
document.addEventListener('keydown', event => {
    if (!document.getElementById('screen-multiplayer').classList.contains('is-active')) return;
    if (event.target.closest?.('input, textarea')) return;
    const directions = { ArrowUp: 'up', w: 'up', ArrowDown: 'down', s: 'down', ArrowLeft: 'left', a: 'left', ArrowRight: 'right', d: 'right' };
    const direction = directions[event.key] ?? directions[event.key.toLowerCase()];
    if (direction) {
        event.preventDefault();
        const vector = { up: { x: 0, y: -1 }, down: { x: 0, y: 1 }, left: { x: -1, y: 0 }, right: { x: 1, y: 0 } }[direction];
        multiplayer.setDirection(vector);
    }
});
document.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button) return;
    audio.unlock();
    const sound = button.hasAttribute('data-map') ? 'map'
        : button.hasAttribute('data-mode') ? 'mode'
            : button.hasAttribute('data-palette') || button.hasAttribute('data-avatar') || button.hasAttribute('data-skin') || button.hasAttribute('data-food') ? 'select' : 'button';
    audio.playSound(sound);
});

showScreen('customize');

window.addEventListener('pagehide', () => {
    game.stop();
    audio.stopMusic();
    multiplayer.leave();
});
document.getElementById('btn-copy-room').addEventListener('click', async () => {
    const code = document.getElementById('room-code-display').textContent;
    try {
        await navigator.clipboard.writeText(code);
        setRoomStatus('CÓDIGO COPIADO', 'Comparte el código con la otra persona.');
    } catch {
        setRoomStatus('CÓDIGO DE SALA', `Comparte manualmente: ${code}`);
    }
});