export const palettes = [
    { id: 'cyber', name: 'Cyberpunk', code: '01 / NIGHT CITY', colors: ['#101521', '#1c2637', '#c1ff57', '#fa6685'] },
    { id: 'ocean', name: 'Océano', code: '02 / TIDAL', colors: ['#0d1c22', '#142830', '#68d9cd', '#ffad72'] },
    { id: 'nature', name: 'Bosque', code: '03 / BOTANICAL', colors: ['#102019', '#182b20', '#a9d887', '#f2a06b'] },
    { id: 'fire', name: 'Fuego', code: '04 / EMBER', colors: ['#211411', '#30201a', '#ff9861', '#f7d46a'] },
    { id: 'neon', name: 'Neón', code: '05 / AFTERGLOW', colors: ['#1d1420', '#2b1d30', '#f29ad7', '#b8ec75'] },
    { id: 'space', name: 'Espacial', code: '06 / DEEP ORBIT', colors: ['#101327', '#1d2242', '#88aaff', '#ff9bd8'] },
    { id: 'retro', name: 'Retro', code: '07 / 8-BIT', colors: ['#201b16', '#383027', '#f4c95d', '#e8795c'] },
    { id: 'dark', name: 'Oscura', code: '08 / MONO', colors: ['#141618', '#202326', '#d2d5cc', '#ef967e'] }
];