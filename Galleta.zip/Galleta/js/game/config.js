export const difficultySettings = {
    easy: { id: 'easy', label: 'Fácil', startMs: 190, speedStepMs: 1, minMs: 130 },
    normal: { id: 'normal', label: 'Normal', startMs: 135, speedStepMs: 3, minMs: 65 },
    hard: { id: 'hard', label: 'Difícil', startMs: 92, speedStepMs: 4, minMs: 48 }
};

export const mapDefinitions = {
    small: { id: 'small', label: 'Pequeño', width: 14, height: 14, walls: 'solid', obstacles: [] },
    normal: { id: 'normal', label: 'Normal', width: 20, height: 20, walls: 'solid', obstacles: [] },
    large: { id: 'large', label: 'Grande', width: 30, height: 30, walls: 'solid', obstacles: [] },
    randomWalls: { id: 'randomWalls', label: 'Paredes aleatorias', width: 24, height: 24, walls: 'solid', obstacleStyle: 'random', obstacles: [] },
    maze: { id: 'maze', label: 'Laberinto', width: 31, height: 31, walls: 'solid', obstacleStyle: 'maze', obstacles: [] },
    islands: { id: 'islands', label: 'Islas', width: 30, height: 30, walls: 'solid', obstacleStyle: 'islands', obstacles: [] },
    corridors: { id: 'corridors', label: 'Corredores', width: 28, height: 24, walls: 'solid', obstacleStyle: 'corridors', obstacles: [] },
    portals: { id: 'portals', label: 'Portales', width: 24, height: 24, walls: 'solid', portals: [{ x: 3, y: 3 }, { x: 20, y: 20 }], obstacles: [] },
    closed: { id: 'closed', label: 'Cerrado', width: 20, height: 20, walls: 'solid', obstacles: [] },
    obstacleCourse: { id: 'obstacleCourse', label: 'Obstáculos', width: 20, height: 20, walls: 'solid', obstacles: [] }
};

export const gameModes = {
    classic: { id: 'classic', label: 'Clásico', description: 'Crece y suma puntos. No choques.', scorePerFood: 10 },
    timeAttack: { id: 'timeAttack', label: 'Contrarreloj', description: 'Consigue tantos puntos como puedas en 60 segundos.', durationMs: 60000, scorePerFood: 10 },
    survival: { id: 'survival', label: 'Supervivencia', description: 'La velocidad aumenta con cada bocado.', startMs: 150, speedStepMs: 7, minMs: 54, scorePerFood: 12 },
    hardcore: { id: 'hardcore', label: 'Hardcore', description: 'Empieza rápido y acelera sin piedad.', requiresMap: 'large', startMs: 75, speedStepMs: 7, minMs: 30, scorePerFood: 15 },
    chaos: { id: 'chaos', label: 'Caos', description: 'Aparecen muros y la comida no espera.', requiresMap: 'large', startMs: 115, speedStepMs: 5, minMs: 38, scorePerFood: 14, obstacleRate: 0.075, foodLifetimeMs: 9000, eventIntervalMs: 9500 },
    extremeSurvival: { id: 'extremeSurvival', label: 'Supervivencia extrema', description: 'Velocidad brutal, muros y eventos dinámicos.', requiresMap: 'large', startMs: 82, speedStepMs: 8, minMs: 28, scorePerFood: 16, obstacleRate: 0.06, eventIntervalMs: 8000 },
    speedExtreme: { id: 'speedExtreme', label: 'Velocidad extrema', description: 'Reacción inmediata. Cada bocado te acelera.', requiresMap: 'large', startMs: 52, speedStepMs: 5, minMs: 22, scorePerFood: 12 },
    puzzle: { id: 'puzzle', label: 'Puzzle', description: 'Encuentra comida entre pasillos conectados.', requiresMap: 'maze', targetScore: 80, scorePerFood: 10 },
    flood: { id: 'flood', label: 'Inundación', description: 'El agua cierra anillos desde el borde hacia dentro.', requiresMap: 'large', startMs: 125, speedStepMs: 4, minMs: 48, scorePerFood: 13, eventIntervalMs: 8000, eventKind: 'flood' },
    portalRun: { id: 'portalRun', label: 'Portales', description: 'Cruza un portal para reaparecer en su pareja.', requiresMap: 'portals', startMs: 120, speedStepMs: 4, minMs: 48, scorePerFood: 12, portals: true },
    lava: { id: 'lava', label: 'Lava', description: 'Puntos calientes cubren el mapa progresivamente.', requiresMap: 'large', startMs: 108, speedStepMs: 6, minMs: 35, scorePerFood: 14, eventIntervalMs: 6500, eventKind: 'lava' },
    bombs: { id: 'bombs', label: 'Bombas', description: 'Evita cargas temporales antes de que detonen.', requiresMap: 'large', startMs: 115, speedStepMs: 5, minMs: 38, scorePerFood: 14, eventIntervalMs: 5500, eventKind: 'bombs', bombFuseMs: 4200 },
    labyrinth: { id: 'labyrinth', label: 'Laberinto', description: 'Sobrevive en un laberinto nuevo en cada partida.', requiresMap: 'maze', startMs: 105, speedStepMs: 5, minMs: 40, scorePerFood: 15 }
};

const isNearSpawn = (position, snake) => snake.some(segment =>
    Math.abs(position.x - segment.x) <= 3 && Math.abs(position.y - segment.y) <= 3
);

export function createMap(mapId, snake = [], { obstacleCount = null } = {}) {
    const template = mapDefinitions[mapId] ?? mapDefinitions.normal;
    const map = { ...template, obstacles: [...template.obstacles] };
    if (map.obstacleStyle === 'maze') return createMaze(map, snake);
    if (map.obstacleStyle === 'islands') return createIslands(map, snake);
    if (map.obstacleStyle === 'corridors') return createCorridors(map, snake);
    if (map.obstacleStyle !== 'random' && obstacleCount === null) return map;

    const occupied = new Set(snake.map(segment => `${segment.x},${segment.y}`));
    const targetWalls = obstacleCount ?? Math.floor(map.width * map.height * 0.055);
    let attempts = 0;
    while (map.obstacles.length < targetWalls && attempts < targetWalls * 24) {
        attempts += 1;
        const horizontal = Math.random() < 0.5;
        const length = 2 + Math.floor(Math.random() * 3);
        const xSpan = map.width - (horizontal ? length : 1) - 2;
        const ySpan = map.height - (horizontal ? 1 : length) - 2;
        const x = 1 + Math.floor(Math.random() * xSpan);
        const y = 1 + Math.floor(Math.random() * ySpan);
        const wall = Array.from({ length }, (_, index) => ({ x: x + (horizontal ? index : 0), y: y + (horizontal ? 0 : index) }));
        if (wall.some(tile => isNearSpawn(tile, snake) || occupied.has(`${tile.x},${tile.y}`))) continue;
        wall.forEach(tile => occupied.add(`${tile.x},${tile.y}`));
        map.obstacles.push(...wall);
    }
    return map;
}

function createMaze(map, snake) {
    const obstacles = new Set();
    for (let y = 1; y < map.height - 1; y += 1) {
        for (let x = 1; x < map.width - 1; x += 1) obstacles.add(`${x},${y}`);
    }
    const clear = (x, y) => obstacles.delete(`${x},${y}`);
    snake.forEach(segment => clear(segment.x, segment.y));
    clear(snake[0].x + 1, snake[0].y);
    if (snake[0].x + 2 < map.width - 1) clear(snake[0].x + 2, snake[0].y);
    const visited = new Set(snake.map(segment => `${segment.x},${segment.y}`));
    const stack = [snake[0]];
    while (stack.length) {
        const current = stack[stack.length - 1];
        const choices = [
            { x: current.x + 2, y: current.y, wall: { x: current.x + 1, y: current.y } },
            { x: current.x - 2, y: current.y, wall: { x: current.x - 1, y: current.y } },
            { x: current.x, y: current.y + 2, wall: { x: current.x, y: current.y + 1 } },
            { x: current.x, y: current.y - 2, wall: { x: current.x, y: current.y - 1 } }
        ].filter(tile => tile.x > 0 && tile.y > 0 && tile.x < map.width - 1 && tile.y < map.height - 1 && !visited.has(`${tile.x},${tile.y}`));
        if (!choices.length) {
            stack.pop();
            continue;
        }
        const next = choices[Math.floor(Math.random() * choices.length)];
        clear(next.wall.x, next.wall.y);
        clear(next.x, next.y);
        visited.add(`${next.x},${next.y}`);
        stack.push({ x: next.x, y: next.y });
    }
    map.obstacles = [...obstacles].map(value => {
        const [x, y] = value.split(',').map(Number);
        return { x, y };
    });
    return map;
}

function createIslands(map, snake) {
    for (let x = 5; x < map.width - 2; x += 7) {
        const gap = 3 + Math.floor(Math.random() * (map.height - 6));
        for (let y = 1; y < map.height - 1; y += 1) {
            if (Math.abs(y - gap) <= 1 || isNearSpawn({ x, y }, snake)) continue;
            map.obstacles.push({ x, y });
        }
    }
    return map;
}

function createCorridors(map, snake) {
    for (let x = 4; x < map.width - 2; x += 5) {
        const gap = 2 + Math.floor(Math.random() * (map.height - 4));
        for (let y = 1; y < map.height - 1; y += 1) {
            if (Math.abs(y - gap) <= 1 || isNearSpawn({ x, y }, snake)) continue;
            map.obstacles.push({ x, y });
        }
    }
    return map;
}

export function isModeAvailable(modeId, mapId) {
    const mode = gameModes[modeId];
    return Boolean(mode && (!mode.requiresMap || mode.requiresMap === mapId));
}

export function findReachableTiles(start, map, mode = {}) {
    const visited = new Set([`${start.x},${start.y}`]);
    const queue = [start];
    for (let index = 0; index < queue.length; index += 1) {
        const current = queue[index];
        for (const direction of [{ x: 1, y: 0 }, { x: -1, y: 0 }, { x: 0, y: 1 }, { x: 0, y: -1 }]) {
            const next = { x: current.x + direction.x, y: current.y + direction.y };
            const key = `${next.x},${next.y}`;
            if (visited.has(key) || isBlockedByMap(next, map, mode)) continue;
            visited.add(key);
            queue.push(next);
        }
    }
    return queue;
}

export function isBlockedByMap(position, map, mode = {}) {
    const outside = position.x < 0 || position.y < 0 || position.x >= map.width || position.y >= map.height;
    if (outside && (mode.wraps || map.walls === 'wrap')) return false;
    if (outside) return true;
    return map.obstacles.some(tile => tile.x === position.x && tile.y === position.y);
}

export function wrapPosition(position, map, mode = {}) {
    if (mode.portals && map.portals?.length > 1) {
        const portalIndex = map.portals.findIndex(portal => portal.x === position.x && portal.y === position.y);
        if (portalIndex >= 0) return { ...map.portals[(portalIndex + 1) % map.portals.length] };
    }
    if (!mode.wraps && map.walls !== 'wrap') return position;
    return { x: (position.x + map.width) % map.width, y: (position.y + map.height) % map.height };
}