/*
 * Snake skins are pure data: the renderer in rendering/snake-renderer.js reads them.
 * Color strings accept hex values or the theme tokens "accent", "accent+N" (lighter) and "accent-N" (darker).
 * To add a skin, append an entry here; `pattern.type` and `head.front/back` pick existing painters.
 */
import { heroSkins } from './hero-skins.js';

const originalSkins = [
    {
        id: 'classic', name: 'Clásica', note: 'Limpia y reconocible', width: 0.78, alpha: 1,
        outline: 'accent-65', outlineWidth: 0.06,
        gradient: ['accent+16', 'accent', 'accent-20'],
        pattern: { type: 'dorsal', dark: 'accent-35', light: 'accent+45' },
        head: { shape: 'blob', fill: ['accent+22', 'accent-2'], front: ['gloss'], tongue: true, eye: { style: 'round' } }
    },
    {
        id: 'neon', name: 'Neón', note: 'Luz de otro mundo', width: 0.74, alpha: 1,
        outline: '#4cf8db', outlineWidth: 0.075,
        gradient: ['#0c3f46', '#082e38', '#061f2a'],
        glow: { color: '#4cf8db', alpha: 0.55, pulse: true },
        pattern: { type: 'rim' },
        head: { shape: 'blob', fill: ['#14606a', '#0a3a44'], front: ['rim'], eye: { style: 'round', white: '#eafffb', glow: '#4cf8db' } }
    },
    {
        id: 'fire', name: 'Fuego', note: 'Calor vivo', width: 0.78, alpha: 1,
        outline: '#3a0d05', outlineWidth: 0.06,
        gradient: ['#ffd35a', '#ff8a2a', '#e0401c', '#7a1608'],
        glow: { color: '#ff6a2a', alpha: 0.45, pulse: true },
        pattern: { type: 'flames' },
        head: { shape: 'blob', fill: ['#ffe08a', '#ff8a2a'], back: 'crest', eye: { style: 'slit', white: '#fff6c9', pupil: '#3a0d05' } }
    },
    {
        id: 'ice', name: 'Hielo', note: 'Cristal congelado', width: 0.78, alpha: 1,
        outline: '#0f3d63', outlineWidth: 0.06,
        gradient: ['#f2ffff', '#a4ecff', '#52bdee', '#2f7fc8'],
        glow: { color: '#8fe6ff', alpha: 0.35 },
        pattern: { type: 'facets' },
        head: { shape: 'crystal', fill: ['#ffffff', '#7fd8f7'], front: ['facets'], eye: { style: 'round', white: '#ffffff', pupil: '#0f3d63' } }
    },
    {
        id: 'plasma', name: 'Plasma', note: 'Energía en movimiento', width: 0.78, alpha: 1, scroll: 0.00016,
        outline: '#1d0a40', outlineWidth: 0.06,
        gradient: ['#ff5ad9', '#a682ff', '#4fd2ff', '#a682ff', '#ff5ad9'],
        glow: { color: '#a682ff', alpha: 0.6, pulse: true },
        pattern: { type: 'arcs' },
        head: { shape: 'blob', fill: ['#ffffff', '#b79cff'], front: ['bolts'], eye: { style: 'round', white: '#fff', pupil: '#2b0f66', glow: '#d9c8ff' } }
    },
    {
        id: 'cyber', name: 'Cyber', note: 'Circuito activo', width: 0.78, alpha: 1,
        outline: '#071014', outlineWidth: 0.06,
        gradient: ['#4a6a78', '#31505c', '#1f3640', '#16262e'],
        glow: { color: '#48dfdc', alpha: 0.25 },
        pattern: { type: 'plates', color: '#48dfdc' },
        head: { shape: 'wedge', fill: ['#5f8494', '#2a444f'], outline: '#071014', front: ['gloss'], eye: { style: 'visor', glow: '#48dfdc' } }
    },
    {
        id: 'ghost', name: 'Fantasma', note: 'Casi invisible', width: 0.8, alpha: 0.7,
        outline: '#8fc4e6', outlineWidth: 0.05,
        gradient: ['#ffffff', '#d6f0ff', '#a9d6f5'],
        glow: { color: '#c8e9ff', alpha: 0.4, pulse: true },
        pattern: { type: 'wisps' },
        head: { shape: 'blob', fill: ['#ffffff', '#cfeaff'], outline: '#8fc4e6', eye: { style: 'round', white: '#35506b', pupil: '#0a1622', size: 0.1 } }
    },
    {
        id: 'gold', name: 'Dorada', note: 'Brillo de realeza', width: 0.78, alpha: 1,
        outline: '#5a3a05', outlineWidth: 0.06,
        gradient: ['#fff3b0', '#f7ca4b', '#d9a21b', '#9a6a08'],
        glow: { color: '#ffd34d', alpha: 0.3 },
        pattern: { type: 'rings' },
        head: { shape: 'blob', fill: ['#fff7c4', '#e7b432'], front: ['crown', 'gloss'], eye: { style: 'slit', white: '#fffbe0', pupil: '#3d2503' } }
    },
    {
        id: 'galaxy', name: 'Galaxia', note: 'Polvo de estrellas', width: 0.78, alpha: 1,
        outline: '#0a0626', outlineWidth: 0.06,
        gradient: ['#7c6bff', '#c14bd9', '#3b2bb0', '#1a1058'],
        glow: { color: '#a28cff', alpha: 0.5, pulse: true },
        pattern: { type: 'stars' },
        head: { shape: 'blob', fill: ['#9b8cff', '#2b1a78'], front: ['stars'], eye: { style: 'round', white: '#f3ddff', pupil: '#14093f', glow: '#c9b8ff' } }
    },
    {
        id: 'lava', name: 'Lava', note: 'Roca incandescente', width: 0.8, alpha: 1,
        outline: '#0d0402', outlineWidth: 0.06,
        gradient: ['#4a2118', '#341611', '#24100c', '#1a0a07'],
        glow: { color: '#ff4a1a', alpha: 0.35, pulse: true },
        pattern: { type: 'cracks' },
        head: { shape: 'blob', fill: ['#5a2a1e', '#2a120d'], back: 'horns', front: ['cracks'], eye: { style: 'slit', white: '#ffd34f', pupil: '#2a0a00', glow: '#ff7a1a' } }
    }
];

export const snakeSkins = [...originalSkins.map(skin => ({ universe: 'original', ...skin })), ...heroSkins];

export const skinUniverses = [
    { id: 'original', name: 'Originales' },
    { id: 'marvel', name: 'Marvel' },
    { id: 'dc', name: 'DC Comics' }
];

export function getSkin(id) {
    const normalizedId = String(id ?? '').replace(/^snake_/, '');
    return snakeSkins.find(candidate => candidate.id === normalizedId) ?? snakeSkins[0];
}
