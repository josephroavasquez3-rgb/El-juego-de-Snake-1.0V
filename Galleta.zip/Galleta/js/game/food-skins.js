export const foodSkins = [
    { id: 'food_berry', name: 'Baya', note: 'Del color de tu tema', particle: 'theme-food' },
    { id: 'food_apple', name: 'Manzana', note: 'Roja y crujiente', particle: '#f04c48' },
    { id: 'food_orange', name: 'Naranja', note: 'Cítrica y brillante', particle: '#ff9e36' },
    { id: 'food_strawberry', name: 'Fresa', note: 'Dulce con semillas', particle: '#f45d80' },
    { id: 'food_cherries', name: 'Cerezas', note: 'Un par de caprichos', particle: '#df3356' },
    { id: 'food_watermelon', name: 'Sandía', note: 'Fresca y jugosa', particle: '#f76f63' },
    { id: 'food_burger', name: 'Hamburguesa', note: 'Capas de sabor', particle: '#d79a4a' },
    { id: 'food_crystal', name: 'Cristal', note: 'Energía pura', particle: '#72dcff' },
    { id: 'food_coin', name: 'Moneda', note: 'Brillo de oro', particle: '#ffd34d' },
    { id: 'food_golden', name: 'Manzana dorada', note: 'Legendaria', particle: '#ffe36e' }
];

export function getFoodSkin(id) {
    return foodSkins.find(skin => skin.id === id) ?? foodSkins[0];
}
