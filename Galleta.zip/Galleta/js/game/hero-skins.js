/*
 * Hero skins (Marvel / DC). Same data model as the original skins plus `universe`, `patterns`
 * (a list of painters from rendering/hero-parts.js) and richer `head` options. These are
 * original stylized designs inspired by each character's colors and gear; adding a character
 * only needs a new entry here.
 */
const marvel = 'marvel';
const dc = 'dc';

export const heroSkins = [
    {
        id: 'spiderman', universe: marvel, name: 'Spider-Man', note: 'Telaraña roja y azul', width: 0.78, alpha: 1,
        outline: '#1c0509', outlineWidth: 0.06,
        gradient: ['#ea2733', '#cf1f2c', '#a8131f'],
        patterns: [
            { type: 'band', offset: 0.75, width: 0.46, color: '#1f4fd6' },
            { type: 'band', offset: -0.75, width: 0.46, color: '#1f4fd6' },
            { type: 'web' },
            { type: 'emblem', shape: 'spider', at: [1.3], size: 0.8 }
        ],
        head: { shape: 'blob', fill: ['#ff4450', '#cf1f2c'], front: ['gloss', 'web'], eye: { style: 'lens' } }
    },
    {
        id: 'ironman', universe: marvel, name: 'Iron Man', note: 'Armadura y reactor', width: 0.8, alpha: 1,
        outline: '#3a0b0d', outlineWidth: 0.06,
        gradient: ['#f2323d', '#cb2029', '#8f121b'],
        glow: { color: '#8fe8ff', alpha: 0.2, pulse: true },
        patterns: [
            { type: 'band', offset: 0.82, width: 0.34, color: '#ffd44a' },
            { type: 'band', offset: -0.82, width: 0.34, color: '#ffd44a' },
            { type: 'armor', seam: '#ffd44a', seamAlpha: 0.85, shine: '#ffffff', rivet: '#fff0a8', insert: '#ffd44a' },
            { type: 'emblem', shape: 'reactor', at: [1.35], size: 0.8 }
        ],
        head: { shape: 'helmet', fill: ['#ee3640', '#b01c25'], front: [{ type: 'faceplate' }], eye: { style: 'angled', white: '#e9fcff', glow: '#8fe8ff' } }
    },
    {
        id: 'captain', universe: marvel, name: 'Capitán América', note: 'Estrellas y franjas', width: 0.78, alpha: 1,
        outline: '#07123a', outlineWidth: 0.06,
        gradient: ['#3166d8', '#2250b2', '#183f8d'],
        patterns: [
            { type: 'band', offset: 0.5, width: 0.16, color: '#d3202b' },
            { type: 'band', offset: 0.67, width: 0.16, color: '#f6f6f6' },
            { type: 'band', offset: 0.84, width: 0.14, color: '#d3202b' },
            { type: 'band', offset: -0.5, width: 0.16, color: '#d3202b' },
            { type: 'band', offset: -0.67, width: 0.16, color: '#f6f6f6' },
            { type: 'band', offset: -0.84, width: 0.14, color: '#d3202b' },
            { type: 'glyph', shape: 'star', spacing: 0.7, size: 0.13, color: '#ffffff' },
            { type: 'emblem', shape: 'shield', at: [1.35], size: 0.82 }
        ],
        head: { shape: 'blob', fill: ['#3d73e0', '#1f4aa8'], back: [{ type: 'wings', color: '#f4f4f4' }], front: ['gloss', { type: 'star' }], eye: { style: 'round', pupil: '#17428f' } }
    },
    {
        id: 'thor', universe: marvel, name: 'Thor', note: 'Acero, capa y rayos', width: 0.8, alpha: 1,
        outline: '#17202e', outlineWidth: 0.06,
        gradient: ['#dbe9fa', '#93b2db', '#5c80b4'],
        glow: { color: '#7fd6ff', alpha: 0.24, pulse: true },
        patterns: [
            { type: 'band', offset: 0.84, width: 0.3, color: '#d42a30' },
            { type: 'band', offset: -0.84, width: 0.3, color: '#d42a30' },
            { type: 'discs' },
            { type: 'sparks', color: '#a8e6ff' }
        ],
        head: { shape: 'blob', fill: ['#f6f9fc', '#93a8bf'], back: [{ type: 'wings', color: '#dfe8f2' }], front: ['gloss', 'bolts'], eye: { style: 'round', pupil: '#2a6fd0' } }
    },
    {
        id: 'panther', universe: marvel, name: 'Black Panther', note: 'Pantera de vibranium', width: 0.76, alpha: 1,
        outline: '#030206', outlineWidth: 0.06,
        gradient: ['#1d1928', '#14111d', '#0d0b14'],
        glow: { color: '#a15bff', alpha: 0.38, pulse: true },
        patterns: [
            { type: 'line', offset: 0.84, width: 0.035, color: '#b98aff', glow: true, pulse: true },
            { type: 'line', offset: -0.84, width: 0.035, color: '#b98aff', glow: true, pulse: true },
            { type: 'chevrons', color: '#a86bff' }
        ],
        head: { shape: 'cowl', fill: ['#2b2538', '#0f0d17'], back: [{ type: 'ears', color: '#17131f', tipX: -0.12, tipY: 0.66 }], front: [{ type: 'lines', color: '#b98aff' }], eye: { style: 'angled', white: '#f1e6ff', glow: '#b98aff' } }
    },
    {
        id: 'deadpool', universe: marvel, name: 'Deadpool', note: 'Rojo, negro y sarcasmo', width: 0.78, alpha: 1,
        outline: '#120204', outlineWidth: 0.06,
        gradient: ['#da2730', '#bb1a22', '#8e1017'],
        patterns: [
            { type: 'band', offset: 0.5, width: 1, color: '#14090c' },
            { type: 'line', offset: 0.5, width: 0.03, color: '#da2730', dash: [0.12, 0.1], alpha: 0.9 },
            { type: 'line', offset: 0, width: 0.04, color: '#14090c', alpha: 0.9 },
            { type: 'glyph', shape: 'dot', spacing: 0.7, offset: -0.5, size: 0.1, color: '#14090c', alpha: 0.8, alternate: false }
        ],
        head: { shape: 'blob', fill: ['#e8333b', '#bb1a22'], front: [{ type: 'half', color: '#14090c' }, 'gloss'], eye: { style: 'patch', patch: '#0a0306', white: '#ffffff' } }
    },
    {
        id: 'hulk', universe: marvel, name: 'Hulk', note: 'Fuerza bruta verde', width: 0.84, alpha: 1,
        gradientAnchor: 'tail', gradientSpan: 6,
        outline: '#0d330c', outlineWidth: 0.06,
        gradient: ['#4fd043', '#3cb135', '#35a62e', '#6c3fb4', '#6c3fb4'],
        patterns: [
            { type: 'band', offset: -0.2, width: 0.3, color: '#a5f598', alpha: 0.3 },
            { type: 'muscle' }
        ],
        head: { shape: 'blob', fill: ['#62dd55', '#349f2d'], back: [{ type: 'hair', color: '#1d2a17', smooth: true }], front: ['gloss'], eye: { style: 'angry' } }
    },
    {
        id: 'wolverine', universe: marvel, name: 'Wolverine', note: 'Garras y traje clásico', width: 0.78, alpha: 1,
        outline: '#16110a', outlineWidth: 0.06,
        gradient: ['#ffd81f', '#f6bb00', '#dc9c00'],
        patterns: [
            { type: 'band', offset: 0.72, width: 0.52, color: '#2158cf' },
            { type: 'band', offset: -0.72, width: 0.52, color: '#2158cf' },
            { type: 'claws' },
            { type: 'line', offset: 0, width: 0.035, color: '#16110a', alpha: 0.7 }
        ],
        head: { shape: 'cowl', fill: ['#2f66dc', '#173d9c'], back: [{ type: 'ears', color: '#1d4cc0', tipX: -0.5, tipY: 0.6 }], front: ['gloss'], eye: { style: 'angled', white: '#ffffff' } }
    },
    {
        id: 'batman', universe: dc, name: 'Batman', note: 'Caballero de la noche', width: 0.78, alpha: 1,
        outline: '#030304', outlineWidth: 0.06,
        gradient: ['#626c78', '#454d58', '#2a3038'],
        patterns: [
            { type: 'band', offset: 0.78, width: 0.4, color: '#0b0c10' },
            { type: 'band', offset: -0.78, width: 0.4, color: '#0b0c10' },
            { type: 'line', offset: 0.88, width: 0.03, color: '#ffd21f', alpha: 0.85 },
            { type: 'line', offset: -0.88, width: 0.03, color: '#ffd21f', alpha: 0.85 },
            { type: 'armor', seam: '#0b0c10', spacing: 0.6, seamAlpha: 0.6, shine: '#ffffff' },
            { type: 'glyph', shape: 'diamond', spacing: 1.2, size: 0.09, color: '#ffd21f', every: 1 },
            { type: 'emblem', shape: 'bat', at: [1.35], size: 0.9 }
        ],
        head: { shape: 'cowl', fill: ['#464e5a', '#1b1e24'], back: [{ type: 'ears', color: '#14161b', tipX: -0.3, tipY: 0.84 }], front: ['gloss'], eye: { style: 'angled', white: '#ffffff' } }
    },
    {
        id: 'superman', universe: dc, name: 'Superman', note: 'Símbolo de esperanza', width: 0.8, alpha: 1,
        gradientAnchor: 'tail', gradientSpan: 4,
        outline: '#08153f', outlineWidth: 0.06,
        gradient: ['#2168e0', '#1b55c4', '#1b55c4', '#d1222c'],
        patterns: [
            { type: 'band', offset: 0.82, width: 0.3, color: '#d1222c' },
            { type: 'band', offset: -0.82, width: 0.3, color: '#d1222c' },
            { type: 'emblem', shape: 'superman', at: [1.35], size: 0.9 }
        ],
        head: { shape: 'blob', fill: ['#ffe0c2', '#eab890'], front: [{ type: 'curl' }], eye: { style: 'round', pupil: '#1a5fd0' } }
    },
    {
        id: 'wonder', universe: dc, name: 'Wonder Woman', note: 'Oro, rojo y estrellas', width: 0.78, alpha: 1,
        gradientAnchor: 'tail', gradientSpan: 7,
        outline: '#3a0a10', outlineWidth: 0.06,
        gradient: ['#dc2a33', '#c9232b', '#c9232b', '#1f3fa8'],
        patterns: [
            { type: 'band', offset: 0.84, width: 0.22, color: '#ffd34d' },
            { type: 'band', offset: -0.84, width: 0.22, color: '#ffd34d' },
            { type: 'armor', seam: '#ffd34d', seamAlpha: 0.75, spacing: 0.6 },
            { type: 'glyph', shape: 'star', spacing: 0.5, size: 0.1, color: '#ffffff', tail: 2.8 },
            { type: 'emblem', shape: 'ww', at: [1.35], size: 0.85 }
        ],
        head: { shape: 'blob', fill: ['#ffe0c2', '#eab890'], back: [{ type: 'hair', color: '#1a1410', smooth: true }], front: [{ type: 'tiara' }], eye: { style: 'round', pupil: '#2a6fd0' } }
    },
    {
        id: 'flash', universe: dc, name: 'Flash', note: 'Rayos a toda velocidad', width: 0.76, alpha: 1,
        outline: '#2a0508', outlineWidth: 0.06,
        gradient: ['#f13335', '#d6232a', '#a51319'],
        glow: { color: '#ffd23a', alpha: 0.26, pulse: true },
        patterns: [
            { type: 'line', offset: 0.88, width: 0.04, color: '#ffd23a', alpha: 0.9 },
            { type: 'line', offset: -0.88, width: 0.04, color: '#ffd23a', alpha: 0.9 },
            { type: 'bolt', color: '#ffd23a' },
            { type: 'trail', color: '#ffe680' }
        ],
        head: { shape: 'cowl', fill: ['#ff4c4c', '#c8191f'], back: [{ type: 'wings', color: '#f4f4f4' }], front: ['boltmark'], eye: { style: 'angled', white: '#ffffff' } }
    },
    {
        id: 'lantern', universe: dc, name: 'Linterna Verde', note: 'Voluntad hecha energía', width: 0.78, alpha: 1,
        outline: '#020a05', outlineWidth: 0.06,
        gradient: ['#122e1a', '#0d2214', '#08150c'],
        glow: { color: '#35f06a', alpha: 0.5, pulse: true },
        patterns: [
            { type: 'band', offset: 0, width: 0.2, color: '#35f06a', alpha: 0.55, pulse: true },
            { type: 'line', offset: 0.88, width: 0.035, color: '#35f06a', glow: true, alpha: 0.9 },
            { type: 'line', offset: -0.88, width: 0.035, color: '#35f06a', glow: true, alpha: 0.9 },
            { type: 'hex', color: '#59ff8c' },
            { type: 'emblem', shape: 'lantern', at: [1.35], size: 0.8 }
        ],
        head: { shape: 'blob', fill: ['#224a2e', '#0a180f'], front: ['gloss'], eye: { style: 'patch', patch: '#27cf58', white: '#f2fff5' } }
    },
    {
        id: 'aquaman', universe: dc, name: 'Aquaman', note: 'Escamas del océano', width: 0.8, alpha: 1,
        outline: '#3f1a02', outlineWidth: 0.06,
        gradient: ['#ffa526', '#f58a15', '#d36c0c'],
        patterns: [
            { type: 'band', offset: 0.78, width: 0.44, color: '#1f9f6a' },
            { type: 'band', offset: -0.78, width: 0.44, color: '#1f9f6a' },
            { type: 'scales' },
            { type: 'line', offset: 0.55, width: 0.04, color: '#ffd34d', alpha: 0.95 },
            { type: 'line', offset: -0.55, width: 0.04, color: '#ffd34d', alpha: 0.95 }
        ],
        head: { shape: 'blob', fill: ['#ffb955', '#f08a1a'], back: [{ type: 'ears', color: '#1f9f6a', tipX: -0.45, tipY: 0.82 }], front: ['gloss', 'trident'], eye: { style: 'round', pupil: '#1f6fc0' } }
    },
    {
        id: 'cyborg', universe: dc, name: 'Cyborg', note: 'Mitad hombre, mitad máquina', width: 0.8, alpha: 1,
        outline: '#0e1318', outlineWidth: 0.06,
        gradient: ['#e7edf2', '#bcc8d1', '#8c99a5'],
        glow: { color: '#ff3b3b', alpha: 0.18, pulse: true },
        patterns: [
            { type: 'band', offset: -0.62, width: 0.76, color: '#2a343e', alpha: 0.92 },
            { type: 'armor', seam: '#1b242c', seamAlpha: 0.7, shine: '#ffffff', rivet: '#d9e2ea', led: '#ff3b3b', spacing: 0.46 },
            { type: 'line', offset: 0.55, width: 0.04, color: '#ff3b3b', glow: true, pulse: true }
        ],
        head: { shape: 'helmet', fill: ['#dfe6ec', '#8d9aa6'], front: [{ type: 'half', color: '#2a343e', side: -1 }], eye: { style: 'cyclops', glow: '#ff2a2a' } }
    },
    {
        id: 'joker', universe: dc, name: 'Joker', note: 'Caos y carcajadas', width: 0.78, alpha: 1,
        outline: '#1a0727', outlineWidth: 0.06,
        gradient: ['#8f38bf', '#6c2d94', '#4d1d6f'],
        patterns: [
            { type: 'band', offset: 0, width: 0.3, color: '#8ed12f', alpha: 0.92 },
            { type: 'splash' },
            { type: 'glyph', shape: 'diamond', spacing: 1.1, size: 0.1, color: '#ffffff', offset: 0, alternate: false },
            { type: 'line', offset: 0.88, width: 0.03, color: '#c5f24a', alpha: 0.7 },
            { type: 'line', offset: -0.88, width: 0.03, color: '#c5f24a', alpha: 0.7 }
        ],
        head: { shape: 'blob', fill: ['#ffffff', '#e2e6dc'], back: [{ type: 'hair', color: '#7ec91e', count: 5, len: 0.3 }], front: [{ type: 'grin' }], eye: { style: 'patch', patch: '#2a1238', white: '#ffe94a' } }
    }
];
