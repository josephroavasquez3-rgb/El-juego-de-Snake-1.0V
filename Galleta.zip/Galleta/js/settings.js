import { palettes } from './palettes.js';
import { difficultySettings, gameModes, isModeAvailable, mapDefinitions } from './game/config.js';
import {
    getActivePlayerProfile,
    getPlayerProfile,
    profileAvatars,
    readBestScore,
    saveBestScore,
    savePlayerPreferences
} from './data/player-profile.js';

export { readBestScore, saveBestScore };

export function readPalette() {
    const id = getPlayerProfile().selectedTheme;
    return palettes.some(palette => palette.id === id) ? id : palettes[0].id;
}

export function readDifficulty() {
    const id = getPlayerProfile().difficulty;
    return difficultySettings[id] ? id : 'normal';
}

function markSelected(container, selector, attribute, value) {
    container.querySelectorAll(selector).forEach(button => {
        const selected = button.dataset[attribute] === value;
        button.setAttribute('aria-checked', String(selected));
        button.classList.toggle('is-selected', selected);
    });
}

export function applyPalette(id) {
    const palette = palettes.find(item => item.id === id) ?? palettes[0];
    document.body.dataset.palette = palette.id;
    if (getActivePlayerProfile()) savePlayerPreferences({ selectedTheme: palette.id });
    const list = document.getElementById('palette-list');
    if (list) markSelected(list, '.palette-option', 'palette', palette.id);
}

export function applyDifficulty(id) {
    const difficulty = difficultySettings[id] ? id : 'normal';
    if (getActivePlayerProfile()) savePlayerPreferences({ difficulty });
    const list = document.getElementById('difficulty-list');
    if (list) markSelected(list, '.difficulty-option', 'difficulty', difficulty);
    return difficultySettings[difficulty];
}

export function renderPalettes(container) {
    container.innerHTML = palettes.map(palette => `
        <button class="palette-option" type="button" role="radio" aria-checked="false" data-palette="${palette.id}">
            <span class="swatches" aria-hidden="true" style="--swatch-a:${palette.colors[0]};--swatch-b:${palette.colors[1]};--swatch-c:${palette.colors[2]};--swatch-d:${palette.colors[3]}"><i></i><i></i><i></i><i></i></span>
            <span class="palette-name">${palette.name}<small>${palette.code}</small></span>
            <span class="palette-check" aria-hidden="true">✓</span>
        </button>`).join('');
}

export function renderDifficulties(container) {
    const hints = { easy: 'Ritmo tranquilo', normal: 'Equilibrado', hard: 'Reflejos rápidos' };
    container.innerHTML = Object.values(difficultySettings).map(setting => `
        <button class="difficulty-option" type="button" role="radio" aria-checked="false" data-difficulty="${setting.id}">
            <span>${setting.label}</span><small>${hints[setting.id] ?? ''}</small>
        </button>`).join('');
}

export function renderSetup(mapContainer, modeContainer) {
    renderMaps(mapContainer);
    renderModes(modeContainer);
    refreshSetupSelection();
}

export function renderSettings(profile = getPlayerProfile()) {
    applyPalette(profile.selectedTheme);
    applyDifficulty(profile.difficulty);
    for (const [id, enabled] of [['toggle-sound', profile.soundEnabled], ['toggle-music', profile.musicEnabled]]) {
        const button = document.getElementById(id);
        button.setAttribute('aria-checked', String(Boolean(enabled)));
        button.querySelector('.switch-state').textContent = enabled ? 'ON' : 'OFF';
    }
    for (const [id, outputId, value] of [['sound-volume', 'sound-volume-value', profile.soundVolume], ['music-volume', 'music-volume-value', profile.musicVolume]]) {
        const input = document.getElementById(id);
        input.value = String(value);
        document.getElementById(outputId).value = `${Math.round(value * 100)}%`;
    }
    updateStatistics(profile);
}

export function updateStatistics(profile = getPlayerProfile()) {
    const stats = profile.statistics;
    document.getElementById('profile-name').textContent = profile.name.toLocaleUpperCase();
    document.getElementById('stat-games').textContent = String(stats.gamesPlayed);
    document.getElementById('stat-wins').textContent = String(stats.gamesWon);
    document.getElementById('stat-best').textContent = String(profile.highScore);
    document.getElementById('stat-total-score').textContent = String(stats.totalScore);
    document.getElementById('stat-length').textContent = String(stats.maximumLength);
    const totalMinutes = Math.floor(stats.totalTimeMs / 60000);
    document.getElementById('stat-time').textContent = totalMinutes < 60
        ? `${totalMinutes} min`
        : `${Math.floor(totalMinutes / 60)} h ${totalMinutes % 60} min`;
    document.getElementById('menu-best').textContent = String(profile.highScore).padStart(3, '0');
}

export function savePreference(key, value) {
    return getActivePlayerProfile() ? savePlayerPreferences({ [key]: value }) : null;
}

export function readMapId() {
    const id = getPlayerProfile().mapId;
    return mapDefinitions[id] ? id : 'normal';
}

export function readModeId() {
    const id = getPlayerProfile().modeId;
    return gameModes[id] ? id : 'classic';
}

export function applyMap(id) {
    const mapId = mapDefinitions[id] ? id : 'normal';
    if (getActivePlayerProfile()) savePlayerPreferences({ mapId });
    refreshSetupSelection();
    return mapDefinitions[mapId];
}

export function applyMode(id) {
    if (!gameModes[id] || !isModeAvailable(id, readMapId())) return null;
    if (getActivePlayerProfile()) savePlayerPreferences({ modeId: id });
    refreshSetupSelection();
    return gameModes[id];
}

export function renderMaps(container) {
    const selectableMaps = ['small', 'normal', 'large', 'randomWalls', 'maze', 'islands', 'corridors', 'portals'].map(id => mapDefinitions[id]);
    container.innerHTML = selectableMaps.map(map => `
        <button class="map-option" type="button" role="radio" aria-checked="false" data-map="${map.id}">
            <span class="map-preview map-preview-${map.id}" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></span>
            <span class="map-name">${map.label}<small>${map.width} × ${map.height} CELDAS</small></span>
            <span class="palette-check" aria-hidden="true">✓</span>
        </button>`).join('');
}

export function renderModes(container) {
    const modes = Object.values(gameModes);
    document.getElementById('mode-count').textContent = `${String(modes.length).padStart(2, '0')} MODOS`;
    container.innerHTML = modes.map(mode => `
        <button class="mode-option${mode.requiresMap ? ' mode-advanced' : ''}" type="button" role="radio" aria-checked="false" data-mode="${mode.id}">
            <span class="mode-name">${mode.label}<small>${mode.description}</small></span>
            ${mode.requiresMap ? `<span class="mode-requirement">REQUIERE ${mapDefinitions[mode.requiresMap].label.toLocaleUpperCase()}</span>` : ''}
            <span class="palette-check" aria-hidden="true">✓</span>
        </button>`).join('');
}

export function refreshSetupSelection() {
    const mapId = readMapId();
    const modeId = readModeId();
    const mapList = document.getElementById('map-list');
    const modeList = document.getElementById('mode-list');
    if (!mapList || !modeList) return;
    markSelected(mapList, '.map-option', 'map', mapId);
    markSelected(modeList, '.mode-option', 'mode', modeId);
    modeList.querySelectorAll('.mode-option').forEach(button => {
        const available = isModeAvailable(button.dataset.mode, mapId);
        button.disabled = !available;
        button.setAttribute('aria-disabled', String(!available));
    });
    const map = mapDefinitions[mapId];
    document.getElementById('selected-map-size').textContent = `${map.width} × ${map.height}`;
    const unavailable = !isModeAvailable(modeId, mapId);
    const requiredMap = mapDefinitions[gameModes[modeId].requiresMap]?.label;
    const notice = document.getElementById('mode-notice');
    notice.hidden = !unavailable;
    notice.textContent = unavailable ? `${gameModes[modeId].label} requiere el mapa ${requiredMap}. Cámbialo para iniciar este modo.` : '';
    document.getElementById('btn-confirm-play').disabled = unavailable;
    document.getElementById('setup-message').textContent = unavailable
        ? `Configuración incompatible: selecciona el mapa ${requiredMap}.`
        : gameModes[modeId].description;
}

export function renderProfileCardList(profiles, activeId, container) {
    container.innerHTML = profiles.map(profile => `
        <article class="profile-card${profile.id === activeId ? ' is-current' : ''}" data-profile-card="${profile.id}">
            <button class="profile-select" type="button" data-select-profile="${profile.id}" aria-pressed="${profile.id === activeId}">
                <span class="profile-avatar">${profile.avatar}</span>
                <span class="profile-card-copy"><strong>${escapeText(profile.name)}</strong><small>${profile.gamesPlayed} PARTIDAS · RÉCORD ${profile.highScore}</small></span>
                ${profile.id === activeId ? '<span class="profile-current">ACTIVO</span>' : ''}
            </button>
            <div class="profile-card-actions"><button type="button" data-rename-profile="${profile.id}" aria-label="Cambiar nombre de ${escapeText(profile.name)}">EDITAR</button><button type="button" data-delete-profile="${profile.id}" aria-label="Eliminar perfil ${escapeText(profile.name)}">ELIMINAR</button></div>
        </article>`).join('');
}

export function renderAvatarPicker(container, selected = '🐍') {
    container.innerHTML = profileAvatars.map(avatar => `<button type="button" role="radio" aria-checked="${avatar === selected}" data-avatar="${avatar}" aria-label="Avatar ${avatar}">${avatar}</button>`).join('');
}

function escapeText(value) {
    return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}