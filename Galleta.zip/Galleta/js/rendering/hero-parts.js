import { color, dense, forwardOf, getTravel, hash, lateral, marks, mirrored, normalOf, polygon, starPath, TAU } from './snake-utils.js';

/*
 * Painters used by the hero skins (Marvel / DC). Every painter receives its options from the skin
 * definition, so a new character is data only. Offsets are fractions of the half body width
 * (-1 = left edge, 0 = spine, 1 = right edge) and follow the snake through every curve.
 */

const half = (skin, widthAt, s) => skin.width * widthAt(s) / 2;

const within = (q, run, p) => (p.from === undefined || q.s >= p.from)
    && (p.to === undefined || q.s <= p.to)
    && (p.tail === undefined || run.total - run.offset - q.s <= p.tail);

const tailDistance = (run, s) => run.total - run.offset - s;
const pulse = (env, p, speed = 300) => (p.pulse ? 0.78 + 0.22 * Math.sin(env.time / speed) : 1);

function strokeRibbon(ctx, points) {
    ctx.beginPath();
    points.forEach((point, index) => (index ? ctx.lineTo(point.x, point.y) : ctx.moveTo(point.x, point.y)));
}

export const HERO_PATTERNS = {
    // Filled stripe that follows the body (optionally limited to a range or to the tail end).
    band(ctx, run, skin, env, widthAt, p) {
        const samples = dense(run).filter(q => within(q, run, p));
        if (samples.length < 2) return;
        const upper = [];
        const lower = [];
        for (const q of samples) {
            const h = half(skin, widthAt, q.s);
            upper.push(lateral(q, (p.offset + p.width / 2) * h));
            lower.push(lateral(q, (p.offset - p.width / 2) * h));
        }
        strokeRibbon(ctx, [...upper, ...lower.reverse()]);
        ctx.closePath();
        ctx.fillStyle = color(p.color, env, (p.alpha ?? 1) * pulse(env, p));
        ctx.fill();
    },

    // Thin continuous line, optionally dashed (stitching) or glowing.
    line(ctx, run, skin, env, widthAt, p) {
        const samples = dense(run).filter(q => within(q, run, p));
        if (samples.length < 2) return;
        const points = samples.map(q => lateral(q, p.offset * half(skin, widthAt, q.s)));
        const alpha = (p.alpha ?? 1) * pulse(env, p);
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        if (p.dash) {
            const period = p.dash.reduce((sum, value) => sum + value, 0);
            ctx.setLineDash(p.dash);
            ctx.lineDashOffset = ((getTravel() - samples[0].s) % period + period) % period;
        }
        if (p.glow) {
            strokeRibbon(ctx, points);
            ctx.strokeStyle = color(p.color, env, alpha * 0.28);
            ctx.lineWidth = p.width * 3;
            ctx.stroke();
        }
        strokeRibbon(ctx, points);
        ctx.strokeStyle = color(p.color, env, alpha);
        ctx.lineWidth = p.width;
        ctx.stroke();
    },

    // Spider-Man: longitudinal threads crossed by drooping arcs, all glued to the body.
    web(ctx, run, skin, env, widthAt, p) {
        const ink = color(p.color ?? '#12060a', env, p.alpha ?? 0.8);
        const samples = dense(run);
        ctx.strokeStyle = ink;
        ctx.lineCap = 'round';
        ctx.lineWidth = 0.028;
        for (const offset of p.threads ?? [-0.56, 0, 0.56]) {
            strokeRibbon(ctx, samples.map(q => lateral(q, offset * half(skin, widthAt, q.s))));
            ctx.stroke();
        }
        marks(run.path, p.spacing ?? 0.58, 0.2, (q, s) => {
            if (s < 0.45) return;
            const h = half(skin, widthAt, s);
            const a = lateral(q, -h * 0.97);
            const b = lateral(q, h * 0.97);
            const droop = (p.droop ?? 0.2) * Math.min(1, h * 3);
            const f = forwardOf(q.angle);
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.quadraticCurveTo(q.x - f.x * droop * 2, q.y - f.y * droop * 2, b.x, b.y);
            ctx.stroke();
        });
    },

    // Iron Man / Cyborg: segmented plates with seams, bevel highlights, rivets and status LEDs.
    armor(ctx, run, skin, env, widthAt, p) {
        const seam = color(p.seam ?? '#000000', env, p.seamAlpha ?? 0.55);
        marks(run.path, p.spacing ?? 0.5, 0.25, (q, s, k) => {
            if (s < 0.4) return;
            const h = half(skin, widthAt, s);
            const f = forwardOf(q.angle);
            const a = lateral(q, -h * 0.94);
            const b = lateral(q, h * 0.94);
            ctx.lineCap = 'round';
            ctx.strokeStyle = seam;
            ctx.lineWidth = 0.045;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
            if (p.shine) {
                ctx.strokeStyle = color(p.shine, env, 0.5);
                ctx.lineWidth = 0.025;
                ctx.beginPath(); ctx.moveTo(a.x + f.x * 0.055, a.y + f.y * 0.055); ctx.lineTo(b.x + f.x * 0.055, b.y + f.y * 0.055); ctx.stroke();
            }
            if (p.insert && k % 2 === 0) {
                const c1 = lateral(q, -h * 0.5);
                const c2 = lateral(q, h * 0.5);
                ctx.strokeStyle = color(p.insert, env, 0.9);
                ctx.lineWidth = 0.07;
                ctx.beginPath();
                ctx.moveTo(c1.x - f.x * 0.12, c1.y - f.y * 0.12);
                ctx.lineTo(c2.x - f.x * 0.12, c2.y - f.y * 0.12);
                ctx.stroke();
            }
            if (p.rivet) {
                ctx.fillStyle = color(p.rivet, env, 0.9);
                for (const side of [-1, 1]) {
                    const r = lateral(q, side * h * 0.74);
                    ctx.beginPath(); ctx.arc(r.x, r.y, 0.028, 0, TAU); ctx.fill();
                }
            }
            if (p.led && k % 3 === 0) {
                const led = lateral(q, -h * 0.45);
                const on = Math.sin(env.time / 260 + k) > -0.2;
                ctx.fillStyle = color(p.led, env, on ? 0.35 : 0.12);
                ctx.beginPath(); ctx.arc(led.x, led.y, 0.1, 0, TAU); ctx.fill();
                ctx.fillStyle = color(p.led, env, on ? 1 : 0.4);
                ctx.beginPath(); ctx.arc(led.x, led.y, 0.04, 0, TAU); ctx.fill();
            }
        });
    },

    // Small repeated symbols (stars, diamonds, dots) along an offset line.
    glyph(ctx, run, skin, env, widthAt, p) {
        marks(run.path, p.spacing ?? 0.7, 0.3, (q, s, k) => {
            if (s < 0.5 || (p.tail !== undefined && tailDistance(run, s) > p.tail)) return;
            if (p.every && k % p.every) return;
            const h = half(skin, widthAt, s);
            const offset = (p.offset ?? 0) * (p.alternate && k % 2 ? -1 : 1);
            const center = lateral(q, offset * h);
            const size = (p.size ?? 0.12) * Math.min(1, widthAt(s) + 0.2);
            ctx.save();
            ctx.translate(center.x, center.y);
            ctx.rotate(q.angle - Math.PI / 2);
            ctx.fillStyle = color(p.color, env, p.alpha ?? 1);
            if (p.shape === 'diamond') polygon(ctx, [[0, -size * 1.3], [size, 0], [0, size * 1.3], [-size, 0]]);
            else if (p.shape === 'dot') { ctx.beginPath(); ctx.arc(0, 0, size * 0.6, 0, TAU); }
            else starPath(ctx, size);
            ctx.fill();
            ctx.restore();
        });
    },

    // Chest emblem placed a fixed distance behind the head, rotated with the body.
    emblem(ctx, run, skin, env, widthAt, p) {
        if (run.offset > 0) return;
        for (const distance of p.at ?? [1.3]) {
            if (distance > run.path.total - 0.6) continue;
            const q = run.path.at(distance);
            const size = skin.width * (p.size ?? 0.9) * Math.min(1, widthAt(distance));
            ctx.save();
            ctx.translate(q.x, q.y);
            ctx.rotate(q.angle - Math.PI / 2);
            ctx.scale(size, size);
            EMBLEMS[p.shape]?.(ctx, env, p);
            ctx.restore();
        }
    },

    // Flash: one continuous zigzag bolt running down the spine.
    bolt(ctx, run, skin, env, widthAt, p) {
        const points = [];
        marks(run.path, p.step ?? 0.34, 0.1, (q, s, k) => {
            const h = half(skin, widthAt, s);
            points.push(lateral(q, (k % 2 ? 1 : -1) * h * (p.amplitude ?? 0.62)));
        });
        if (points.length < 2) return;
        ctx.lineJoin = 'miter';
        ctx.lineCap = 'round';
        for (const [width, alpha] of [[0.14, 0.28], [0.055, 1]]) {
            strokeRibbon(ctx, points);
            ctx.strokeStyle = color(p.color, env, alpha * pulse(env, p, 120));
            ctx.lineWidth = width;
            ctx.stroke();
        }
    },

    // Flash: faint speed streaks behind the tail.
    trail(ctx, run, skin, env, widthAt, p) {
        if (!run.isLast) return;
        const tail = run.path.at(run.path.total);
        const length = (p.length ?? 1.1) + 0.25 * Math.sin(env.time / 140);
        const dx = Math.cos(tail.angle);
        const dy = Math.sin(tail.angle);
        const n = normalOf(tail.angle);
        for (const offset of [-0.13, 0, 0.13]) {
            const sx = tail.x + n.x * offset;
            const sy = tail.y + n.y * offset;
            const gradient = ctx.createLinearGradient(sx, sy, sx + dx * length, sy + dy * length);
            gradient.addColorStop(0, color(p.color, env, 0.75));
            gradient.addColorStop(1, color(p.color, env, 0));
            ctx.strokeStyle = gradient;
            ctx.lineWidth = offset === 0 ? 0.05 : 0.03;
            ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx + dx * length * (offset === 0 ? 1 : 0.7), sy + dy * length * (offset === 0 ? 1 : 0.7)); ctx.stroke();
        }
    },

    // Thor: flickering electric arcs across the armor.
    sparks(ctx, run, skin, env, widthAt, p) {
        const frame = Math.floor(env.time / 110);
        marks(run.path, p.spacing ?? 0.8, 0.2, (q, s, k) => {
            if (s < 0.6 || hash(k * 3.7 + frame) < 0.62) return;
            const h = half(skin, widthAt, s);
            const f = forwardOf(q.angle);
            const side = hash(k + frame * 0.37) > 0.5 ? 1 : -1;
            const points = [];
            for (let step = 0; step <= 4; step += 1) {
                const t = step / 4;
                const jitter = (hash(k * 11 + step + frame) - 0.5) * 0.2;
                const c = lateral(q, (side * (1 - t * 1.6)) * h * 0.9);
                points.push({ x: c.x + f.x * jitter, y: c.y + f.y * jitter });
            }
            strokeRibbon(ctx, points);
            ctx.lineJoin = 'miter';
            ctx.strokeStyle = color(p.color ?? '#a8e6ff', env, 0.4);
            ctx.lineWidth = 0.08;
            ctx.stroke();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 0.025;
            ctx.stroke();
        });
    },

    // Thor: round armor discs.
    discs(ctx, run, skin, env, widthAt, p) {
        marks(run.path, p.spacing ?? 0.64, 0.3, (q, s) => {
            if (s < 0.5) return;
            const r = (p.size ?? 0.17) * Math.min(1, widthAt(s));
            const gradient = ctx.createRadialGradient(q.x - r * 0.3, q.y - r * 0.3, r * 0.1, q.x, q.y, r);
            gradient.addColorStop(0, color(p.light ?? '#ffffff', env));
            gradient.addColorStop(1, color(p.dark ?? '#6b7f98', env));
            ctx.fillStyle = gradient;
            ctx.beginPath(); ctx.arc(q.x, q.y, r, 0, TAU); ctx.fill();
            ctx.strokeStyle = color(p.ring ?? '#2b3647', env, 0.8);
            ctx.lineWidth = 0.03;
            ctx.stroke();
        });
    },

    // Black Panther: glowing V marks across the back.
    chevrons(ctx, run, skin, env, widthAt, p) {
        const alpha = pulse(env, { pulse: true }, 420);
        marks(run.path, p.spacing ?? 0.5, 0.25, (q, s) => {
            if (s < 0.5) return;
            const h = half(skin, widthAt, s);
            const f = forwardOf(q.angle);
            const a = lateral(q, -h * 0.82);
            const b = lateral(q, h * 0.82);
            const points = [
                { x: a.x + f.x * 0.13, y: a.y + f.y * 0.13 },
                { x: q.x - f.x * 0.1, y: q.y - f.y * 0.1 },
                { x: b.x + f.x * 0.13, y: b.y + f.y * 0.13 }
            ];
            ctx.lineJoin = 'miter';
            strokeRibbon(ctx, points);
            ctx.strokeStyle = color(p.color, env, 0.25 * alpha);
            ctx.lineWidth = 0.1;
            ctx.stroke();
            ctx.strokeStyle = color(p.color, env, 0.95 * alpha);
            ctx.lineWidth = 0.035;
            ctx.stroke();
        });
    },

    // Wolverine: angular black claw slashes on the flanks.
    claws(ctx, run, skin, env, widthAt, p) {
        marks(run.path, p.spacing ?? 0.85, 0.2, (q, s) => {
            if (s < 0.6 || s > run.path.total - 0.6) return;
            const h = half(skin, widthAt, s);
            const ahead = run.path.at(Math.min(run.path.total, s + 0.42));
            ctx.fillStyle = color(p.color ?? '#0d0d12', env, 0.92);
            for (const side of [-1, 1]) {
                for (let claw = 0; claw < 3; claw += 1) {
                    const start = run.path.at(Math.min(run.path.total, s + claw * 0.13));
                    const e1 = lateral(start, side * h * 0.98);
                    const e2 = lateral(run.path.at(Math.min(run.path.total, s + claw * 0.13 + 0.09)), side * h * 0.98);
                    const tip = lateral(ahead, side * h * (0.28 + claw * 0.1));
                    polygon(ctx, [[e1.x, e1.y], [e2.x, e2.y], [tip.x, tip.y]]);
                    ctx.fill();
                }
            }
        });
    },

    // Hulk: pairs of muscle crescents with highlights.
    muscle(ctx, run, skin, env, widthAt, p) {
        marks(run.path, p.spacing ?? 0.62, 0.2, (q, s) => {
            if (s < 0.6 || s > run.path.total - 0.5) return;
            const h = half(skin, widthAt, s);
            const next = run.path.at(s + 0.22);
            for (const side of [-1, 1]) {
                const a = lateral(q, side * h * 0.92);
                const c = lateral(next, side * h * 0.45);
                const b = lateral(q, side * h * 0.05);
                ctx.beginPath();
                ctx.moveTo(a.x, a.y);
                ctx.quadraticCurveTo(c.x, c.y, b.x, b.y);
                ctx.strokeStyle = color(p.dark ?? '#166015', env, 0.5);
                ctx.lineWidth = 0.075;
                ctx.lineCap = 'round';
                ctx.stroke();
                const f = forwardOf(q.angle);
                ctx.beginPath();
                ctx.moveTo(a.x + f.x * 0.06, a.y + f.y * 0.06);
                ctx.quadraticCurveTo(c.x + f.x * 0.07, c.y + f.y * 0.07, b.x + f.x * 0.06, b.y + f.y * 0.06);
                ctx.strokeStyle = color(p.light ?? '#b9ffa8', env, 0.3);
                ctx.lineWidth = 0.035;
                ctx.stroke();
            }
        });
    },

    // Aquaman: overlapping fish scales that continue seamlessly down the body.
    scales(ctx, run, skin, env, widthAt, p) {
        marks(run.path, p.spacing ?? 0.34, 0.1, (q, s, k) => {
            if (s < 0.5) return;
            const h = half(skin, widthAt, s);
            const offsets = k % 2 ? [-0.62, 0, 0.62] : [-0.31, 0.31];
            const radius = Math.min(0.17, h * 0.5);
            for (const offset of offsets) {
                const c = lateral(q, offset * h);
                ctx.beginPath();
                ctx.arc(c.x, c.y, radius, q.angle - Math.PI / 2, q.angle + Math.PI / 2);
                ctx.strokeStyle = color(p.color ?? '#7c3a05', env, 0.55);
                ctx.lineWidth = 0.035;
                ctx.stroke();
                ctx.beginPath();
                ctx.arc(c.x, c.y, radius * 0.6, q.angle - Math.PI / 2.4, q.angle + Math.PI / 2.4);
                ctx.strokeStyle = color(p.highlight ?? '#ffe08a', env, 0.35);
                ctx.lineWidth = 0.02;
                ctx.stroke();
            }
        });
    },

    // Green Lantern: glowing hexagon lattice.
    hex(ctx, run, skin, env, widthAt, p) {
        const glow = pulse(env, { pulse: true }, 360);
        marks(run.path, p.spacing ?? 0.5, 0.2, (q, s, k) => {
            if (s < 0.5) return;
            const h = half(skin, widthAt, s);
            const radius = Math.min(0.17, h * 0.55);
            const c = lateral(q, (k % 2 ? 1 : -1) * h * 0.2);
            ctx.save();
            ctx.translate(c.x, c.y);
            ctx.rotate(q.angle);
            ctx.beginPath();
            for (let corner = 0; corner < 6; corner += 1) {
                const angle = corner * Math.PI / 3 + Math.PI / 6;
                ctx.lineTo(Math.cos(angle) * radius, Math.sin(angle) * radius);
            }
            ctx.closePath();
            ctx.fillStyle = color(p.color, env, 0.12 * glow);
            ctx.fill();
            ctx.strokeStyle = color(p.color, env, 0.85 * glow);
            ctx.lineWidth = 0.03;
            ctx.stroke();
            ctx.restore();
        });
    },

    // Joker: irregular splashes of color.
    splash(ctx, run, skin, env, widthAt, p) {
        const palette = p.colors ?? ['#8ed12f', '#c5f24a', '#ffffff'];
        marks(run.path, p.spacing ?? 0.42, 0.2, (q, s, k) => {
            if (s < 0.5) return;
            const h = half(skin, widthAt, s);
            const c = lateral(q, (hash(k * 1.7) - 0.5) * 1.5 * h);
            const radius = 0.045 + hash(k * 2.3) * 0.09;
            ctx.fillStyle = color(palette[Math.floor(hash(k * 5.1) * palette.length)], env, 0.85);
            ctx.beginPath();
            for (let corner = 0; corner < 7; corner += 1) {
                const angle = corner / 7 * TAU;
                const r = radius * (0.6 + hash(k * 13 + corner) * 0.8);
                ctx.lineTo(c.x + Math.cos(angle) * r, c.y + Math.sin(angle) * r);
            }
            ctx.closePath();
            ctx.fill();
        });
    }
};

const BAT_HALF = [[0, -0.2], [0.06, -0.31], [0.11, -0.17], [0.26, -0.2], [0.4, -0.14], [0.46, -0.03], [0.39, 0.06], [0.31, 0], [0.27, 0.11], [0.18, 0.04], [0.11, 0.17], [0.05, 0.07], [0, 0.17]];

// Emblems are drawn upright (up = direction of travel) in a unit box around the origin.
export const EMBLEMS = {
    bat(ctx) {
        ctx.fillStyle = '#ffd21f';
        ctx.beginPath(); ctx.ellipse(0, 0, 0.54, 0.35, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#0b0b0f'; ctx.lineWidth = 0.05; ctx.stroke();
        ctx.fillStyle = '#0b0b0f';
        polygon(ctx, mirrored(BAT_HALF)); ctx.fill();
    },
    superman(ctx) {
        polygon(ctx, [[-0.46, -0.42], [0.46, -0.42], [0.46, 0.04], [0, 0.52], [-0.46, 0.04]]);
        ctx.fillStyle = '#ffd23a'; ctx.fill();
        ctx.strokeStyle = '#c1121f'; ctx.lineWidth = 0.06; ctx.lineJoin = 'round'; ctx.stroke();
        ctx.strokeStyle = '#c1121f'; ctx.lineWidth = 0.1; ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(0.2, -0.22);
        ctx.bezierCurveTo(0.2, -0.36, -0.22, -0.36, -0.22, -0.15);
        ctx.bezierCurveTo(-0.22, 0.02, 0.22, -0.02, 0.22, 0.16);
        ctx.bezierCurveTo(0.22, 0.34, -0.2, 0.32, -0.2, 0.18);
        ctx.stroke();
    },
    shield(ctx) {
        const rings = [['#c8202b', 0.5], ['#f4f4f4', 0.39], ['#c8202b', 0.29], ['#1c4fb8', 0.2]];
        rings.forEach(([fill, r]) => { ctx.fillStyle = fill; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill(); });
        ctx.fillStyle = '#ffffff'; starPath(ctx, 0.17); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.lineWidth = 0.03; ctx.beginPath(); ctx.arc(0, 0, 0.5, 0, TAU); ctx.stroke();
    },
    reactor(ctx, env) {
        const glow = 0.8 + 0.2 * Math.sin(env.time / 260);
        ctx.fillStyle = `rgba(143,232,255,${0.28 * glow})`;
        ctx.beginPath(); ctx.arc(0, 0, 0.62, 0, TAU); ctx.fill();
        ctx.fillStyle = '#2b3a44';
        ctx.beginPath(); ctx.arc(0, 0, 0.46, 0, TAU); ctx.fill();
        const gradient = ctx.createRadialGradient(0, 0, 0.02, 0, 0, 0.4);
        gradient.addColorStop(0, '#ffffff'); gradient.addColorStop(0.55, '#aef2ff'); gradient.addColorStop(1, '#27b7e0');
        ctx.fillStyle = gradient;
        ctx.beginPath(); ctx.arc(0, 0, 0.38, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(20,70,90,.7)'; ctx.lineWidth = 0.04;
        polygon(ctx, [[0, -0.27], [0.24, 0.15], [-0.24, 0.15]]); ctx.stroke();
    },
    lantern(ctx, env) {
        const glow = 0.75 + 0.25 * Math.sin(env.time / 300);
        ctx.fillStyle = `rgba(53,240,106,${0.25 * glow})`;
        ctx.beginPath(); ctx.arc(0, 0, 0.6, 0, TAU); ctx.fill();
        ctx.fillStyle = '#04120a';
        ctx.beginPath(); ctx.arc(0, 0, 0.46, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#35f06a'; ctx.lineWidth = 0.07;
        ctx.beginPath(); ctx.arc(0, 0, 0.38, 0, TAU); ctx.stroke();
        ctx.lineWidth = 0.09; ctx.lineCap = 'butt';
        ctx.beginPath(); ctx.moveTo(-0.18, 0); ctx.lineTo(0.18, 0); ctx.moveTo(0, -0.18); ctx.lineTo(0, 0.18); ctx.stroke();
    },
    ww(ctx) {
        ctx.fillStyle = '#c8222a';
        ctx.beginPath(); ctx.arc(0, 0, 0.5, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#ffd34d'; ctx.lineWidth = 0.05; ctx.stroke();
        ctx.lineWidth = 0.09; ctx.lineJoin = 'miter'; ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(-0.3, -0.2); ctx.lineTo(-0.16, 0.2); ctx.lineTo(0, -0.04); ctx.lineTo(0.16, 0.2); ctx.lineTo(0.3, -0.2);
        ctx.stroke();
        ctx.lineWidth = 0.05;
        ctx.beginPath(); ctx.moveTo(-0.38, -0.3); ctx.quadraticCurveTo(0, -0.1, 0.38, -0.3); ctx.stroke();
    },
    spider(ctx) {
        ctx.strokeStyle = '#0c0508'; ctx.lineWidth = 0.05; ctx.lineCap = 'round';
        for (const side of [-1, 1]) {
            for (const [angle, reach] of [[-0.9, 0.44], [-0.35, 0.5], [0.3, 0.5], [0.85, 0.44]]) {
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.quadraticCurveTo(side * reach * 0.6, Math.sin(angle) * 0.4 - 0.08, side * reach, Math.sin(angle) * reach * 0.9);
                ctx.stroke();
            }
        }
        ctx.fillStyle = '#0c0508';
        ctx.beginPath(); ctx.ellipse(0, 0.08, 0.11, 0.2, 0, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.ellipse(0, -0.14, 0.075, 0.09, 0, 0, TAU); ctx.fill();
    },
    flash(ctx) {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(0, 0, 0.5, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#a8141a'; ctx.lineWidth = 0.05; ctx.stroke();
        ctx.fillStyle = '#ffc31f';
        polygon(ctx, [[0.05, -0.4], [-0.2, 0.06], [-0.02, 0.06], [-0.08, 0.4], [0.2, -0.08], [0.02, -0.08]]);
        ctx.fill();
        ctx.strokeStyle = '#a8141a'; ctx.lineWidth = 0.025; ctx.stroke();
    }
};

export const HERO_HEAD_SHAPES = {
    cowl: ctx => {
        ctx.moveTo(0.58, 0);
        ctx.bezierCurveTo(0.54, -0.26, 0.34, -0.46, 0.04, -0.46);
        ctx.lineTo(-0.34, -0.4);
        ctx.quadraticCurveTo(-0.5, -0.2, -0.5, 0);
        ctx.quadraticCurveTo(-0.5, 0.2, -0.34, 0.4);
        ctx.lineTo(0.04, 0.46);
        ctx.bezierCurveTo(0.34, 0.46, 0.54, 0.26, 0.58, 0);
        ctx.closePath();
    },
    helmet: ctx => { ctx.roundRect(-0.44, -0.44, 1.0, 0.88, 0.3); }
};

export const HERO_HEAD_BACK = {
    ears(ctx, skin, env, o, outline) {
        for (const side of [-1, 1]) {
            polygon(ctx, [[0.12, side * 0.28], [-0.3, side * 0.42], [o.tipX ?? -0.2, side * (o.tipY ?? 0.72)]]);
            ctx.fillStyle = color(o.color, env);
            ctx.fill();
            ctx.strokeStyle = outline;
            ctx.lineWidth = skin.outlineWidth;
            ctx.stroke();
        }
    },
    wings(ctx, skin, env, o, outline) {
        for (const side of [-1, 1]) {
            polygon(ctx, [[0.12, side * 0.36], [0, side * 0.64], [-0.26, side * 0.84], [-0.2, side * 0.58], [-0.36, side * 0.54], [-0.26, side * 0.4]]);
            ctx.fillStyle = color(o.color, env);
            ctx.fill();
            ctx.strokeStyle = outline;
            ctx.lineWidth = skin.outlineWidth;
            ctx.stroke();
        }
    },
    hair(ctx, skin, env, o, outline) {
        ctx.fillStyle = color(o.color, env);
        ctx.strokeStyle = outline;
        ctx.lineWidth = skin.outlineWidth;
        if (o.smooth) {
            ctx.beginPath(); ctx.ellipse(-0.34, 0, 0.3, 0.44, 0, 0, TAU); ctx.fill(); ctx.stroke();
            ctx.beginPath(); ctx.ellipse(-0.62, 0.04, 0.2, 0.12, 0.3, 0, TAU); ctx.fill();
            return;
        }
        const count = o.count ?? 5;
        for (let index = 0; index < count; index += 1) {
            const angle = Math.PI + (index - (count - 1) / 2) * 0.42;
            const bx = 0.05 + Math.cos(angle) * 0.4;
            const by = Math.sin(angle) * 0.4;
            const tip = [0.05 + Math.cos(angle) * (0.4 + (o.len ?? 0.28)), Math.sin(angle) * (0.4 + (o.len ?? 0.28))];
            polygon(ctx, [[bx - Math.sin(angle) * 0.1, by + Math.cos(angle) * 0.1], tip, [bx + Math.sin(angle) * 0.1, by - Math.cos(angle) * 0.1]]);
            ctx.fill();
        }
    }
};

export const HERO_HEAD_FRONT = {
    faceplate(ctx, skin, env, o) {
        ctx.beginPath(); ctx.roundRect(-0.1, -0.34, 0.66, 0.68, 0.2);
        ctx.fillStyle = color(o.color ?? '#ffcf3a', env); ctx.fill();
        ctx.strokeStyle = 'rgba(70,20,0,.75)'; ctx.lineWidth = 0.03; ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0.12, 0); ctx.lineTo(0.5, 0);
        ctx.moveTo(0.46, -0.1); ctx.lineTo(0.46, 0.1); ctx.stroke();
    },
    half(ctx, skin, env, o, shape) {
        ctx.beginPath(); shape(ctx); ctx.clip();
        ctx.fillStyle = color(o.color ?? '#2b3640', env, 0.92);
        ctx.fillRect(-0.7, (o.side ?? 1) > 0 ? 0 : -0.7, 1.4, 0.7);
    },
    star(ctx, skin, env, o) {
        ctx.translate(-0.08, 0); ctx.rotate(Math.PI / 2);
        ctx.fillStyle = color(o.color ?? '#ffffff', env, 0.95); starPath(ctx, 0.14); ctx.fill();
    },
    curl(ctx, skin, env) {
        ctx.fillStyle = '#14141a';
        ctx.beginPath(); ctx.ellipse(-0.17, 0, 0.35, 0.46, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#14141a'; ctx.lineWidth = 0.055; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(0.08, -0.18); ctx.quadraticCurveTo(0.22, -0.2, 0.2, -0.08); ctx.stroke();
    },
    tiara(ctx) {
        ctx.strokeStyle = '#ffd34d'; ctx.lineWidth = 0.07; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(-0.02, -0.34); ctx.quadraticCurveTo(-0.16, 0, -0.02, 0.34); ctx.stroke();
        ctx.fillStyle = '#d6262e';
        ctx.translate(-0.1, 0); ctx.rotate(Math.PI / 2);
        starPath(ctx, 0.075); ctx.fill();
    },
    grin(ctx) {
        ctx.strokeStyle = '#d4202c'; ctx.lineWidth = 0.075; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(0.36, -0.28); ctx.quadraticCurveTo(0.62, 0, 0.36, 0.28); ctx.stroke();
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 0.025;
        ctx.beginPath(); ctx.moveTo(0.4, -0.18); ctx.lineTo(0.5, -0.17); ctx.moveTo(0.43, -0.06); ctx.lineTo(0.53, -0.05);
        ctx.moveTo(0.43, 0.06); ctx.lineTo(0.53, 0.05); ctx.moveTo(0.4, 0.18); ctx.lineTo(0.5, 0.17); ctx.stroke();
    },
    boltmark(ctx) {
        ctx.strokeStyle = '#ffd21f'; ctx.lineWidth = 0.06; ctx.lineJoin = 'miter'; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(0, -0.17); ctx.lineTo(-0.13, -0.02); ctx.lineTo(-0.04, -0.02); ctx.lineTo(-0.17, 0.17); ctx.stroke();
    },
    lines(ctx, skin, env, o) {
        const glow = 0.7 + 0.3 * Math.sin(env.time / 420);
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        const draw = (width, alpha) => {
            ctx.strokeStyle = color(o.color, env, alpha * glow); ctx.lineWidth = width;
            ctx.beginPath();
            ctx.moveTo(-0.42, 0); ctx.lineTo(0.02, 0);
            ctx.moveTo(-0.34, -0.2); ctx.lineTo(-0.12, -0.08);
            ctx.moveTo(-0.34, 0.2); ctx.lineTo(-0.12, 0.08);
            ctx.stroke();
        };
        draw(0.09, 0.28); draw(0.03, 1);
    },
    web(ctx, skin, env, o, shape) {
        ctx.beginPath(); shape(ctx); ctx.clip();
        ctx.strokeStyle = color(o.color ?? '#12060a', env, 0.7); ctx.lineWidth = 0.022;
        ctx.beginPath();
        for (let index = 0; index < 8; index += 1) {
            const angle = index * Math.PI / 4;
            ctx.moveTo(-0.05, 0); ctx.lineTo(-0.05 + Math.cos(angle) * 0.7, Math.sin(angle) * 0.7);
        }
        ctx.stroke();
        for (const radius of [0.18, 0.34, 0.5]) {
            ctx.beginPath();
            for (let index = 0; index <= 8; index += 1) {
                const angle = index * Math.PI / 4;
                const r = radius * (index % 2 ? 0.92 : 1);
                const x = -0.05 + Math.cos(angle) * r;
                const y = Math.sin(angle) * r;
                if (index) ctx.lineTo(x, y); else ctx.moveTo(x, y);
            }
            ctx.stroke();
        }
    },
    trident(ctx) {
        ctx.strokeStyle = '#ffd34d'; ctx.lineWidth = 0.045; ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(-0.3, 0); ctx.lineTo(0.06, 0);
        ctx.moveTo(0.0, -0.1); ctx.lineTo(0.0, 0.1);
        ctx.moveTo(0.0, -0.1); ctx.lineTo(0.12, -0.1); ctx.moveTo(0.0, 0.1); ctx.lineTo(0.12, 0.1); ctx.moveTo(0.06, 0); ctx.lineTo(0.16, 0);
        ctx.stroke();
    }
};

const eyePositions = [-1, 1];

export const HERO_EYES = {
    // Spider-Man: big white lenses with a heavy black rim.
    lens(ctx, eye) {
        for (const side of eyePositions) {
            ctx.save();
            ctx.translate(0.22, side * 0.2); ctx.rotate(-side * 0.6);
            ctx.beginPath(); ctx.ellipse(0, 0, 0.16, 0.085, 0, 0, TAU);
            ctx.fillStyle = eye.white ?? '#ffffff'; ctx.fill();
            ctx.lineWidth = 0.04; ctx.strokeStyle = eye.outline ?? '#0a0306'; ctx.stroke();
            ctx.restore();
        }
    },
    // Narrow slanted eyes that can glow (Batman, Panther, Iron Man, Flash, Wolverine).
    angled(ctx, eye) {
        for (const side of eyePositions) {
            ctx.save();
            ctx.translate(0.24, side * 0.19); ctx.rotate(-side * 0.42);
            if (eye.glow) {
                ctx.fillStyle = `${eye.glow}55`;
                ctx.beginPath(); ctx.ellipse(0, 0, 0.19, 0.1, 0, 0, TAU); ctx.fill();
            }
            ctx.beginPath(); ctx.ellipse(0, 0, 0.13, 0.045, 0, 0, TAU);
            ctx.fillStyle = eye.white ?? '#ffffff'; ctx.fill();
            ctx.restore();
        }
    },
    // Dark (or colored) mask patch around a small white eye (Deadpool, Green Lantern, Joker).
    patch(ctx, eye) {
        for (const side of eyePositions) {
            ctx.save();
            ctx.translate(0.2, side * 0.2); ctx.rotate(-side * 0.5);
            ctx.beginPath(); ctx.ellipse(0, 0, 0.19, 0.105, 0, 0, TAU);
            ctx.fillStyle = eye.patch ?? '#0a0a0e'; ctx.fill();
            ctx.lineWidth = 0.02; ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.stroke();
            ctx.beginPath(); ctx.ellipse(0.02, 0, 0.11, 0.045, 0, 0, TAU);
            ctx.fillStyle = eye.white ?? '#ffffff'; ctx.fill();
            ctx.restore();
        }
    },
    // Cyborg: a single glowing red lens on one side, dark optics on the other.
    cyclops(ctx, eye) {
        const glow = eye.glow ?? '#ff2a2a';
        ctx.fillStyle = 'rgba(255,42,42,.3)';
        ctx.beginPath(); ctx.arc(0.22, -0.2, 0.2, 0, TAU); ctx.fill();
        ctx.fillStyle = '#1a0606';
        ctx.beginPath(); ctx.arc(0.22, -0.2, 0.125, 0, TAU); ctx.fill();
        ctx.fillStyle = glow;
        ctx.beginPath(); ctx.arc(0.22, -0.2, 0.085, 0, TAU); ctx.fill();
        ctx.fillStyle = '#ffd0d0';
        ctx.beginPath(); ctx.arc(0.2, -0.22, 0.025, 0, TAU); ctx.fill();
        ctx.fillStyle = '#0f151a';
        ctx.beginPath(); ctx.roundRect(0.16, 0.12, 0.12, 0.16, 0.04); ctx.fill();
    },
    // Hulk: round eyes under a heavy angry brow.
    angry(ctx, eye) {
        for (const side of eyePositions) {
            ctx.fillStyle = eye.white ?? '#ffffff';
            ctx.beginPath(); ctx.arc(0.2, side * 0.2, 0.1, 0, TAU); ctx.fill();
            ctx.fillStyle = eye.pupil ?? '#1b2a14';
            ctx.beginPath(); ctx.arc(0.24, side * 0.2, 0.055, 0, TAU); ctx.fill();
            ctx.strokeStyle = eye.brow ?? '#0f3a0d'; ctx.lineWidth = 0.075; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(0.1, side * 0.36); ctx.lineTo(0.34, side * 0.1); ctx.stroke();
        }
    }
};
