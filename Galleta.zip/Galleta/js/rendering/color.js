const FALLBACK = [255, 255, 255];

export function parseColor(value) {
    if (Array.isArray(value)) return value;
    const text = String(value ?? '').trim();
    if (text.startsWith('#')) {
        const hex = text.length === 4 ? text.slice(1).replace(/./g, character => character + character) : text.slice(1, 7);
        const number = Number.parseInt(hex, 16);
        return Number.isNaN(number) ? FALLBACK : [(number >> 16) & 255, (number >> 8) & 255, number & 255];
    }
    const match = text.match(/rgba?\(([^)]+)\)/);
    if (match) {
        const parts = match[1].split(',').map(part => Number.parseFloat(part));
        return [parts[0] || 0, parts[1] || 0, parts[2] || 0];
    }
    return FALLBACK;
}

export function mix(first, second, amount) {
    const a = parseColor(first);
    const b = parseColor(second);
    return a.map((channel, index) => Math.round(channel + (b[index] - channel) * amount));
}

// Positive percent lightens toward white, negative darkens toward black.
export function shade(color, percent) {
    return percent >= 0 ? mix(color, [255, 255, 255], percent / 100) : mix(color, [0, 0, 0], -percent / 100);
}

export function css(color, alpha = 1) {
    const [red, green, blue] = parseColor(color);
    return alpha >= 1 ? `rgb(${red},${green},${blue})` : `rgba(${red},${green},${blue},${alpha})`;
}

// Resolves "accent", "accent+20", "accent-30" tokens against the active theme color.
export function resolveToken(token, accent) {
    const match = /^accent([+-]\d+)?$/.exec(token);
    if (!match) return parseColor(token);
    return match[1] ? shade(accent, Number(match[1])) : parseColor(accent);
}

export function gradientLookup(stops, accent, size = 48, loop = false) {
    const colors = stops.map(stop => resolveToken(stop, accent));
    const table = [];
    for (let index = 0; index < size; index += 1) {
        const position = (index / (size - 1)) * (colors.length - 1);
        const lower = Math.min(colors.length - 2, Math.floor(position));
        table.push(css(mix(colors[lower], colors[lower + 1], position - lower)));
    }
    table.loop = loop;
    return table;
}

export function lookup(table, position) {
    const wrapped = table.loop ? ((position % 1) + 1) % 1 : Math.min(1, Math.max(0, position));
    return table[Math.round(wrapped * (table.length - 1))];
}
