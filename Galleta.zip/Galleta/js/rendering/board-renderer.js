import { css, mix, shade } from './color.js';
import { drawFood } from './food-renderer.js';
import { drawSnake } from './snake-renderer.js';

const MAX_BOARD_PIXELS = 960;

export function readTheme() {
    const styles = getComputedStyle(document.body);
    const read = name => styles.getPropertyValue(name).trim();
    return { surface: read('--surface'), line: read('--line'), accent: read('--accent'), accentInk: read('--accent-ink'), food: read('--food') };
}

export function paintTiles(context, columns, rows, cell, theme) {
    context.fillStyle = theme.surface;
    context.fillRect(0, 0, columns * cell, rows * cell);
    context.fillStyle = css(shade(theme.surface, 5), 0.55);
    for (let y = 0; y < rows; y += 1) {
        for (let x = (y % 2); x < columns; x += 2) context.fillRect(x * cell, y * cell, cell, cell);
    }
}

export class BoardRenderer {
    constructor(canvas) {
        this.canvas = canvas;
        this.context = canvas.getContext('2d');
        this.cell = 24;
        this.theme = null;
        this.themeKey = '';
    }

    resize(map) {
        const cell = Math.max(18, Math.min(44, Math.floor(MAX_BOARD_PIXELS / Math.max(map.width, map.height))));
        this.cell = cell;
        this.canvas.width = cell * map.width;
        this.canvas.height = cell * map.height;
        this.canvas.style.setProperty('--board-ratio', `${map.width} / ${map.height}`);
        this.canvas.parentElement?.style.setProperty('--board-ratio', String(map.width / map.height));
    }

    currentTheme() {
        const key = document.body.dataset.palette;
        if (this.themeKey !== key || !this.theme) {
            this.theme = readTheme();
            this.themeKey = key;
        }
        return this.theme;
    }

    render({ view, food, foodBornAt = 0, eaten = null, foodSkin, skin, map, particles, time = 0, dead = false, travel = 0, fade = 1, impact = null }) {
        const context = this.context;
        const theme = this.currentTheme();
        const cell = this.cell;
        const width = this.canvas.width;
        const height = this.canvas.height;

        context.clearRect(0, 0, width, height);
        paintTiles(context, map.width, map.height, cell, theme);

        this.drawObstacles(map, theme, cell);
        this.drawPortals(map, theme, cell, time);

        const foodSize = cell * 0.94;
        if (eaten) {
            const amount = Math.min(1, Math.max(0, (time - eaten.startedAt) / eaten.duration));
            if (amount < 1) drawFood(context, eaten.skinId, (eaten.x + 0.5) * cell, (eaten.y + 0.5) * cell, foodSize, { time, themeFood: theme.food, scale: 1 - amount * amount, animate: false });
        }
        if (food) {
            const age = Math.min(1, Math.max(0, (time - foodBornAt) / 240));
            const scale = 0.35 + 0.65 * (1 - (1 - age) ** 3);
            drawFood(context, foodSkin.id, (food.x + 0.5) * cell, (food.y + 0.5) * cell, foodSize, { time, themeFood: theme.food, scale });
        }

        if (view) {
            context.globalAlpha = fade;
            drawSnake(context, view, skin, { cell, time, accent: theme.accent, dead, travel });
            context.globalAlpha = 1;
        }
        particles?.draw(context, time);
        if (impact) this.drawImpact(impact, theme, cell);

        context.strokeStyle = css(mix(theme.line, theme.accent, 0.25), 0.9);
        context.lineWidth = 3;
        context.strokeRect(1.5, 1.5, width - 3, height - 3);
    }

    // Short flash plus an expanding ring at the point of impact (death animation).
    drawImpact({ x, y, elapsed }, theme, cell) {
        const context = this.context;
        if (elapsed < 140) {
            context.fillStyle = `rgba(255,255,255,${0.26 * (1 - elapsed / 140)})`;
            context.fillRect(0, 0, this.canvas.width, this.canvas.height);
        }
        const age = elapsed / 420;
        if (age >= 1) return;
        context.strokeStyle = css(mix(theme.accent, [255, 255, 255], 0.5), 0.85 * (1 - age));
        context.lineWidth = Math.max(1, cell * 0.16 * (1 - age));
        context.beginPath();
        context.arc(x * cell, y * cell, cell * (0.4 + 1.9 * (1 - (1 - age) ** 2)), 0, Math.PI * 2);
        context.stroke();
    }

    drawObstacles(map, theme, cell) {
        const context = this.context;
        const base = mix(theme.line, theme.surface, 0.15);
        map.obstacles.forEach(tile => {
            const x = tile.x * cell;
            const y = tile.y * cell;
            const inset = cell * 0.05;
            context.fillStyle = css(shade(base, -28));
            context.beginPath(); context.roundRect(x + inset, y + inset + cell * 0.07, cell - inset * 2, cell - inset * 2, cell * 0.2); context.fill();
            const gradient = context.createLinearGradient(x, y, x, y + cell);
            gradient.addColorStop(0, css(shade(base, 22)));
            gradient.addColorStop(1, css(base));
            context.fillStyle = gradient;
            context.beginPath(); context.roundRect(x + inset, y + inset, cell - inset * 2, cell - inset * 2 - cell * 0.07, cell * 0.2); context.fill();
            context.fillStyle = 'rgba(255,255,255,.12)';
            context.fillRect(x + cell * 0.2, y + cell * 0.14, cell * 0.6, cell * 0.06);
        });
    }

    drawPortals(map, theme, cell, time) {
        const context = this.context;
        (map.portals ?? []).forEach((portal, index) => {
            const x = (portal.x + 0.5) * cell;
            const y = (portal.y + 0.5) * cell;
            const color = index % 2 ? '#83c8ff' : theme.accent;
            context.strokeStyle = color;
            context.lineCap = 'round';
            for (let ring = 0; ring < 3; ring += 1) {
                context.globalAlpha = 0.85 - ring * 0.2;
                context.lineWidth = cell * 0.07;
                context.beginPath();
                const start = time / (500 - ring * 90) * (index % 2 ? -1 : 1) + ring * 2;
                context.arc(x, y, cell * (0.42 - ring * 0.11), start, start + Math.PI * 1.5);
                context.stroke();
            }
            context.globalAlpha = 1;
        });
    }
}
