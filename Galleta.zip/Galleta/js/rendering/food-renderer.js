import { css, shade } from './color.js';

const TAU = Math.PI * 2;

function radial(ctx, cx, cy, inner, outer, stops) {
    const gradient = ctx.createRadialGradient(cx, cy, inner, cx, cy, outer);
    stops.forEach(([offset, color]) => gradient.addColorStop(offset, color));
    return gradient;
}

function leaf(ctx, x, y, angle, length, fill, vein = 'rgba(0,70,0,.35)') {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(length * 0.5, -length * 0.42, length, 0);
    ctx.quadraticCurveTo(length * 0.5, length * 0.34, 0, 0);
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.strokeStyle = vein;
    ctx.lineWidth = 0.014;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(length * 0.85, 0);
    ctx.stroke();
    ctx.restore();
}

function sparkle(ctx, x, y, size, color = '#ffffff') {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x, y - size); ctx.quadraticCurveTo(x, y, x + size, y);
    ctx.quadraticCurveTo(x, y, x, y + size); ctx.quadraticCurveTo(x, y, x - size, y);
    ctx.quadraticCurveTo(x, y, x, y - size);
    ctx.fill();
}

function applePath(ctx) {
    ctx.moveTo(0, -0.3);
    ctx.bezierCurveTo(0.1, -0.42, 0.4, -0.4, 0.46, -0.1);
    ctx.bezierCurveTo(0.52, 0.2, 0.3, 0.46, 0.14, 0.46);
    ctx.bezierCurveTo(0.06, 0.46, 0.03, 0.42, 0, 0.42);
    ctx.bezierCurveTo(-0.03, 0.42, -0.06, 0.46, -0.14, 0.46);
    ctx.bezierCurveTo(-0.3, 0.46, -0.52, 0.2, -0.46, -0.1);
    ctx.bezierCurveTo(-0.4, -0.4, -0.1, -0.42, 0, -0.3);
    ctx.closePath();
}

function drawApple(ctx, palette) {
    ctx.beginPath();
    applePath(ctx);
    ctx.fillStyle = radial(ctx, -0.15, -0.12, 0.03, 0.66, [[0, palette.light], [0.5, palette.mid], [1, palette.dark]]);
    ctx.fill();
    ctx.lineWidth = 0.045;
    ctx.lineJoin = 'round';
    ctx.strokeStyle = palette.outline;
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,.42)';
    ctx.beginPath(); ctx.ellipse(-0.24, -0.13, 0.06, 0.12, 0.45, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#6a3f1c';
    ctx.lineWidth = 0.05;
    ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, -0.28); ctx.quadraticCurveTo(0.02, -0.4, 0.07, -0.47); ctx.stroke();
    leaf(ctx, 0.04, -0.4, -0.45, 0.3, '#5fc24a');
}

function drawOrange(ctx) {
    ctx.beginPath();
    for (let index = 0; index <= 56; index += 1) {
        const angle = (index / 56) * TAU;
        const radius = 0.43 + 0.012 * Math.sin(angle * 7) + 0.008 * Math.sin(angle * 13 + 1);
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius + 0.04;
        if (index) ctx.lineTo(x, y); else ctx.moveTo(x, y);
    }
    ctx.closePath();
    ctx.fillStyle = radial(ctx, -0.14, -0.08, 0.03, 0.62, [[0, '#ffc95a'], [0.5, '#ff9a1f'], [1, '#d4650a']]);
    ctx.fill();
    ctx.lineWidth = 0.04;
    ctx.strokeStyle = '#9c4a05';
    ctx.stroke();
    ctx.fillStyle = 'rgba(150,70,0,.35)';
    for (let index = 0; index < 18; index += 1) {
        const angle = index * 2.4;
        const radius = 0.08 + ((index * 37) % 25) / 100;
        ctx.beginPath();
        ctx.arc(Math.cos(angle) * radius, Math.sin(angle) * radius + 0.06, 0.012, 0, TAU);
        ctx.fill();
    }
    ctx.fillStyle = 'rgba(255,255,255,.4)';
    ctx.beginPath(); ctx.ellipse(-0.2, -0.12, 0.06, 0.11, 0.5, 0, TAU); ctx.fill();
    ctx.fillStyle = '#4a8a2a';
    ctx.beginPath(); ctx.arc(0, -0.37, 0.05, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#6a3f1c';
    ctx.lineWidth = 0.04;
    ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, -0.37); ctx.lineTo(0.01, -0.46); ctx.stroke();
    leaf(ctx, 0.02, -0.42, -0.35, 0.28, '#5fc24a');
}

function drawStrawberry(ctx) {
    ctx.beginPath();
    ctx.moveTo(0, 0.48);
    ctx.bezierCurveTo(-0.14, 0.46, -0.46, 0.18, -0.44, -0.14);
    ctx.bezierCurveTo(-0.42, -0.36, -0.18, -0.38, 0, -0.3);
    ctx.bezierCurveTo(0.18, -0.38, 0.42, -0.36, 0.44, -0.14);
    ctx.bezierCurveTo(0.46, 0.18, 0.14, 0.46, 0, 0.48);
    ctx.closePath();
    ctx.fillStyle = radial(ctx, -0.14, -0.1, 0.03, 0.62, [[0, '#ff7a90'], [0.5, '#e8284a'], [1, '#a81029']]);
    ctx.fill();
    ctx.lineWidth = 0.04;
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#6f0a1d';
    ctx.stroke();
    ctx.fillStyle = '#ffe9a3';
    [[-0.22, -0.08], [0, -0.12], [0.22, -0.08], [-0.12, 0.06], [0.12, 0.06], [-0.28, 0.1], [0.28, 0.1], [0, 0.2], [-0.14, 0.24], [0.14, 0.24], [0, 0.36]].forEach(([x, y]) => {
        ctx.beginPath(); ctx.ellipse(x, y, 0.016, 0.026, 0, 0, TAU); ctx.fill();
    });
    ctx.fillStyle = 'rgba(255,255,255,.35)';
    ctx.beginPath(); ctx.ellipse(-0.26, -0.18, 0.05, 0.09, 0.3, 0, TAU); ctx.fill();
    [-1.15, -0.6, 0, 0.6, 1.15].forEach(angle => leaf(ctx, 0, -0.3, angle - Math.PI / 2, 0.22, angle === 0 ? '#58b843' : '#3f9a35', 'rgba(0,60,0,.3)'));
    ctx.strokeStyle = '#3f9a35';
    ctx.lineWidth = 0.05;
    ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, -0.3); ctx.lineTo(0.02, -0.46); ctx.stroke();
}

function drawCherries(ctx) {
    ctx.strokeStyle = '#4f8a35';
    ctx.lineWidth = 0.035;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-0.2, 0.06); ctx.quadraticCurveTo(-0.14, -0.28, 0.05, -0.42);
    ctx.moveTo(0.2, 0.1); ctx.quadraticCurveTo(0.14, -0.26, 0.05, -0.42);
    ctx.stroke();
    leaf(ctx, 0.05, -0.42, -0.2, 0.3, '#5fc24a');
    [[-0.2, 0.26], [0.2, 0.3]].forEach(([x, y]) => {
        ctx.beginPath();
        ctx.arc(x, y, 0.21, 0, TAU);
        ctx.fillStyle = radial(ctx, x - 0.07, y - 0.08, 0.02, 0.3, [[0, '#ff6a84'], [0.5, '#d4153a'], [1, '#7e0b1e']]);
        ctx.fill();
        ctx.lineWidth = 0.03;
        ctx.strokeStyle = '#5a0716';
        ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,.6)';
        ctx.beginPath(); ctx.ellipse(x - 0.08, y - 0.08, 0.035, 0.055, 0.5, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(80,0,10,.4)';
        ctx.beginPath(); ctx.arc(x, y - 0.17, 0.03, 0, TAU); ctx.fill();
    });
}

function drawWatermelon(ctx) {
    ctx.save();
    ctx.rotate(-0.2);
    ctx.translate(0, -0.2);
    const slice = radius => { ctx.beginPath(); ctx.arc(0, 0, radius, 0, Math.PI); ctx.closePath(); };
    ctx.scale(1, 1.15);
    slice(0.5);
    ctx.fillStyle = '#2f8f3a';
    ctx.fill();
    ctx.lineWidth = 0.04;
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#175a22';
    ctx.stroke();
    ctx.strokeStyle = 'rgba(190,240,120,.55)';
    ctx.lineWidth = 0.025;
    for (const angle of [0.35, 0.8, 1.3, 1.8, 2.3, 2.8]) {
        ctx.beginPath();
        ctx.moveTo(Math.cos(angle) * 0.44, Math.sin(angle) * 0.44);
        ctx.lineTo(Math.cos(angle) * 0.5, Math.sin(angle) * 0.5);
        ctx.stroke();
    }
    slice(0.43);
    ctx.fillStyle = '#d6f3a3';
    ctx.fill();
    slice(0.38);
    ctx.fillStyle = radial(ctx, 0, 0, 0.02, 0.42, [[0, '#ff6b78'], [1, '#e0243b']]);
    ctx.fill();
    ctx.fillStyle = '#1a1112';
    [[-0.22, 0.12], [0, 0.2], [0.22, 0.12], [-0.1, 0.3], [0.12, 0.3], [-0.3, 0.26]].forEach(([x, y]) => {
        ctx.beginPath(); ctx.ellipse(x, y, 0.02, 0.035, 0, 0, TAU); ctx.fill();
    });
    ctx.restore();
}

function roundedPath(ctx, x, y, width, height, radii) {
    ctx.beginPath();
    ctx.roundRect(x, y, width, height, radii);
}

function drawBurger(ctx) {
    const outline = '#4a2a0c';
    ctx.lineWidth = 0.03;
    ctx.strokeStyle = outline;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(-0.46, -0.03);
    ctx.bezierCurveTo(-0.46, -0.38, -0.2, -0.5, 0, -0.5);
    ctx.bezierCurveTo(0.2, -0.5, 0.46, -0.38, 0.46, -0.03);
    ctx.closePath();
    ctx.fillStyle = radial(ctx, -0.12, -0.38, 0.02, 0.6, [[0, '#f2b45e'], [0.6, '#dc9340'], [1, '#b9722a']]);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#fff0c4';
    [[-0.22, -0.28, -0.5], [0, -0.38, 0.2], [0.2, -0.26, 0.6], [-0.08, -0.17, 0.1], [0.3, -0.12, -0.3], [-0.34, -0.12, 0.7]].forEach(([x, y, angle]) => {
        ctx.beginPath(); ctx.ellipse(x, y, 0.03, 0.016, angle, 0, TAU); ctx.fill();
    });
    ctx.fillStyle = '#5fbf3f';
    ctx.beginPath();
    ctx.moveTo(-0.5, -0.03);
    for (let index = 0; index <= 5; index += 1) ctx.quadraticCurveTo(-0.5 + (index + 0.5) * 0.2, 0.1, -0.5 + (index + 1) * 0.2, -0.03);
    ctx.lineTo(0.5, -0.03);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#ffcf3d';
    ctx.beginPath();
    ctx.moveTo(-0.44, 0.04); ctx.lineTo(0.44, 0.04); ctx.lineTo(0.36, 0.12); ctx.lineTo(0.1, 0.12); ctx.lineTo(0.02, 0.2); ctx.lineTo(-0.08, 0.12); ctx.lineTo(-0.36, 0.12);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    roundedPath(ctx, -0.46, 0.1, 0.92, 0.15, 0.07);
    ctx.fillStyle = '#6b3b1f';
    ctx.fill();
    ctx.stroke();
    roundedPath(ctx, -0.46, 0.25, 0.92, 0.17, [0.02, 0.02, 0.1, 0.1]);
    ctx.fillStyle = '#d98d3a';
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,.28)';
    ctx.beginPath(); ctx.ellipse(-0.2, -0.36, 0.1, 0.045, -0.5, 0, TAU); ctx.fill();
}

function drawBerry(ctx, accent) {
    ctx.beginPath();
    ctx.arc(0, 0.04, 0.39, 0, TAU);
    ctx.fillStyle = radial(ctx, -0.13, -0.08, 0.03, 0.55, [[0, css(shade(accent, 45))], [0.5, css(accent)], [1, css(shade(accent, -38))]]);
    ctx.fill();
    ctx.lineWidth = 0.04;
    ctx.strokeStyle = css(shade(accent, -62));
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,.5)';
    ctx.beginPath(); ctx.ellipse(-0.17, -0.07, 0.06, 0.1, 0.5, 0, TAU); ctx.fill();
    ctx.fillStyle = '#4a9a35';
    for (let index = 0; index < 5; index += 1) {
        const angle = -Math.PI / 2 + (index - 2) * 0.55;
        ctx.save();
        ctx.translate(0, -0.3);
        ctx.rotate(angle + Math.PI / 2);
        ctx.beginPath(); ctx.moveTo(-0.045, 0); ctx.lineTo(0, -0.13); ctx.lineTo(0.045, 0); ctx.closePath(); ctx.fill();
        ctx.restore();
    }
}

function drawCrystal(ctx, time) {
    const facets = [
        [[-0.28, -0.34], [0.28, -0.34], [0.18, -0.08], [-0.18, -0.08]],
        [[-0.28, -0.34], [-0.5, -0.08], [-0.18, -0.08]],
        [[0.28, -0.34], [0.5, -0.08], [0.18, -0.08]],
        [[-0.5, -0.08], [-0.18, -0.08], [0, 0.5]],
        [[-0.18, -0.08], [0.18, -0.08], [0, 0.5]],
        [[0.18, -0.08], [0.5, -0.08], [0, 0.5]]
    ];
    const colors = ['#e6fbff', '#9cecff', '#8fe6ff', '#3fb4ea', '#7cdcfb', '#2f8fd2'];
    facets.forEach((points, index) => {
        ctx.beginPath();
        points.forEach(([x, y], pointIndex) => (pointIndex ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
        ctx.closePath();
        ctx.fillStyle = colors[index];
        ctx.fill();
        ctx.lineWidth = 0.025;
        ctx.lineJoin = 'round';
        ctx.strokeStyle = '#1d5f9c';
        ctx.stroke();
    });
    sparkle(ctx, 0.12, -0.24, 0.07 + 0.03 * Math.sin(time / 240), 'rgba(255,255,255,.95)');
}

function drawStar(ctx, radius, inner) {
    ctx.beginPath();
    for (let index = 0; index < 10; index += 1) {
        const angle = -Math.PI / 2 + index * Math.PI / 5;
        const length = index % 2 ? inner : radius;
        if (index) ctx.lineTo(Math.cos(angle) * length, Math.sin(angle) * length); else ctx.moveTo(Math.cos(angle) * length, Math.sin(angle) * length);
    }
    ctx.closePath();
}

function drawCoin(ctx, time) {
    ctx.save();
    ctx.scale(0.82 + 0.18 * Math.cos(time / 500), 1);
    ctx.beginPath();
    ctx.arc(0, 0, 0.43, 0, TAU);
    ctx.fillStyle = radial(ctx, -0.14, -0.14, 0.03, 0.55, [[0, '#fff0a0'], [0.55, '#ffc928'], [1, '#c98f10']]);
    ctx.fill();
    ctx.lineWidth = 0.045;
    ctx.strokeStyle = '#8a5a05';
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, 0.32, 0, TAU);
    ctx.lineWidth = 0.025;
    ctx.strokeStyle = 'rgba(138,90,5,.7)';
    ctx.stroke();
    drawStar(ctx, 0.2, 0.09);
    ctx.fillStyle = '#e0a012';
    ctx.fill();
    ctx.strokeStyle = '#8a5a05';
    ctx.lineWidth = 0.02;
    ctx.stroke();
    ctx.restore();
}

const APPLE_RED = { light: '#ff7a6a', mid: '#e03030', dark: '#a01a25', outline: '#6e1118' };
const APPLE_GOLD = { light: '#fff7b8', mid: '#ffd23d', dark: '#d9960f', outline: '#8a5a05' };

const DRAWERS = {
    food_berry: (ctx, env) => drawBerry(ctx, env.themeFood),
    food_apple: ctx => drawApple(ctx, APPLE_RED),
    food_orange: drawOrange,
    food_strawberry: drawStrawberry,
    food_cherries: drawCherries,
    food_watermelon: drawWatermelon,
    food_burger: drawBurger,
    food_crystal: (ctx, env) => drawCrystal(ctx, env.time),
    food_coin: (ctx, env) => drawCoin(ctx, env.time),
    food_golden: (ctx, env) => {
        drawApple(ctx, APPLE_GOLD);
        sparkle(ctx, 0.22, -0.2, 0.08 + 0.05 * Math.abs(Math.sin(env.time / 280)));
        sparkle(ctx, -0.26, 0.14, 0.05 + 0.04 * Math.abs(Math.sin(env.time / 350 + 1)));
    }
};

/**
 * Draws a food item centered at (x, y). `size` is the item's full width in pixels;
 * `scale` lets the game shrink an item while the snake swallows it.
 */
export function drawFood(ctx, foodId, x, y, size, { time = 0, themeFood = '#fa6685', scale = 1, animate = true } = {}) {
    const drawer = DRAWERS[foodId] ?? DRAWERS.food_berry;
    const bob = animate ? Math.sin(time / 300) * 0.025 : 0;
    ctx.save();
    ctx.translate(x, y + bob * size);
    ctx.scale(size * scale, size * scale);
    if (animate) ctx.rotate(Math.sin(time / 700) * 0.05);
    ctx.fillStyle = 'rgba(0,0,0,.2)';
    ctx.beginPath();
    ctx.ellipse(0, 0.46, 0.28, 0.055, 0, 0, TAU);
    ctx.fill();
    drawer(ctx, { time, themeFood });
    ctx.restore();
}
