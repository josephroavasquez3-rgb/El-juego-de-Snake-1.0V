import { css, gradientLookup, lookup, resolveToken } from './color.js';
import { HERO_EYES, HERO_HEAD_BACK, HERO_HEAD_FRONT, HERO_HEAD_SHAPES, HERO_PATTERNS } from './hero-parts.js';
import { TAU, hash, marks, normalOf, setTravel, sparkle } from './snake-utils.js';

export class SmoothPath {
    constructor(points) {
        this.points = points;
        this.cum = [0];
        for (let index = 1; index < points.length; index += 1) {
            this.cum.push(this.cum[index - 1] + Math.hypot(points[index].x - points[index - 1].x, points[index].y - points[index - 1].y));
        }
        this.total = this.cum[this.cum.length - 1] ?? 0;
    }

    at(distance) {
        const points = this.points;
        if (points.length === 1) return { x: points[0].x, y: points[0].y, angle: 0 };
        const s = Math.min(this.total, Math.max(0, distance));
        let low = 0;
        let high = this.cum.length - 1;
        while (high - low > 1) {
            const middle = (low + high) >> 1;
            if (this.cum[middle] <= s) low = middle; else high = middle;
        }
        const from = points[low];
        const to = points[low + 1];
        const length = this.cum[low + 1] - this.cum[low] || 1;
        const amount = (s - this.cum[low]) / length;
        return { x: from.x + (to.x - from.x) * amount, y: from.y + (to.y - from.y) * amount, angle: Math.atan2(to.y - from.y, to.x - from.x) };
    }

    // Keeps only the part of the path closest to the head.
    slice(length) {
        if (length >= this.total) return this;
        const points = [];
        for (let index = 0; index < this.points.length && this.cum[index] < length; index += 1) points.push(this.points[index]);
        const end = this.at(length);
        points.push({ x: end.x, y: end.y });
        return new SmoothPath(points);
    }
}

// Shortens a snake view from the tail so only `keep` cells of body remain (used by the death animation).
export function trimSnakeView(view, keep) {
    let remaining = keep;
    const paths = [];
    for (const path of view.paths) {
        if (remaining <= 0.001) break;
        paths.push(path.slice(remaining));
        remaining -= path.total;
    }
    return { paths, bulges: view.bulges };
}

// Death animation phases in ms: impact freeze, dissolve from the tail, final fade of the head.
export const DEATH = { hit: 140, dissolve: 860, fade: 200, minBody: 0.6 };
export const DEATH_MS = DEATH.hit + DEATH.dissolve + DEATH.fade;

export function dissolveView(view, elapsed, scale = 1) {
    const total = view.paths.reduce((sum, path) => sum + path.total, 0);
    const amount = Math.min(1, Math.max(0, (elapsed - DEATH.hit * scale) / (DEATH.dissolve * scale)));
    const eased = amount * amount * (3 - 2 * amount);
    const fadeStart = (DEATH.hit + DEATH.dissolve) * scale;
    return {
        view: trimSnakeView(view, Math.max(Math.min(total, DEATH.minBody), total * (1 - eased))),
        fade: elapsed > fadeStart ? Math.max(0, 1 - (elapsed - fadeStart) / (DEATH.fade * scale)) : 1,
        dissolving: amount > 0 && amount < 1
    };
}

// Rounds every corner with a quadratic curve so turns are continuous and never leave gaps.
export function smoothPath(raw) {
    const points = [];
    for (const point of raw) {
        const last = points[points.length - 1];
        if (!last || Math.hypot(point.x - last.x, point.y - last.y) > 1e-3) points.push({ x: point.x, y: point.y });
    }
    if (points.length < 3) return new SmoothPath(points);
    const out = [points[0]];
    for (let index = 1; index < points.length - 1; index += 1) {
        const previous = points[index - 1];
        const current = points[index];
        const next = points[index + 1];
        const d1 = Math.hypot(current.x - previous.x, current.y - previous.y);
        const d2 = Math.hypot(next.x - current.x, next.y - current.y);
        const cross = ((current.x - previous.x) * (next.y - current.y) - (current.y - previous.y) * (next.x - current.x)) / (d1 * d2);
        if (Math.abs(cross) < 1e-3) {
            out.push(current);
            continue;
        }
        const cut = Math.min(0.5, d1 / 2, d2 / 2);
        const a = { x: current.x + (previous.x - current.x) * cut / d1, y: current.y + (previous.y - current.y) * cut / d1 };
        const b = { x: current.x + (next.x - current.x) * cut / d2, y: current.y + (next.y - current.y) * cut / d2 };
        out.push(a);
        for (let step = 1; step < 8; step += 1) {
            const t = step / 8;
            const inverse = 1 - t;
            out.push({
                x: inverse * inverse * a.x + 2 * inverse * t * current.x + t * t * b.x,
                y: inverse * inverse * a.y + 2 * inverse * t * current.y + t * t * b.y
            });
        }
        out.push(b);
    }
    out.push(points[points.length - 1]);
    return new SmoothPath(out);
}

const adjacent = (a, b) => Math.abs(a.x - b.x) + Math.abs(a.y - b.y) <= 1.001;

/**
 * Builds the continuous visual path of the snake from its logical grid cells.
 * `progress` (0..1) is how far the head has travelled toward its logical cell;
 * `tailFrom` is the cell the tail just left (null while growing).
 */
export function buildSnakeView(cells, progress = 1, tailFrom = null, bulges = []) {
    const points = cells.map(cell => ({ x: cell.x + 0.5, y: cell.y + 0.5 }));
    if (points.length > 1 && adjacent(cells[0], cells[1])) {
        points[0] = {
            x: points[1].x + (points[0].x - points[1].x) * progress,
            y: points[1].y + (points[0].y - points[1].y) * progress
        };
    }
    const last = cells[cells.length - 1];
    if (tailFrom && progress < 1 && adjacent(tailFrom, last)) {
        points.push({
            x: last.x + 0.5 + (tailFrom.x - last.x) * (1 - progress),
            y: last.y + 0.5 + (tailFrom.y - last.y) * (1 - progress)
        });
    }
    const runs = [[points[0]]];
    for (let index = 1; index < points.length; index += 1) {
        if (Math.hypot(points[index].x - points[index - 1].x, points[index].y - points[index - 1].y) > 1.5) runs.push([]);
        runs[runs.length - 1].push(points[index]);
    }
    return { paths: runs.map(run => smoothPath(run)), bulges };
}

function headAngle(path) {
    const head = path.at(0);
    const behind = path.at(Math.min(0.45, path.total));
    return Math.hypot(head.x - behind.x, head.y - behind.y) < 1e-4 ? 0 : Math.atan2(head.y - behind.y, head.x - behind.x);
}

function tracePath(ctx, path) {
    ctx.beginPath();
    path.points.forEach((point, index) => (index ? ctx.lineTo(point.x, point.y) : ctx.moveTo(point.x, point.y)));
}

const PATTERNS = {
    dorsal(ctx, run, skin, env, widthAt) {
        const dark = css(resolveToken(skin.pattern.dark, env.accent), 0.5);
        const light = css(resolveToken(skin.pattern.light, env.accent), 0.55);
        marks(run.path, 0.56, 0.5, (p, s) => {
            const w = widthAt(s);
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.angle);
            ctx.fillStyle = dark;
            ctx.beginPath();
            ctx.moveTo(-0.22, 0); ctx.lineTo(0, -0.17 * w); ctx.lineTo(0.22, 0); ctx.lineTo(0, 0.17 * w);
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = light;
            ctx.beginPath();
            ctx.arc(0.28, 0, 0.035, 0, TAU);
            ctx.fill();
            ctx.restore();
        });
    },
    rim(ctx, run, skin, env) {
        tracePath(ctx, run.path);
        ctx.strokeStyle = 'rgba(220,255,250,.55)';
        ctx.lineWidth = 0.07;
        ctx.stroke();
        const phase = (env.time * 0.004) % 2;
        marks(run.path, 2, phase, p => {
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(p.x, p.y, 0.09, 0, TAU);
            ctx.fill();
        });
    },
    flames(ctx, run, skin, env, widthAt) {
        marks(run.path, 0.62, 0.35, (p, s, k) => {
            const w = widthAt(s);
            const n = normalOf(p.angle);
            const flicker = 0.34 + 0.14 * Math.sin(env.time / 110 + k * 1.7);
            const dx = Math.cos(p.angle);
            const dy = Math.sin(p.angle);
            for (const [length, color] of [[flicker, 'rgba(255,92,30,.9)'], [flicker * 0.55, 'rgba(255,226,130,.95)']]) {
                const half = 0.13 * w * (length / flicker);
                ctx.fillStyle = color;
                ctx.beginPath();
                ctx.moveTo(p.x + n.x * half, p.y + n.y * half);
                ctx.quadraticCurveTo(p.x + dx * length * 0.5 + n.x * half * 1.1, p.y + dy * length * 0.5 + n.y * half * 1.1, p.x + dx * length * 1.3, p.y + dy * length * 1.3);
                ctx.quadraticCurveTo(p.x + dx * length * 0.5 - n.x * half * 1.1, p.y + dy * length * 0.5 - n.y * half * 1.1, p.x - n.x * half, p.y - n.y * half);
                ctx.closePath();
                ctx.fill();
            }
        });
    },
    facets(ctx, run, skin, env, widthAt) {
        marks(run.path, 0.5, 0.4, (p, s, k) => {
            const w = widthAt(s);
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.angle);
            ctx.fillStyle = k % 2 ? 'rgba(20,90,170,.22)' : 'rgba(255,255,255,.34)';
            ctx.strokeStyle = 'rgba(255,255,255,.55)';
            ctx.lineWidth = 0.02;
            ctx.beginPath();
            ctx.moveTo(-0.25, 0); ctx.lineTo(0, -0.27 * w); ctx.lineTo(0.25, 0); ctx.lineTo(0, 0.27 * w);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        });
        marks(run.path, 2.7, 1.3, (p, s, k) => {
            const twinkle = 0.45 + 0.55 * Math.abs(Math.sin(env.time / 320 + k * 2.1));
            sparkle(ctx, p.x, p.y, 0.13 * twinkle, 'rgba(255,255,255,.95)');
        });
    },
    arcs(ctx, run, skin, env, widthAt) {
        const path = run.path;
        for (const [width, alpha, color] of [[0.11, 0.3, '160,120,255'], [0.04, 0.95, '245,235,255']]) {
            ctx.beginPath();
            for (let s = 0, k = 0; s <= path.total; s += 0.22, k += 1) {
                const p = path.at(s);
                const n = normalOf(p.angle);
                const jitter = Math.sin(env.time / 70 + s * 6.3) * 0.14 * widthAt(s) * (k % 2 ? 1 : -1);
                if (s === 0) ctx.moveTo(p.x + n.x * jitter, p.y + n.y * jitter); else ctx.lineTo(p.x + n.x * jitter, p.y + n.y * jitter);
            }
            ctx.lineWidth = width;
            ctx.lineJoin = 'round';
            ctx.strokeStyle = `rgba(${color},${alpha})`;
            ctx.stroke();
        }
        marks(path, 0.95, 0.45, (p, s, k) => {
            const pulse = 0.6 + 0.4 * Math.sin(env.time / 160 + k * 1.9);
            ctx.fillStyle = `rgba(255,255,255,${0.35 + pulse * 0.4})`;
            ctx.beginPath();
            ctx.arc(p.x, p.y, 0.07 + pulse * 0.04, 0, TAU);
            ctx.fill();
        });
    },
    plates(ctx, run, skin, env, widthAt) {
        const cyan = css(resolveToken(skin.pattern.color, env.accent));
        marks(run.path, 0.44, 0.3, (p, s, k) => {
            const w = widthAt(s) * skin.width;
            const n = normalOf(p.angle);
            ctx.strokeStyle = 'rgba(0,0,0,.45)';
            ctx.lineWidth = 0.05;
            ctx.beginPath();
            ctx.moveTo(p.x + n.x * w * 0.5, p.y + n.y * w * 0.5);
            ctx.lineTo(p.x - n.x * w * 0.5, p.y - n.y * w * 0.5);
            ctx.stroke();
            if (k % 2 === 0) {
                ctx.strokeStyle = cyan;
                ctx.lineWidth = 0.035;
                const dx = Math.cos(p.angle) * 0.1;
                const dy = Math.sin(p.angle) * 0.1;
                ctx.beginPath();
                ctx.moveTo(p.x + dx + n.x * w * 0.32, p.y + dy + n.y * w * 0.32);
                ctx.lineTo(p.x + dx - n.x * w * 0.32, p.y + dy - n.y * w * 0.32);
                ctx.stroke();
            }
            if (k % 3 === 1) {
                ctx.fillStyle = Math.sin(env.time / 260 + k) > -0.3 ? '#d7ffff' : cyan;
                ctx.fillRect(p.x + n.x * w * 0.28 - 0.035, p.y + n.y * w * 0.28 - 0.035, 0.07, 0.07);
            }
        });
    },
    wisps(ctx, run, skin, env, widthAt) {
        marks(run.path, 0.62, 0.3, (p, s, k) => {
            const n = normalOf(p.angle);
            const offset = Math.sin(k * 1.9 + env.time / 700) * 0.18 * widthAt(s);
            ctx.fillStyle = 'rgba(255,255,255,.38)';
            ctx.beginPath();
            ctx.arc(p.x + n.x * offset, p.y + n.y * offset, 0.09 + 0.03 * Math.sin(k + env.time / 400), 0, TAU);
            ctx.fill();
        });
    },
    rings(ctx, run, skin, env, widthAt) {
        marks(run.path, 0.42, 0.3, (p, s) => {
            const w = widthAt(s) * skin.width * 0.5;
            const n = normalOf(p.angle);
            const dx = Math.cos(p.angle);
            const dy = Math.sin(p.angle);
            ctx.lineWidth = 0.045;
            for (const [offset, color] of [[0, 'rgba(110,64,4,.65)'], [0.05, 'rgba(255,250,200,.5)']]) {
                ctx.strokeStyle = color;
                ctx.beginPath();
                ctx.moveTo(p.x + dx * offset + n.x * w, p.y + dy * offset + n.y * w);
                ctx.quadraticCurveTo(p.x - dx * 0.12 + dx * offset, p.y - dy * 0.12 + dy * offset, p.x + dx * offset - n.x * w, p.y + dy * offset - n.y * w);
                ctx.stroke();
            }
        });
        const glint = ((env.time / 900) % (run.path.total + 6)) - 3;
        if (glint >= 0 && glint <= run.path.total) {
            const p = run.path.at(glint);
            ctx.fillStyle = 'rgba(255,255,255,.28)';
            ctx.beginPath(); ctx.arc(p.x, p.y, 0.3, 0, TAU); ctx.fill();
            ctx.fillStyle = 'rgba(255,255,255,.55)';
            ctx.beginPath(); ctx.arc(p.x, p.y, 0.15, 0, TAU); ctx.fill();
        }
    },
    stars(ctx, run, skin, env, widthAt) {
        marks(run.path, 0.3, 0.2, (p, s, k) => {
            const n = normalOf(p.angle);
            const w = widthAt(s) * skin.width;
            if (k % 4 === 0) {
                ctx.fillStyle = `rgba(${hash(k + 9) > 0.5 ? '255,130,225' : '110,200,255'},.2)`;
                ctx.beginPath();
                ctx.arc(p.x + n.x * (hash(k) - 0.5) * w, p.y + n.y * (hash(k) - 0.5) * w, 0.22, 0, TAU);
                ctx.fill();
            }
            const offset = (hash(k * 3.1) - 0.5) * w * 0.85;
            const twinkle = 0.35 + 0.65 * Math.abs(Math.sin(env.time / 420 + k * 1.3));
            if (k % 9 === 3) sparkle(ctx, p.x + n.x * offset, p.y + n.y * offset, 0.12 * twinkle + 0.03, '#ffffff');
            else {
                ctx.fillStyle = `rgba(255,255,255,${0.35 + twinkle * 0.5})`;
                ctx.beginPath();
                ctx.arc(p.x + n.x * offset, p.y + n.y * offset, 0.022 + hash(k * 7.7) * 0.03, 0, TAU);
                ctx.fill();
            }
        });
    },
    cracks(ctx, run, skin, env, widthAt) {
        marks(run.path, 0.52, 0.3, (p, s, k) => {
            const w = widthAt(s) * skin.width * 0.5;
            const n = normalOf(p.angle);
            const dx = Math.cos(p.angle);
            const dy = Math.sin(p.angle);
            const pulse = 0.65 + 0.35 * Math.sin(env.time / 340 + k * 1.4);
            const bend = (hash(k) - 0.5) * 0.3;
            const points = [[-0.8, 0], [-0.25, bend], [0.3, -bend * 0.7], [0.85, 0.05]].map(([across, along]) => ({
                x: p.x + n.x * across * w + dx * along,
                y: p.y + n.y * across * w + dy * along
            }));
            for (const [width, color] of [[0.07, `rgba(255,110,20,${0.55 * pulse})`], [0.03, `rgba(255,228,150,${0.95 * pulse})`]]) {
                ctx.strokeStyle = color;
                ctx.lineWidth = width;
                ctx.lineJoin = 'round';
                ctx.beginPath();
                points.forEach((point, index) => (index ? ctx.lineTo(point.x, point.y) : ctx.moveTo(point.x, point.y)));
                ctx.stroke();
            }
        });
    }
};

const HEAD_SHAPES = {
    blob: ctx => { ctx.ellipse(0.05, 0, 0.54, 0.47, 0, 0, TAU); },
    wedge: ctx => {
        ctx.moveTo(0.6, 0); ctx.lineTo(0.22, -0.46); ctx.lineTo(-0.3, -0.42); ctx.lineTo(-0.44, -0.1);
        ctx.lineTo(-0.44, 0.1); ctx.lineTo(-0.3, 0.42); ctx.lineTo(0.22, 0.46); ctx.closePath();
    },
    crystal: ctx => {
        ctx.moveTo(0.62, 0); ctx.lineTo(0.18, -0.47); ctx.lineTo(-0.34, -0.36); ctx.lineTo(-0.46, 0);
        ctx.lineTo(-0.34, 0.36); ctx.lineTo(0.18, 0.47); ctx.closePath();
    }
};

const HEAD_BACK = {
    crest(ctx, skin, env) {
        for (const [y, length, phase] of [[-0.24, 0.42, 0], [0, 0.55, 1.7], [0.24, 0.42, 3.1]]) {
            const flick = length + Math.sin(env.time / 100 + phase) * 0.1;
            for (const [scale, color] of [[1, '#ff5a1f'], [0.55, '#ffe08a']]) {
                ctx.fillStyle = color;
                ctx.beginPath();
                ctx.moveTo(-0.15, y - 0.12 * scale); ctx.quadraticCurveTo(-0.15 - flick * 0.5 * scale, y - 0.1 * scale, -0.18 - flick * scale, y);
                ctx.quadraticCurveTo(-0.15 - flick * 0.5 * scale, y + 0.1 * scale, -0.15, y + 0.12 * scale);
                ctx.closePath();
                ctx.fill();
            }
        }
    },
    horns(ctx) {
        for (const side of [-1, 1]) {
            ctx.fillStyle = '#1a0a07';
            ctx.beginPath();
            ctx.moveTo(0, side * 0.32); ctx.quadraticCurveTo(-0.2, side * 0.5, -0.48, side * 0.52); ctx.quadraticCurveTo(-0.28, side * 0.32, -0.18, side * 0.18);
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = '#ff7a1a';
            ctx.beginPath();
            ctx.moveTo(-0.34, side * 0.46); ctx.lineTo(-0.5, side * 0.54); ctx.lineTo(-0.4, side * 0.4);
            ctx.closePath();
            ctx.fill();
        }
    }
};

const HEAD_FRONT = {
    crown(ctx) {
        for (const [x, y] of [[-0.2, 0], [-0.12, -0.22], [-0.12, 0.22]]) {
            ctx.fillStyle = '#ff4a63';
            ctx.beginPath(); ctx.arc(x, y, 0.07, 0, TAU); ctx.fill();
            ctx.fillStyle = 'rgba(255,255,255,.8)';
            ctx.beginPath(); ctx.arc(x - 0.02, y - 0.02, 0.022, 0, TAU); ctx.fill();
        }
    },
    facets(ctx) {
        ctx.strokeStyle = 'rgba(255,255,255,.6)';
        ctx.lineWidth = 0.025;
        ctx.beginPath();
        for (const [x, y] of [[0.18, -0.47], [-0.34, -0.36], [-0.34, 0.36], [0.18, 0.47], [0.62, 0]]) { ctx.moveTo(0, 0); ctx.lineTo(x, y); }
        ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,.35)';
        ctx.beginPath(); ctx.moveTo(0.5, 0); ctx.lineTo(0.18, -0.4); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
    },
    cracks(ctx, skin, env) {
        const pulse = 0.65 + 0.35 * Math.sin(env.time / 340);
        ctx.strokeStyle = `rgba(255,150,40,${pulse})`;
        ctx.lineWidth = 0.04;
        ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(-0.38, 0); ctx.lineTo(-0.2, 0.06); ctx.lineTo(-0.05, -0.04); ctx.lineTo(0.08, 0.02);
        ctx.moveTo(-0.2, 0.06); ctx.lineTo(-0.14, 0.26);
        ctx.moveTo(-0.05, -0.04); ctx.lineTo(0.02, -0.28);
        ctx.stroke();
    },
    stars(ctx, skin, env) {
        for (const [x, y, k] of [[-0.18, -0.12, 1], [-0.3, 0.1, 2], [0.02, 0.0, 3], [-0.1, 0.22, 4]]) {
            sparkle(ctx, x, y, 0.045 + 0.03 * Math.abs(Math.sin(env.time / 300 + k)), '#ffffff');
        }
    },
    bolts(ctx, skin, env) {
        ctx.strokeStyle = `rgba(250,240,255,${0.65 + 0.3 * Math.sin(env.time / 90)})`;
        ctx.lineWidth = 0.035;
        ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(-0.32, -0.08); ctx.lineTo(-0.16, 0.06); ctx.lineTo(-0.04, -0.07); ctx.lineTo(0.1, 0.05);
        ctx.stroke();
    },
    rim(ctx) {
        ctx.strokeStyle = 'rgba(220,255,250,.7)';
        ctx.lineWidth = 0.04;
        ctx.beginPath(); ctx.moveTo(-0.3, 0); ctx.lineTo(0.2, 0); ctx.stroke();
    },
    gloss(ctx) {
        ctx.fillStyle = 'rgba(255,255,255,.22)';
        ctx.beginPath(); ctx.ellipse(0.1, -0.2, 0.22, 0.09, -0.15, 0, TAU); ctx.fill();
    }
};

function drawEyes(ctx, eye, env) {
    const size = eye.size ?? 0.115;
    if (!env.dead && HERO_EYES[eye.style]) {
        HERO_EYES[eye.style](ctx, eye, env);
        return;
    }
    if (env.dead) {
        ctx.strokeStyle = eye.pupil ?? '#111';
        ctx.lineWidth = 0.04;
        ctx.lineCap = 'round';
        for (const side of [-1, 1]) {
            const x = 0.2;
            const y = side * 0.2;
            ctx.beginPath();
            ctx.moveTo(x - 0.07, y - 0.07); ctx.lineTo(x + 0.07, y + 0.07);
            ctx.moveTo(x + 0.07, y - 0.07); ctx.lineTo(x - 0.07, y + 0.07);
            ctx.stroke();
        }
        return;
    }
    if (eye.style === 'visor') {
        ctx.fillStyle = 'rgba(0,0,0,.55)';
        ctx.beginPath(); ctx.roundRect(0.1, -0.31, 0.2, 0.62, 0.08); ctx.fill();
        ctx.fillStyle = eye.glow ?? '#48dfdc';
        ctx.beginPath(); ctx.roundRect(0.15, -0.26, 0.1, 0.52, 0.05); ctx.fill();
        return;
    }
    for (const side of [-1, 1]) {
        const x = 0.2;
        const y = side * 0.2;
        if (eye.glow) {
            ctx.fillStyle = css(eye.glow, 0.32);
            ctx.beginPath(); ctx.arc(x, y, size * 1.9, 0, TAU); ctx.fill();
        }
        ctx.fillStyle = eye.white ?? '#ffffff';
        ctx.beginPath(); ctx.arc(x, y, size, 0, TAU); ctx.fill();
        ctx.fillStyle = eye.pupil ?? '#10201a';
        ctx.beginPath();
        if (eye.style === 'slit') ctx.ellipse(x + 0.015, y, size * 0.32, size * 0.82, 0, 0, TAU);
        else ctx.arc(x + size * 0.28, y, size * 0.55, 0, TAU);
        ctx.fill();
    }
}

function drawHead(ctx, skin, env, view) {
    const head = skin.head;
    const path = view.paths[0];
    const position = path.at(0);
    ctx.save();
    ctx.translate(position.x, position.y);
    ctx.rotate(headAngle(path));
    if (head.tongue && !env.dead) {
        const phase = (env.time % 3400) / 3400;
        const extension = phase < 0.16 ? Math.sin(phase / 0.16 * Math.PI) : 0;
        if (extension > 0.02) {
            const reach = 0.5 + 0.42 * extension;
            ctx.strokeStyle = '#ff4a5e';
            ctx.lineWidth = 0.05;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(0.45, 0); ctx.lineTo(reach, 0);
            ctx.moveTo(reach, 0); ctx.lineTo(reach + 0.1, -0.07);
            ctx.moveTo(reach, 0); ctx.lineTo(reach + 0.1, 0.07);
            ctx.stroke();
        }
    }
    const outline = css(resolveToken(head.outline ?? skin.outline, env.accent));
    ctx.lineJoin = 'round';
    for (const part of [].concat(head.back ?? [])) {
        const options = typeof part === 'string' ? { type: part } : part;
        (HEAD_BACK[options.type] ?? HERO_HEAD_BACK[options.type])?.(ctx, skin, env, options, outline);
    }
    const fill = ctx.createLinearGradient(0.5, 0, -0.4, 0);
    fill.addColorStop(0, css(resolveToken(head.fill[0], env.accent)));
    fill.addColorStop(1, css(resolveToken(head.fill[1], env.accent)));
    const shape = HEAD_SHAPES[head.shape ?? 'blob'] ?? HERO_HEAD_SHAPES[head.shape];
    ctx.beginPath();
    shape(ctx);
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.lineWidth = skin.outlineWidth;
    ctx.strokeStyle = outline;
    ctx.stroke();
    for (const part of head.front ?? []) {
        const options = typeof part === 'string' ? { type: part } : part;
        const painter = HEAD_FRONT[options.type] ?? HERO_HEAD_FRONT[options.type];
        if (!painter) continue;
        ctx.save();
        painter(ctx, skin, env, options, shape);
        ctx.restore();
    }
    drawEyes(ctx, head.eye, env);
    ctx.restore();
}

function paintSnake(ctx, view, skin, env) {
    const { cell, time, accent } = env;
    ctx.save();
    ctx.translate(env.originX ?? 0, env.originY ?? 0);
    ctx.scale(cell, cell);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const total = view.paths.reduce((sum, path) => sum + path.total, 0);
    setTravel(env.travel ?? 0);
    const span = Math.max(8, Math.min(total, 20));
    const fromTail = skin.gradientAnchor === 'tail';
    const colors = gradientLookup(skin.gradient, accent, 48, Boolean(skin.scroll));
    const scroll = skin.scroll ? time * skin.scroll : 0;
    const outlineColor = css(resolveToken(skin.outline, accent));
    const stepSize = total > 60 ? 0.45 : 0.3;
    const runs = [];
    let offset = 0;
    view.paths.forEach((path, index) => {
        const isLast = index === view.paths.length - 1;
        const taper = Math.min(3.2, path.total * 0.55);
        const base = offset;
        const widthAt = s => {
            let factor = 1;
            if (isLast) {
                const distance = path.total - s;
                if (distance < taper) factor = 0.3 + 0.7 * (1 - (1 - distance / taper) ** 2);
            }
            for (const bulge of view.bulges) factor += 0.2 * Math.exp(-((base + s - bulge) ** 2) / 0.22);
            return factor;
        };
        const samples = [];
        for (let s = path.total; s > 0; s -= stepSize) samples.push({ s, ...path.at(s) });
        samples.push({ s: 0, ...path.at(0) });
        runs.push({ path, offset, widthAt, samples, total, isLast });
        offset += path.total;
    });

    if (skin.glow) {
        const pulse = skin.glow.pulse ? 0.8 + 0.2 * Math.sin(time / 380) : 1;
        runs.forEach(run => {
            for (const [factor, alpha] of [[2.1, 0.35], [1.5, 0.55]]) {
                tracePath(ctx, run.path);
                ctx.strokeStyle = css(skin.glow.color, skin.glow.alpha * alpha * pulse);
                ctx.lineWidth = skin.width * factor;
                ctx.stroke();
            }
        });
    }

    for (const run of [...runs].reverse()) {
        const { samples, widthAt } = run;
        const stroke = (width, color) => {
            for (let index = 0; index < samples.length - 1; index += 1) {
                const a = samples[index];
                const b = samples[index + 1];
                ctx.strokeStyle = color(a);
                ctx.lineWidth = width(a);
                ctx.beginPath();
                ctx.moveTo(a.x, a.y);
                ctx.lineTo(b.x, b.y);
                ctx.stroke();
            }
        };
        stroke(a => skin.width * widthAt(a.s) + skin.outlineWidth * 2, () => outlineColor);
        const tailSpan = Math.min(skin.gradientSpan ?? span, Math.max(total, 1));
        const position = a => (fromTail ? 1 - Math.min(1, (total - run.offset - a.s) / tailSpan) : (run.offset + a.s) / span + scroll);
        stroke(a => skin.width * widthAt(a.s), a => lookup(colors, position(a)));
        for (const options of [...(skin.pattern ? [skin.pattern] : []), ...(skin.patterns ?? [])]) {
            ctx.save();
            (PATTERNS[options.type] ?? HERO_PATTERNS[options.type])?.(ctx, run, skin, env, widthAt, options);
            ctx.restore();
        }
        ctx.save();
        ctx.translate(-0.035, -0.05);
        tracePath(ctx, run.path);
        ctx.strokeStyle = 'rgba(255,255,255,.17)';
        ctx.lineWidth = skin.width * 0.2;
        ctx.stroke();
        ctx.restore();
    }
    drawHead(ctx, skin, env, view);
    ctx.restore();
}

let layer = null;

export function drawSnake(ctx, view, skin, env) {
    if (!view.paths.length || !view.paths[0].points.length) return;
    if (skin.alpha < 1) {
        const canvas = ctx.canvas;
        layer ??= document.createElement('canvas');
        if (layer.width !== canvas.width || layer.height !== canvas.height) {
            layer.width = canvas.width;
            layer.height = canvas.height;
        }
        const layerContext = layer.getContext('2d');
        layerContext.setTransform(1, 0, 0, 1, 0, 0);
        layerContext.clearRect(0, 0, layer.width, layer.height);
        layerContext.setTransform(ctx.getTransform());
        paintSnake(layerContext, view, skin, env);
        ctx.save();
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.globalAlpha *= skin.alpha * (0.92 + 0.08 * Math.sin(env.time / 500));
        ctx.drawImage(layer, 0, 0);
        ctx.restore();
        return;
    }
    paintSnake(ctx, view, skin, env);
}
