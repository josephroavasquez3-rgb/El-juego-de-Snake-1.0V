import { css, resolveToken } from './color.js';

export const TAU = Math.PI * 2;

export const hash = value => {
    const x = Math.sin(value * 127.1 + 311.7) * 43758.5453;
    return x - Math.floor(x);
};

export const normalOf = angle => ({ x: -Math.sin(angle), y: Math.cos(angle) });

// Path angles point from the head toward the tail, so "forward" is the opposite direction.
export const forwardOf = angle => ({ x: -Math.cos(angle), y: -Math.sin(angle) });

export const lateral = (point, distance) => ({ x: point.x - Math.sin(point.angle) * distance, y: point.y + Math.cos(point.angle) * distance });

export const color = (token, env, alpha = 1) => css(resolveToken(token, env.accent), alpha);

// A few representative colors of a skin (body gradient + head), used by particle effects.
export function skinPalette(skin, accent) {
    return [skin.head.fill[0], ...skin.gradient.slice(0, 3)].map(token => color(token, { accent }));
}

let travel = 0;
export function setTravel(value) {
    travel = value;
}
export function getTravel() {
    return travel;
}

/**
 * Calls back at body-anchored positions: features stay glued to the body as the snake advances
 * instead of sliding along it. `k` is a stable integer index for each feature.
 */
export function marks(path, spacing, phase, callback) {
    const base = travel - phase;
    let n = Math.floor(base / spacing);
    for (let s = base - n * spacing; s < path.total - 0.15; s += spacing, n -= 1) callback(path.at(s), s, n + 100000);
}

// Fine samples along a run, cached because bands and lines need smoother geometry than the body strokes.
export function dense(run, step = 0.1) {
    run.denseCache ??= new Map();
    if (run.denseCache.has(step)) return run.denseCache.get(step);
    const samples = [];
    for (let s = run.path.total; s > 0; s -= step) samples.push({ s, ...run.path.at(s) });
    samples.push({ s: 0, ...run.path.at(0) });
    run.denseCache.set(step, samples);
    return samples;
}

export function sparkle(ctx, x, y, size, fill) {
    ctx.fillStyle = fill;
    ctx.beginPath();
    ctx.moveTo(x, y - size); ctx.quadraticCurveTo(x, y, x + size, y);
    ctx.quadraticCurveTo(x, y, x, y + size); ctx.quadraticCurveTo(x, y, x - size, y);
    ctx.quadraticCurveTo(x, y, x, y - size);
    ctx.fill();
}

export function starPath(ctx, radius, inner = radius * 0.42) {
    ctx.beginPath();
    for (let index = 0; index < 10; index += 1) {
        const angle = -Math.PI / 2 + index * Math.PI / 5;
        const length = index % 2 ? inner : radius;
        const x = Math.cos(angle) * length;
        const y = Math.sin(angle) * length;
        if (index) ctx.lineTo(x, y); else ctx.moveTo(x, y);
    }
    ctx.closePath();
}

export function polygon(ctx, points) {
    ctx.beginPath();
    points.forEach(([x, y], index) => (index ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    ctx.closePath();
}

export function mirrored(half) {
    return [...half, ...half.slice().reverse().map(([x, y]) => [-x, y])];
}
