import { getPlayerProfile } from '../data/player-profile.js';
import { getFoodSkin } from '../game/food-skins.js';
import { getSkin } from '../game/skins.js';
import { paintTiles, readTheme } from '../rendering/board-renderer.js';
import { drawFood } from '../rendering/food-renderer.js';
import { buildSnakeView, DEATH_MS, dissolveView, drawSnake } from '../rendering/snake-renderer.js';

export class MultiplayerClient {
    constructor({ onMessage = () => {}, onStatus = () => {} } = {}) {
        this.onMessage = onMessage;
        this.onStatus = onStatus;
        this.socket = null;
        this.roomCode = null;
        this.player = null;
        this.connected = false;
        this.intentionalClose = false;
    }

    async connect() {
        if (this.socket?.readyState === WebSocket.OPEN) return true;
        if (location.protocol === 'file:') {
            this.onStatus('ERROR', 'Abre el proyecto desde el servidor con `npm start` para usar salas.');
            return false;
        }
        const scheme = location.protocol === 'https:' ? 'wss:' : 'ws:';
        return new Promise(resolve => {
            this.intentionalClose = false;
            const socket = new WebSocket(`${scheme}//${location.host}/socket`);
            this.socket = socket;
            const timeout = window.setTimeout(() => {
                if (socket.readyState !== WebSocket.OPEN) {
                    this.onStatus('ERROR', 'No se pudo conectar. Comprueba que `npm start` está activo.');
                    resolve(false);
                }
            }, 5000);
            socket.addEventListener('open', () => {
                window.clearTimeout(timeout);
                this.connected = true;
                this.onStatus('CONECTADO', 'Conectado al servidor de salas.');
                resolve(true);
            }, { once: true });
            socket.addEventListener('message', event => {
                try {
                    const message = JSON.parse(event.data);
                    if (message.roomCode) this.roomCode = message.roomCode;
                    this.onMessage(message);
                } catch {
                    this.onStatus('ERROR', 'El servidor envió un mensaje no válido.');
                }
            });
            socket.addEventListener('close', () => {
                this.connected = false;
                if (!this.intentionalClose) this.onStatus('DESCONECTADO', 'La conexión con la sala se cerró.');
            });
            socket.addEventListener('error', () => {
                this.onStatus('ERROR', 'No se pudo abrir el servidor WebSocket.');
                resolve(false);
            }, { once: true });
        });
    }

    async createRoom(player) {
        if (!await this.connect()) return false;
        this.player = player;
        return this.send({ type: 'create-room', player });
    }

    async joinRoom(code, player) {
        if (!await this.connect()) return false;
        this.player = player;
        return this.send({ type: 'join-room', code: code.trim().toUpperCase(), player });
    }

    setDirection(direction) {
        if (this.roomCode) this.send({ type: 'direction', direction });
    }

    startRoom() {
        return this.send({ type: 'start-room' });
    }

    returnToLobby() {
        return this.send({ type: 'return-lobby' });
    }

    replayRoom() {
        return this.send({ type: 'replay-room' });
    }

    send(message) {
        if (this.socket?.readyState !== WebSocket.OPEN) return false;
        this.socket.send(JSON.stringify(message));
        return true;
    }

    leave() {
        this.intentionalClose = true;
        if (this.socket?.readyState === WebSocket.OPEN) this.send({ type: 'leave-room' });
        this.socket?.close();
        this.socket = null;
        this.roomCode = null;
        this.connected = false;
    }
}

const travelById = new Map();

function trackTravel(player) {
    const head = player.snake[0];
    const entry = travelById.get(player.id) ?? { head, travel: 0 };
    if (entry.head.x !== head.x || entry.head.y !== head.y) entry.travel += 1;
    entry.head = head;
    travelById.set(player.id, entry);
    return entry.travel;
}

// deathElapsed (ms) plays the dissolve animation on defeated players; null draws the plain snapshot.
export function drawRoomSnapshot(canvas, snapshot, deathElapsed = null) {
    const context = canvas.getContext('2d');
    const theme = readTheme();
    const cell = Math.min(canvas.width / snapshot.width, canvas.height / snapshot.height);
    context.clearRect(0, 0, canvas.width, canvas.height);
    paintTiles(context, snapshot.width, snapshot.height, cell, theme);
    if (snapshot.food) {
        const foodSkin = getFoodSkin(getPlayerProfile().selectedFoodSkin);
        drawFood(context, foodSkin.id, (snapshot.food.x + 0.5) * cell, (snapshot.food.y + 0.5) * cell, cell * 0.94, { time: performance.now(), themeFood: theme.food });
    }
    snapshot.players.forEach((player, playerIndex) => {
        if (!player.snake.length) return;
        const accent = playerIndex === 0 ? theme.accent : '#79baff';
        let view = buildSnakeView(player.snake);
        let fade = player.alive ? 1 : 0.4;
        if (!player.alive && deathElapsed !== null) ({ view, fade } = dissolveView(view, deathElapsed));
        if (fade <= 0) return;
        context.globalAlpha = fade;
        drawSnake(context, view, getSkin(player.skin), { cell, time: performance.now(), accent, dead: !player.alive, travel: trackTravel(player) });
        context.globalAlpha = 1;
        const head = player.snake[0];
        const headX = (head.x + 0.5) * cell;
        const headY = (head.y + 0.5) * cell;
        context.font = `600 ${Math.max(9, Math.min(13, cell * 0.48))}px sans-serif`;
        const label = `${player.avatar} ${player.name}`;
        const labelWidth = context.measureText(label).width + 12;
        const labelX = Math.min(Math.max(2, headX - labelWidth / 2), canvas.width - labelWidth - 2);
        const labelY = Math.max(16, headY - cell * 0.72);
        context.fillStyle = 'rgba(8, 14, 14, .82)';
        context.fillRect(labelX, labelY - 13, labelWidth, 18);
        context.fillStyle = '#ffffff';
        context.fillText(label, labelX + 6, labelY);
    });
}

/** Plays the defeat animation for a finished round, then calls `onDone`. Returns a cancel function. */
export function playRoomDeath(canvas, snapshot, onDone) {
    const start = performance.now();
    let frame = null;
    let timer = null;
    let finished = false;
    const stop = () => {
        finished = true;
        window.cancelAnimationFrame(frame);
        window.clearTimeout(timer);
    };
    const finish = () => {
        if (finished) return;
        stop();
        onDone();
    };
    const loop = now => {
        if (finished) return;
        const elapsed = Math.max(0, now - start);
        drawRoomSnapshot(canvas, snapshot, elapsed);
        if (elapsed >= DEATH_MS) finish();
        else frame = window.requestAnimationFrame(loop);
    };
    frame = window.requestAnimationFrame(loop);
    // Background tabs pause animation frames; the results must still appear.
    timer = window.setTimeout(finish, DEATH_MS + 300);
    return stop;
}
