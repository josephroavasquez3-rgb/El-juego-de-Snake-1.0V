import { foodSkins, getFoodSkin } from './game/food-skins.js';
import { gameModes, mapDefinitions } from './game/config.js';
import { getSkin, snakeSkins } from './game/skins.js';
import { paintTiles, readTheme } from './rendering/board-renderer.js';
import { drawFood } from './rendering/food-renderer.js';
import { drawSnake, smoothPath } from './rendering/snake-renderer.js';

const CARD_COLUMNS = 10;
const CARD_ROWS = 5;
const PREVIEW_COLUMNS = 16;
const PREVIEW_ROWS = 9;
const reducedMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

let themeCache = { key: '', theme: null };
function currentTheme() {
    const key = document.body.dataset.palette;
    if (themeCache.key !== key) themeCache = { key, theme: readTheme() };
    return themeCache.theme;
}

export function renderSkinCards() {
    for (const universe of ['original', 'marvel', 'dc']) {
        const container = document.querySelector(`[data-universe-list="${universe}"]`) ?? (universe === 'original' ? document.getElementById('skin-list') : null);
        if (!container) continue;
        container.innerHTML = snakeSkins.filter(skin => skin.universe === universe).map(skin => `
        <button class="skin-card" type="button" data-skin="${skin.id}" aria-pressed="false" aria-label="${skin.name}: ${skin.note}">
            <canvas width="320" height="160" aria-hidden="true"></canvas>
            <span class="card-text"><strong>${skin.name}</strong><small>${skin.note}</small></span>
            <span class="card-check" aria-hidden="true">✓</span>
        </button>`).join('');
    }
}

export function showUniverse(universe) {
    document.querySelectorAll('[data-universe]').forEach(tab => {
        const active = tab.dataset.universe === universe;
        tab.setAttribute('aria-selected', String(active));
        tab.tabIndex = active ? 0 : -1;
    });
    document.querySelectorAll('[data-universe-list]').forEach(list => { list.hidden = list.dataset.universeList !== universe; });
}

export function renderFoodCards(container) {
    container.innerHTML = foodSkins.map(skin => `
        <button class="food-card" type="button" data-food="${skin.id}" aria-pressed="false">
            <canvas width="120" height="120" aria-hidden="true"></canvas>
            <span class="card-text"><strong>${skin.name}</strong></span>
            <span class="card-check" aria-hidden="true">✓</span>
        </button>`).join('');
}

function drawSkinCard(canvas, skin, theme) {
    const context = canvas.getContext('2d');
    const cell = canvas.width / CARD_COLUMNS;
    context.clearRect(0, 0, canvas.width, canvas.height);
    paintTiles(context, CARD_COLUMNS, CARD_ROWS, cell, theme);
    const points = [];
    for (let index = 0; index < 30; index += 1) {
        const x = 9.1 - index * 0.3;
        points.push({ x, y: 2.5 + 0.95 * Math.sin(x * 1.2 + 0.5) });
    }
    drawSnake(context, { paths: [smoothPath(points)], bulges: [] }, skin, { cell, time: 1100, accent: theme.accent, travel: 0 });
}

function drawFoodCard(canvas, skin, theme) {
    const context = canvas.getContext('2d');
    context.clearRect(0, 0, canvas.width, canvas.height);
    paintTiles(context, 4, 4, canvas.width / 4, theme);
    drawFood(context, skin.id, canvas.width / 2, canvas.height / 2, canvas.width * 0.72, { themeFood: theme.food, animate: false, time: 600 });
}

export function redrawCards(foodContainer) {
    const theme = currentTheme();
    document.querySelectorAll('[data-skin]').forEach(card => drawSkinCard(card.querySelector('canvas'), getSkin(card.dataset.skin), theme));
    foodContainer.querySelectorAll('[data-food]').forEach(card => drawFoodCard(card.querySelector('canvas'), getFoodSkin(card.dataset.food), theme));
}

export function markSelection(container, attribute, value) {
    container.querySelectorAll(`[data-${attribute}]`).forEach(card => {
        const selected = card.dataset[attribute] === value;
        card.setAttribute('aria-pressed', String(selected));
        card.classList.toggle('is-selected', selected);
    });
}

export function updateSelectionLabels(profile) {
    const skin = getSkin(profile.selectedSkin);
    const food = getFoodSkin(profile.selectedFoodSkin);
    document.getElementById('preview-skin-name').textContent = skin.name.toLocaleUpperCase();
    document.getElementById('preview-skin-note').textContent = `${skin.universe === 'original' ? skin.note : `${skin.universe === 'dc' ? 'DC Comics' : 'Marvel'} · ${skin.note}`} · ${food.name}`;
    const map = mapDefinitions[profile.mapId] ?? mapDefinitions.normal;
    const mode = gameModes[profile.modeId] ?? gameModes.classic;
    document.getElementById('game-summary').textContent = `${mode.label} · ${map.label}`;
}

/** Animated live preview: the selected snake circles the selected food on a small board. */
export function createPreview(canvas) {
    const context = canvas.getContext('2d');
    let frameId = null;
    let skin = snakeSkins[0];
    let food = foodSkins[0];
    let running = false;

    function draw(now = performance.now()) {
        const theme = currentTheme();
        const cell = canvas.width / PREVIEW_COLUMNS;
        paintTiles(context, PREVIEW_COLUMNS, PREVIEW_ROWS, cell, theme);
        const head = now / 620;
        const points = [];
        for (let index = 0; index < 40; index += 1) {
            const angle = head - index * 0.105;
            points.push({ x: 8 + Math.cos(angle) * 5.6, y: 4.5 + Math.sin(angle) * 2.9 });
        }
        drawFood(context, food.id, 8 * cell, 4.5 * cell, cell * 1.35, { time: now, themeFood: theme.food });
        drawSnake(context, { paths: [smoothPath(points)], bulges: [] }, skin, { cell, time: now, accent: theme.accent, travel: head * 4.3 });
    }

    function loop(now) {
        frameId = null;
        if (!running) return;
        draw(now);
        if (!reducedMotion()) frameId = window.requestAnimationFrame(loop);
    }

    return {
        select(profile) {
            skin = getSkin(profile.selectedSkin);
            food = getFoodSkin(profile.selectedFoodSkin);
            if (running) draw();
        },
        start() {
            running = true;
            if (frameId === null) frameId = window.requestAnimationFrame(loop);
        },
        stop() {
            running = false;
            if (frameId !== null) window.cancelAnimationFrame(frameId);
            frameId = null;
        },
        draw
    };
}
