import { getPlayerProfile, readBestScore, recordGameEnded, recordGameStarted, saveBestScore } from './data/player-profile.js';
import { ParticleSystem } from './effects/particle-system.js';
import { createMap, difficultySettings, findReachableTiles, gameModes, isBlockedByMap, isModeAvailable, mapDefinitions, wrapPosition } from './game/config.js';
import { getSkin } from './game/skins.js';
import { getFoodSkin } from './game/food-skins.js';
import { BoardRenderer } from './rendering/board-renderer.js';
import { buildSnakeView, DEATH_MS, dissolveView } from './rendering/snake-renderer.js';
import { skinPalette } from './rendering/snake-utils.js';

const DIRECTIONS = {
    ArrowUp: { x: 0, y: -1 }, w: { x: 0, y: -1 },
    ArrowDown: { x: 0, y: 1 }, s: { x: 0, y: 1 },
    ArrowLeft: { x: -1, y: 0 }, a: { x: -1, y: 0 },
    ArrowRight: { x: 1, y: 0 }, d: { x: 1, y: 0 }
};
const COUNTDOWN_STEP_MS = 600;
const MAX_QUEUED_TURNS = 2;
const SWIPE_DISTANCE = 26;

export function createGame({ audio, onHome, onOpenOptions, onStatisticsChanged } = {}) {
    const canvas = document.getElementById('game-board');
    const boardFrame = document.querySelector('.board-frame');
    const renderer = new BoardRenderer(canvas);
    const particles = new ParticleSystem();
    const overlay = document.getElementById('game-overlay');
    const scoreLabel = document.getElementById('score');
    const bestLabel = document.getElementById('best-score');
    const menuBestLabel = document.getElementById('menu-best');
    const statusLabel = document.getElementById('game-status');
    const modeNameLabel = document.getElementById('game-mode-name');
    const mapSizeLabel = document.getElementById('board-size');
    const modeTimerLabel = document.getElementById('mode-timer');
    const modeEventLabel = document.getElementById('mode-event');
    const overlayKicker = document.getElementById('overlay-kicker');
    const overlayTitle = document.getElementById('overlay-title');
    const overlayCopy = document.getElementById('overlay-copy');
    const resultStats = document.getElementById('result-stats');
    const resultScore = document.getElementById('result-score');
    const resultBest = document.getElementById('result-best');
    const resultBadge = document.getElementById('result-badge');
    const countdownLabel = document.getElementById('countdown');
    const pauseActions = document.getElementById('pause-actions');
    const gameoverActions = document.getElementById('gameover-actions');
    const pauseButton = document.getElementById('btn-pause');
    const liveDot = document.getElementById('game-live-dot');
    const bestValue = value => String(value).padStart(3, '0');
    let snake = [];
    let tailFrom = null;
    let bulgeAges = [];
    let ticks = 0;
    let direction = { x: 1, y: 0 };
    let turnQueue = [];
    let food = null;
    let foodBornAt = 0;
    let eaten = null;
    let score = 0;
    let modeTimer = null;
    let eventTimer = null;
    let foodTimer = null;
    const bombTimers = new Set();
    let currentSpeedMs = difficultySettings.normal.startMs;
    let running = false;
    let paused = false;
    let dead = false;
    let dying = false;
    let snakeHidden = false;
    let deathStart = 0;
    let deathScale = 1;
    let deathTimer = null;
    let deathImpact = null;
    let deathPalette = [];
    let lastDust = 0;
    let pendingResult = null;
    let counting = false;
    let countdownMs = 0;
    let sessionActive = false;
    let activeSince = 0;
    let sessionElapsedMs = 0;
    let sessionBestAtStart = 0;
    let currentMap = mapDefinitions.normal;
    let currentMode = gameModes.classic;
    let currentDifficulty = difficultySettings.normal;
    let accumulator = 0;
    let progress = 1;
    let lastFrame = 0;
    let frameId = null;
    let currentSkin = getSkin(getPlayerProfile().selectedSkin);
    let currentFoodSkin = getFoodSkin(getPlayerProfile().selectedFoodSkin);
    let modeRemainingMs = 0;
    let eventMessageTimeout = null;
    let floodLevel = 0;

    function updateScoreLabels() {
        bestLabel.textContent = bestValue(readBestScore(currentMode.id));
        menuBestLabel.textContent = bestValue(getPlayerProfile().highScore);
    }

    function formatClock(milliseconds) {
        const seconds = Math.ceil(milliseconds / 1000);
        return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
    }

    function spawnFood() {
        food = randomFood();
        foodBornAt = performance.now();
    }

    function randomFood() {
        const occupied = new Set([
            ...snake.map(segment => `${segment.x},${segment.y}`),
            ...(currentMap.portals ?? []).map(portal => `${portal.x},${portal.y}`)
        ]);
        const reachable = new Set(findReachableTiles(snake[0], currentMap, currentMode).map(tile => `${tile.x},${tile.y}`));
        const openTiles = [];
        for (let y = 0; y < currentMap.height; y += 1) {
            for (let x = 0; x < currentMap.width; x += 1) {
                const key = `${x},${y}`;
                if (reachable.has(key) && !occupied.has(key) && !isBlockedByMap({ x, y }, currentMap, currentMode)) openTiles.push({ x, y });
            }
        }
        return openTiles[Math.floor(Math.random() * openTiles.length)] ?? null;
    }

    function clearModeTimers() {
        window.clearInterval(modeTimer);
        window.clearInterval(eventTimer);
        window.clearTimeout(foodTimer);
        window.clearTimeout(eventMessageTimeout);
        bombTimers.forEach(timerId => window.clearTimeout(timerId));
        bombTimers.clear();
        modeTimer = null;
        eventTimer = null;
        foodTimer = null;
    }

    function elapsedSessionMs() {
        return sessionElapsedMs + (activeSince ? Date.now() - activeSince : 0);
    }

    function updateModeClock() {
        if (!currentMode.durationMs || !running || paused) return;
        modeRemainingMs = Math.max(0, currentMode.durationMs - elapsedSessionMs());
        modeTimerLabel.textContent = formatClock(modeRemainingMs);
        if (modeRemainingMs === 0) endGame(false, 'time');
    }

    function setEventMessage(message) {
        modeEventLabel.textContent = message;
        window.clearTimeout(eventMessageTimeout);
        eventMessageTimeout = window.setTimeout(() => { modeEventLabel.textContent = ''; }, 1800);
    }

    function addRandomObstacle() {
        const occupied = new Set([...snake, ...(food ? [food] : [])].map(tile => `${tile.x},${tile.y}`));
        const head = snake[0];
        for (let attempt = 0; attempt < 60; attempt += 1) {
            const tile = { x: 1 + Math.floor(Math.random() * (currentMap.width - 2)), y: 1 + Math.floor(Math.random() * (currentMap.height - 2)) };
            if (occupied.has(`${tile.x},${tile.y}`) || Math.abs(tile.x - head.x) < 4 && Math.abs(tile.y - head.y) < 4 || isBlockedByMap(tile, currentMap, currentMode)) continue;
            currentMap.obstacles.push(tile);
            return tile;
        }
        return null;
    }

    function advanceFlood() {
        floodLevel += 1;
        const inset = floodLevel + 1;
        const head = snake[0];
        for (let x = inset; x < currentMap.width - inset; x += 1) {
            for (const y of [inset, currentMap.height - inset - 1]) {
                const tile = { x, y };
                if (Math.abs(head.x - x) + Math.abs(head.y - y) > 3 && !isBlockedByMap(tile, currentMap, currentMode)) currentMap.obstacles.push(tile);
            }
        }
        for (let y = inset + 1; y < currentMap.height - inset - 1; y += 1) {
            for (const x of [inset, currentMap.width - inset - 1]) {
                const tile = { x, y };
                if (Math.abs(head.x - x) + Math.abs(head.y - y) > 3 && !isBlockedByMap(tile, currentMap, currentMode)) currentMap.obstacles.push(tile);
            }
        }
        setEventMessage('EL AGUA AVANZA');
        if (inset >= Math.floor(Math.min(currentMap.width, currentMap.height) / 2) - 3) endGame(false, 'flood');
    }

    function dropBomb() {
        const bomb = addRandomObstacle();
        if (!bomb) return setEventMessage('SIN ESPACIO PARA OTRA BOMBA');
        setEventMessage('¡BOMBA! ALÉJATE');
        const timerId = window.setTimeout(() => {
            bombTimers.delete(timerId);
            if (!running) return;
            const hit = snake.some(segment => Math.abs(segment.x - bomb.x) + Math.abs(segment.y - bomb.y) <= 1);
            if (hit) {
                endGame(false, 'bomb');
                return;
            }
            currentMap.obstacles = currentMap.obstacles.filter(tile => tile !== bomb);
            setEventMessage('BOMBA DESACTIVADA');
            draw();
        }, currentMode.bombFuseMs ?? 4200);
        bombTimers.add(timerId);
        draw();
    }

    function armFoodTimer() {
        window.clearTimeout(foodTimer);
        if (!currentMode.foodLifetimeMs) return;
        foodTimer = window.setTimeout(() => {
            food = null;
            draw();
            setEventMessage('LA COMIDA SE FUE');
            foodTimer = window.setTimeout(() => {
                spawnFood();
                draw();
                armFoodTimer();
            }, 650);
        }, currentMode.foodLifetimeMs);
    }

    function runModeEvent() {
        if (!running || paused) return;
        if (currentMode.eventKind === 'flood') {
            advanceFlood();
            draw();
            return;
        }
        if (currentMode.eventKind === 'bombs') {
            dropBomb();
            return;
        }
        const obstacle = currentMode.eventKind === 'lava' || Math.random() < 0.68 ? addRandomObstacle() : null;
        if (currentMode.eventKind === 'lava') {
            setEventMessage(obstacle ? '¡LA LAVA SE EXPANDE!' : '¡ZONA DE LAVA!');
        } else if (obstacle) {
            setEventMessage('¡NUEVO OBSTÁCULO!');
        } else {
            currentSpeedMs = Math.max(currentMode.minMs ?? currentDifficulty.minMs, Math.round(currentSpeedMs * 0.82));
            setEventMessage('¡CAMBIO DE VELOCIDAD!');
        }
        draw();
    }

    function startModeTimers(resuming = false) {
        clearModeTimers();
        modeTimerLabel.hidden = !currentMode.durationMs;
        if (currentMode.durationMs) {
            if (!resuming) modeRemainingMs = currentMode.durationMs;
            updateModeClock();
            modeTimer = window.setInterval(updateModeClock, 200);
        }
        if (currentMode.eventIntervalMs) eventTimer = window.setInterval(runModeEvent, currentMode.eventIntervalMs);
        armFoodTimer();
    }

    // Distance of each recently eaten bite from the visual head, used to bulge the body as food travels down it.
    function bulgeDistances() {
        return bulgeAges.map(age => age + progress - 1).filter(distance => distance <= snake.length);
    }

    function deathState(time) {
        const elapsed = Math.max(0, time - deathStart);
        const { view, fade, dissolving } = dissolveView(buildSnakeView(snake, 1, null, []), elapsed, deathScale);
        const last = view.paths[view.paths.length - 1];
        return { view, fade, elapsed, tip: last.at(last.total), dissolving };
    }
    function draw(time = performance.now()) {
        let view = snake.length && !snakeHidden ? buildSnakeView(snake, progress, tailFrom, bulgeDistances()) : null;
        let fade = 1;
        let impact = null;
        if (dying && view) {
            const state = deathState(time);
            ({ view, fade } = state);
            if (deathImpact) impact = { ...deathImpact, elapsed: state.elapsed / deathScale };
        }
        renderer.render({ view, food, foodBornAt, eaten, foodSkin: currentFoodSkin, skin: currentSkin, map: currentMap, particles, time, dead, travel: Math.max(0, ticks - 1 + progress), fade, impact });
    }

    function scheduleFrame() {
        if (!running || paused || frameId !== null) return;
        lastFrame = performance.now();
        frameId = window.requestAnimationFrame(frame);
    }

    function cancelFrame() {
        if (frameId !== null) window.cancelAnimationFrame(frameId);
        frameId = null;
    }

    // Death animation loop: the snake dissolves from the tail while the game logic stays frozen.
    function deathFrame(now) {
        frameId = null;
        if (!dying) return;
        const state = deathState(now);
        if (state.dissolving && now - lastDust > 55) {
            lastDust = now;
            const cell = renderer.cell;
            particles.burst(state.tip.x * cell, state.tip.y * cell, deathPalette[Math.floor(Math.random() * deathPalette.length)], 4);
        }
        draw(now);
        if (state.elapsed >= DEATH_MS * deathScale) finishDeath();
        else frameId = window.requestAnimationFrame(deathFrame);
    }

    // Fixed-timestep loop: the grid logic advances exactly every `currentSpeedMs`, rendering interpolates in between.
    function frame(now) {
        frameId = null;
        if (!running || paused) return;
        const delta = Math.min(now - lastFrame, 100);
        lastFrame = now;
        if (counting) {
            countdownMs -= delta;
            if (countdownMs <= 0) beginPlay();
            else countdownLabel.textContent = String(Math.ceil(countdownMs / COUNTDOWN_STEP_MS));
        } else {
            accumulator += delta;
            while (running && accumulator >= currentSpeedMs) {
                accumulator -= currentSpeedMs;
                tick();
            }
        }
        if (running) progress = counting ? 1 : Math.min(1, accumulator / currentSpeedMs);
        draw(now);
        if (running && !paused) {
            frameId = window.requestAnimationFrame(frame);
        }
    }

    function finishSession(won = false) {
        if (!sessionActive) return;
        const elapsedMs = elapsedSessionMs();
        activeSince = 0;
        sessionActive = false;
        const profile = recordGameEnded({ score, length: snake.length, elapsedMs, won, modeId: currentMode.id });
        updateScoreLabels();
        onStatisticsChanged?.(profile);
    }

    function showOverlay({ kicker, title, copy, stats = false, pause = false, over = false }) {
        overlayKicker.textContent = kicker;
        overlayTitle.textContent = title;
        overlayCopy.textContent = copy;
        resultStats.hidden = !stats;
        pauseActions.hidden = !pause;
        gameoverActions.hidden = !over;
        overlay.classList.remove('is-hidden');
        overlay.setAttribute('aria-hidden', 'false');
    }

    function hideOverlay() {
        overlay.classList.add('is-hidden');
        overlay.setAttribute('aria-hidden', 'true');
        pauseActions.hidden = true;
        gameoverActions.hidden = true;
        resultStats.hidden = true;
    }

    function clearDeath() {
        dying = false;
        snakeHidden = false;
        pendingResult = null;
        deathImpact = null;
        window.clearTimeout(deathTimer);
    }

    function reset() {
        finishSession(false);
        cancelFrame();
        clearDeath();
        clearModeTimers();
        const profile = getPlayerProfile();
        const mapId = mapDefinitions[profile.mapId] ? profile.mapId : 'normal';
        const modeId = gameModes[profile.modeId] ? profile.modeId : 'classic';
        if (!isModeAvailable(modeId, mapId)) return;
        currentMode = gameModes[modeId];
        sessionBestAtStart = readBestScore(currentMode.id);
        modeNameLabel.textContent = currentMode.label.toLocaleUpperCase();
        const mapTemplate = mapDefinitions[mapId];
        currentDifficulty = difficultySettings[profile.difficulty] ?? difficultySettings.normal;
        currentSkin = getSkin(profile.selectedSkin);
        currentFoodSkin = getFoodSkin(profile.selectedFoodSkin);
        const centerX = Math.floor(mapTemplate.width / 2);
        const centerY = Math.floor(mapTemplate.height / 2);
        snake = [{ x: centerX, y: centerY }, { x: centerX - 1, y: centerY }, { x: centerX - 2, y: centerY }];
        const obstacleCount = currentMode.obstacleRate ? Math.floor(mapTemplate.width * mapTemplate.height * currentMode.obstacleRate) : null;
        currentMap = createMap(mapId, snake, { obstacleCount });
        renderer.resize(currentMap);
        mapSizeLabel.textContent = `${currentMap.width} × ${currentMap.height}`;
        currentSpeedMs = currentMode.startMs ?? currentDifficulty.startMs;
        direction = { x: 1, y: 0 };
        turnQueue = [];
        tailFrom = null;
        bulgeAges = [];
        ticks = 0;
        eaten = null;
        particles.clear();
        floodLevel = 0;
        spawnFood();
        score = 0;
        running = true;
        paused = false;
        dead = false;
        counting = true;
        countdownMs = COUNTDOWN_STEP_MS * 3;
        accumulator = 0;
        progress = 1;
        sessionActive = true;
        activeSince = 0;
        sessionElapsedMs = 0;
        recordGameStarted();
        scoreLabel.textContent = bestValue(score);
        updateScoreLabels();
        modeTimerLabel.hidden = !currentMode.durationMs;
        modeTimerLabel.textContent = formatClock(currentMode.durationMs ?? 0);
        modeEventLabel.textContent = '';
        statusLabel.textContent = 'PREPÁRATE';
        countdownLabel.textContent = '3';
        countdownLabel.hidden = false;
        hideOverlay();
        pauseButton.disabled = false;
        boardFrame.classList.remove('is-game-over', 'is-eating');
        liveDot.classList.remove('is-paused');
        draw();
        scheduleFrame();
    }

    function beginPlay() {
        counting = false;
        countdownLabel.hidden = true;
        activeSince = Date.now();
        accumulator = 0;
        statusLabel.textContent = 'EN PARTIDA';
        startModeTimers();
        audio?.playSound('start');
    }

    function setDirection(candidate) {
        if (!running || paused) return;
        const reference = turnQueue[turnQueue.length - 1] ?? direction;
        if (candidate.x === reference.x && candidate.y === reference.y) return;
        if (candidate.x === -reference.x && candidate.y === -reference.y) return;
        if (turnQueue.length < MAX_QUEUED_TURNS) turnQueue.push(candidate);
    }

    function tick() {
        if (!running || paused) return;
        direction = turnQueue.shift() ?? direction;
        let head = { x: snake[0].x + direction.x, y: snake[0].y + direction.y };
        head = wrapPosition(head, currentMap, currentMode);
        const eating = food && head.x === food.x && head.y === food.y;
        const bodyToCheck = eating ? snake : snake.slice(0, -1);
        if (isBlockedByMap(head, currentMap, currentMode) || bodyToCheck.some(part => part.x === head.x && part.y === head.y)) {
            endGame(false);
            return;
        }

        bulgeAges = bulgeAges.map(age => age + 1).filter(age => age <= snake.length + 1);
        snake.unshift(head);
        ticks += 1;
        if (eating) {
            tailFrom = null;
            bulgeAges.push(0);
            const foodValue = currentMode.scorePerFood ?? 10;
            score += foodValue;
            scoreLabel.textContent = bestValue(score);
            const cell = renderer.cell;
            const particleColor = currentFoodSkin.particle === 'theme-food' ? renderer.currentTheme().food : currentFoodSkin.particle;
            const now = performance.now();
            eaten = { x: food.x, y: food.y, skinId: currentFoodSkin.id, startedAt: now, duration: currentSpeedMs };
            particles.burst((food.x + 0.5) * cell, (food.y + 0.5) * cell, particleColor, 14, currentSpeedMs);
            audio?.play('eat');
            window.clearTimeout(foodTimer);
            boardFrame.classList.remove('is-eating');
            void boardFrame.offsetWidth;
            boardFrame.classList.add('is-eating');
            window.setTimeout(() => boardFrame.classList.remove('is-eating'), 300);
            saveBestScore(score, currentMode.id);
            updateScoreLabels();
            spawnFood();
            armFoodTimer();
            const modeStartMs = currentMode.startMs ?? currentDifficulty.startMs;
            const speedStepMs = currentMode.speedStepMs ?? currentDifficulty.speedStepMs;
            const minimumSpeed = currentMode.minMs ?? currentDifficulty.minMs;
            currentSpeedMs = Math.max(minimumSpeed, modeStartMs - (score / foodValue) * speedStepMs);
            if (!food || (currentMode.targetScore && score >= currentMode.targetScore)) {
                endGame(true);
            }
        } else {
            tailFrom = snake.pop();
        }
    }

    // Ends the round. Losses go through the DYING state (death animation) before the results are shown.
    function endGame(won, reason = null) {
        if (!running || dying) return;
        running = false;
        paused = false;
        progress = 1;
        tailFrom = null;
        cancelFrame();
        clearModeTimers();
        countdownLabel.hidden = true;
        pauseButton.disabled = true;
        const updated = recordGameEnded({ score, length: snake.length, elapsedMs: elapsedSessionMs(), won, modeId: currentMode.id });
        sessionActive = false;
        activeSince = 0;
        liveDot.classList.remove('is-paused');
        updateScoreLabels();
        onStatisticsChanged?.(updated);
        const result = { won, reason, updated, length: snake.length };
        if (won) {
            dead = false;
            showResult(result);
            draw();
        } else {
            startDeath(result);
        }
    }

    function startDeath(result) {
        dying = true;
        dead = true;
        pendingResult = result;
        deathStart = performance.now();
        deathScale = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ? 0.7 : 1;
        lastDust = 0;
        const accent = renderer.currentTheme().accent;
        deathPalette = skinPalette(currentSkin, accent);
        const head = snake[0];
        const cell = renderer.cell;
        if (result.reason === 'time') {
            deathImpact = null;
        } else {
            deathImpact = { x: head.x + 0.5 + direction.x * 0.5, y: head.y + 0.5 + direction.y * 0.5 };
            deathPalette.forEach((paint, index) => particles.burst(deathImpact.x * cell, deathImpact.y * cell, paint, 8, index * 25));
        }
        statusLabel.textContent = 'FIN DE PARTIDA';
        boardFrame.classList.remove('is-game-over');
        void boardFrame.offsetWidth;
        boardFrame.classList.add('is-game-over');
        audio?.play('gameOver');
        window.clearTimeout(deathTimer);
        // Safety net: background tabs pause requestAnimationFrame, but the results must still appear.
        deathTimer = window.setTimeout(finishDeath, DEATH_MS * deathScale + 300);
        frameId = window.requestAnimationFrame(deathFrame);
    }

    function finishDeath() {
        if (!dying) return;
        dying = false;
        snakeHidden = true;
        window.clearTimeout(deathTimer);
        cancelFrame();
        const result = pendingResult;
        pendingResult = null;
        draw();
        showResult(result);
    }

    function showResult({ won, reason, updated, length }) {
        const bestScore = updated.highScores[currentMode.id];
        const newRecord = score > 0 && score > sessionBestAtStart;
        statusLabel.textContent = won ? 'VICTORIA' : reason === 'time' ? 'TIEMPO AGOTADO' : 'FIN DE PARTIDA';
        resultScore.textContent = String(score);
        resultBest.textContent = String(bestScore);
        resultBadge.hidden = !newRecord;
        showOverlay({
            kicker: won ? 'MAPA COMPLETADO' : reason === 'time' ? 'FIN DEL TIEMPO' : reason === 'flood' ? 'ZONA INUNDADA' : reason === 'bomb' ? 'EXPLOSIÓN' : 'FIN DE PARTIDA',
            title: won ? '¡LO LOGRASTE!' : reason === 'time' ? 'Tiempo agotado' : reason === 'flood' ? 'Te alcanzó el agua' : reason === 'bomb' ? 'Demasiado cerca' : 'Te atrapaste',
            copy: `Longitud ${length} · ${currentMode.label}`,
            stats: true,
            over: true
        });
        boardFrame.classList.add('is-game-over');
        if (won) audio?.play('start');
        audio?.setScene('gameover');
    }
    function togglePause() {
        if (!running && !paused) return;
        paused = !paused;
        if (paused) {
            cancelFrame();
            if (activeSince) {
                sessionElapsedMs += Date.now() - activeSince;
                activeSince = 0;
            }
            clearModeTimers();
            statusLabel.textContent = 'EN PAUSA';
            showOverlay({ kicker: 'PAUSA', title: 'Toma aire', copy: 'La partida se reanuda donde la dejaste.', pause: true });
            audio?.playSound('pause');
        } else {
            if (!counting) {
                activeSince = Date.now();
                startModeTimers(true);
                statusLabel.textContent = 'EN PARTIDA';
            }
            hideOverlay();
            audio?.playSound('resume');
            scheduleFrame();
        }
        liveDot.classList.toggle('is-paused', paused);
    }

    function stop() {
        if (running || paused) finishSession(false);
        running = false;
        paused = false;
        cancelFrame();
        clearDeath();
        clearModeTimers();
        hideOverlay();
        countdownLabel.hidden = true;
    }

    function startRound() {
        reset();
    }

    document.addEventListener('keydown', event => {
        if (!document.getElementById('screen-game').classList.contains('is-active')) return;
        const candidate = DIRECTIONS[event.key] ?? DIRECTIONS[event.key.toLowerCase()];
        if (candidate) {
            event.preventDefault();
            setDirection(candidate);
        } else if (event.key === 'Escape' || event.code === 'Space' || event.key.toLowerCase() === 'p') {
            event.preventDefault();
            togglePause();
        } else if (event.key === 'Enter' && !running && !gameoverActions.hidden) {
            event.preventDefault();
            startRound();
        }
    });

    document.addEventListener('visibilitychange', () => {
        if (document.hidden && running && !paused) togglePause();
    });

    document.querySelectorAll('[data-direction]').forEach(button => button.addEventListener('pointerdown', event => {
        event.preventDefault();
        const key = { up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight' }[button.dataset.direction];
        setDirection(DIRECTIONS[key]);
    }));

    let swipeStart = null;
    boardFrame.addEventListener('pointerdown', event => {
        if (event.pointerType !== 'mouse') swipeStart = { x: event.clientX, y: event.clientY };
    });
    boardFrame.addEventListener('pointermove', event => {
        if (!swipeStart) return;
        const dx = event.clientX - swipeStart.x;
        const dy = event.clientY - swipeStart.y;
        if (Math.max(Math.abs(dx), Math.abs(dy)) < SWIPE_DISTANCE) return;
        setDirection(Math.abs(dx) > Math.abs(dy) ? { x: Math.sign(dx), y: 0 } : { x: 0, y: Math.sign(dy) });
        swipeStart = { x: event.clientX, y: event.clientY };
    });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(name => boardFrame.addEventListener(name, () => { swipeStart = null; }));

    pauseButton.addEventListener('click', togglePause);
    document.getElementById('btn-restart').addEventListener('click', startRound);
    document.getElementById('btn-resume').addEventListener('click', togglePause);
    document.getElementById('btn-pause-restart').addEventListener('click', startRound);
    document.getElementById('btn-pause-options').addEventListener('click', () => onOpenOptions?.());
    document.getElementById('btn-pause-home').addEventListener('click', () => onHome?.());
    document.getElementById('btn-gameover-restart').addEventListener('click', startRound);
    document.getElementById('btn-gameover-customize').addEventListener('click', () => onHome?.());

    renderer.resize(currentMap);
    updateScoreLabels();
    draw();
    return {
        start: startRound,
        stop,
        isPaused: () => paused,
        isRunning: () => running,
        isDying: () => dying,
        refresh() {
            const profile = getPlayerProfile();
            currentSkin = getSkin(profile.selectedSkin);
            currentFoodSkin = getFoodSkin(profile.selectedFoodSkin);
            draw();
        }
    };
}
