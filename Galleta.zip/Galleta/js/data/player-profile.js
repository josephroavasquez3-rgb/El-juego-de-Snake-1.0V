import { foodSkins } from '../game/food-skins.js';
import { snakeSkins } from '../game/skins.js';

const PROFILE_LIST_KEY = 'snake_profiles_v1';
const ACTIVE_PROFILE_KEY = 'snake_active_profile_v1';
const LEGACY_PROFILE_KEY = 'snake_player_profile_v1';
const LEGACY_BEST_KEY = 'snake_high_score';

export const profileAvatars = ['🐍', '🦊', '🐸', '🐼', '🐙', '🐯', '🦄', '🤖'];

const modeIds = ['classic', 'timeAttack', 'survival', 'hardcore', 'chaos', 'extremeSurvival', 'speedExtreme', 'puzzle', 'flood', 'portalRun', 'lava', 'bombs', 'labyrinth', 'multiplayer'];
const emptyHighScores = () => Object.fromEntries(modeIds.map(id => [id, 0]));
const emptyStatistics = () => ({ gamesPlayed: 0, gamesWon: 0, totalScore: 0, maximumLength: 3, totalTimeMs: 0 });

function makeId() {
    return globalThis.crypto?.randomUUID?.() ?? `player-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function defaultProfile({ name = 'Jugador', avatar = profileAvatars[0] } = {}) {
    return {
        id: makeId(), name, avatar, highScore: 0, highScores: emptyHighScores(), gamesPlayed: 0,
        selectedSkin: 'classic', selectedFoodSkin: 'food_berry', selectedTheme: 'cyber', difficulty: 'normal', mapId: 'normal', modeId: 'classic',
        soundEnabled: true, soundVolume: 0.65, musicEnabled: false, musicVolume: 0.35,
        statistics: emptyStatistics()
    };
}

// Older saves carried coins, an inventory and shop upgrades; only the equipped looks are migrated.
const LEGACY_SHOP_FIELDS = ['coins', 'inventory', 'equipped', 'upgrades', 'dailyRewards', 'accountId'];

function normalizeProfile(profile) {
    const normalized = { ...defaultProfile(), ...profile };
    const snakeSkin = String(profile.equipped?.snakeSkin ?? normalized.selectedSkin ?? 'classic').replace(/^snake_/, '');
    const foodSkin = String(profile.equipped?.foodSkin ?? normalized.selectedFoodSkin ?? 'food_berry');
    LEGACY_SHOP_FIELDS.forEach(field => delete normalized[field]);
    normalized.selectedSkin = snakeSkins.some(skin => skin.id === snakeSkin) ? snakeSkin : 'classic';
    normalized.selectedFoodSkin = foodSkins.some(skin => skin.id === foodSkin) ? foodSkin : 'food_berry';
    normalized.highScores = { ...emptyHighScores(), ...(profile.highScores ?? {}) };
    normalized.statistics = { ...emptyStatistics(), ...(profile.statistics ?? {}) };
    normalized.gamesPlayed = Math.max(Number(normalized.gamesPlayed) || 0, Number(normalized.statistics.gamesPlayed) || 0);
    normalized.statistics.gamesPlayed = normalized.gamesPlayed;
    normalized.highScore = Math.max(Number(normalized.highScore) || 0, ...Object.values(normalized.highScores).map(Number));
    normalized.name = String(normalized.name || 'Jugador').trim().slice(0, 18) || 'Jugador';
    if (!profileAvatars.includes(normalized.avatar)) normalized.avatar = profileAvatars[0];
    return normalized;
}

function readStoredJson(key) {
    try { return JSON.parse(localStorage.getItem(key) ?? 'null'); }
    catch { return null; }
}

function readProfiles() {
    try {
        const stored = readStoredJson(PROFILE_LIST_KEY);
        if (Array.isArray(stored) && stored.length) {
            const profiles = stored.map(normalizeProfile);
            if (stored.some(profile => profile?.accountId) || localStorage.getItem('snake_account_snapshot_v1')) {
                localStorage.setItem(PROFILE_LIST_KEY, JSON.stringify(profiles));
                localStorage.removeItem('snake_account_snapshot_v1');
            }
            return profiles;
        }
        const oldProfile = readStoredJson(LEGACY_PROFILE_KEY);
        const oldAccount = readStoredJson('snake_account_snapshot_v1');
        const legacyBest = Number.parseInt(localStorage.getItem(LEGACY_BEST_KEY) ?? '0', 10) || 0;
        if (oldProfile || oldAccount?.profile || oldAccount?.name || legacyBest > 0) {
            const legacy = oldProfile ?? oldAccount?.profile ?? {};
            const migrated = normalizeProfile({ ...legacy, name: legacy.name ?? oldAccount?.name, highScore: Math.max(legacy.highScore ?? 0, legacyBest) });
            localStorage.setItem(PROFILE_LIST_KEY, JSON.stringify([migrated]));
            localStorage.setItem(ACTIVE_PROFILE_KEY, migrated.id);
            localStorage.removeItem('snake_account_snapshot_v1');
            return [migrated];
        }
        return [];
    } catch {
        return [];
    }
}

function persist(profiles, activeId = localStorage.getItem(ACTIVE_PROFILE_KEY)) {
    localStorage.setItem(PROFILE_LIST_KEY, JSON.stringify(profiles));
    if (activeId) localStorage.setItem(ACTIVE_PROFILE_KEY, activeId);
    else localStorage.removeItem(ACTIVE_PROFILE_KEY);
    return profiles;
}

export function getPlayerProfiles() {
    return readProfiles();
}

export function getActivePlayerProfile() {
    const profiles = readProfiles();
    const activeId = localStorage.getItem(ACTIVE_PROFILE_KEY);
    return profiles.find(profile => profile.id === activeId) ?? profiles[0] ?? null;
}

export function getPlayerProfile() {
    return getActivePlayerProfile() ?? createPlayerProfile({ name: 'Jugador' });
}

export function createPlayerProfile({ name, avatar } = {}) {
    const profiles = readProfiles();
    const profile = defaultProfile({ name: String(name ?? '').trim().slice(0, 18) || 'Jugador', avatar });
    profiles.push(profile);
    persist(profiles, profile.id);
    return profile;
}

export function selectPlayerProfile(id) {
    const profiles = readProfiles();
    if (!profiles.some(profile => profile.id === id)) return null;
    persist(profiles, id);
    return profiles.find(profile => profile.id === id);
}

export function renamePlayerProfile(id, name) {
    const safeName = String(name ?? '').trim().slice(0, 18);
    if (!safeName) return null;
    const profiles = readProfiles().map(profile => profile.id === id ? { ...profile, name: safeName } : profile);
    persist(profiles);
    return profiles.find(profile => profile.id === id) ?? null;
}

export function deletePlayerProfile(id) {
    const profiles = readProfiles();
    const remaining = profiles.filter(profile => profile.id !== id);
    if (remaining.length === profiles.length) return null;
    const activeId = localStorage.getItem(ACTIVE_PROFILE_KEY);
    const nextActive = activeId === id ? remaining[0]?.id : activeId;
    persist(remaining, nextActive ?? null);
    return remaining[0] ?? null;
}

export function updatePlayerProfile(patch) {
    const profiles = readProfiles();
    let active = getActivePlayerProfile();
    if (!active) active = createPlayerProfile({ name: 'Jugador' });
    const updated = normalizeProfile({
        ...active,
        ...patch,
        highScores: { ...active.highScores, ...(patch.highScores ?? {}) },
        statistics: { ...active.statistics, ...(patch.statistics ?? {}) }
    });
    const nextProfiles = readProfiles().map(profile => profile.id === active.id ? updated : profile);
    persist(nextProfiles, active.id);
    return updated;
}

export function recordGameStarted() {
    const profile = getPlayerProfile();
    const gamesPlayed = profile.gamesPlayed + 1;
    return updatePlayerProfile({ gamesPlayed, statistics: { gamesPlayed } });
}

export function recordGameEnded({ score, length, elapsedMs, won = false, modeId = 'classic' }) {
    const profile = getPlayerProfile();
    const stats = profile.statistics;
    const modeBest = Math.max(profile.highScores[modeId] ?? 0, score);
    const highScores = { ...profile.highScores, [modeId]: modeBest };
    const updated = updatePlayerProfile({
        highScores,
        highScore: Math.max(profile.highScore, score),
        statistics: {
            gamesWon: stats.gamesWon + (won ? 1 : 0),
            totalScore: stats.totalScore + score,
            maximumLength: Math.max(stats.maximumLength, length),
            totalTimeMs: stats.totalTimeMs + elapsedMs
        }
    });
    return updated;
}

export function saveBestScore(score, modeId = 'classic') {
    const profile = getPlayerProfile();
    const highScores = { ...profile.highScores, [modeId]: Math.max(profile.highScores[modeId] ?? 0, score) };
    return updatePlayerProfile({ highScores, highScore: Math.max(profile.highScore, score) }).highScore;
}

export function readBestScore(modeId) {
    const profile = getPlayerProfile();
    return modeId ? profile.highScores[modeId] ?? 0 : profile.highScore;
}

export function savePlayerPreferences(preferences) {
    return updatePlayerProfile(preferences);
}