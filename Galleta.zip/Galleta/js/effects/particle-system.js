export class ParticleSystem {
    constructor() {
        this.particles = [];
    }

    // `delay` lets a burst wait until the snake's head visually reaches the food.
    burst(x, y, color, count = 14, delay = 0) {
        const bornAt = performance.now() + delay;
        for (let index = 0; index < count; index += 1) {
            const angle = (Math.PI * 2 * index) / count + Math.random() * 0.28;
            const speed = 1.1 + Math.random() * 2.2;
            this.particles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, color, bornAt, life: 460 });
        }
    }

    clear() {
        this.particles = [];
    }

    draw(context, time) {
        this.particles = this.particles.filter(particle => time - particle.bornAt < particle.life);
        this.particles.forEach(particle => {
            const progress = (time - particle.bornAt) / particle.life;
            if (progress < 0) return;
            context.globalAlpha = 1 - progress;
            context.fillStyle = particle.color;
            context.beginPath();
            context.arc(particle.x + particle.vx * progress * 14, particle.y + particle.vy * progress * 14, Math.max(1, 4 * (1 - progress)), 0, Math.PI * 2);
            context.fill();
        });
        context.globalAlpha = 1;
    }
}